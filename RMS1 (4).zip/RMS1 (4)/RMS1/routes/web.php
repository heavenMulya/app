<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Branch\BranchManagementController;
use App\Http\Controllers\Bulding\BuldingManagementController;
use App\Http\Controllers\Tenant\TenantManagementController;
use App\Http\Controllers\Invoice\InvoiceManagementController;
use App\Http\Controllers\Company\CompanyManagementController;
use App\Http\Controllers\PropertyMaster\ProperMasterController;
use App\Http\Controllers\Agreements\TenantAgreementMappingController;
use App\Http\Controllers\User\UserManagementController;
use App\Http\Controllers\Floor\FloorManagementController;
use App\Http\Controllers\RentalType\RentalTypeManagementController;
use App\Http\Controllers\PriceMaster\PriceMasterController;
use App\Http\Controllers\CompanyMaster\CompanyMasterController;



Route::get('/', function () {
    return view('index');
});


Route::get('/property',[ProperMasterController ::class, 'showpropertyForm'])->name('property');
Route::get('/get-branches-by-company', [ProperMasterController::class, 'getBranchesByCompany'])->name('get.branches.by.company');
Route::post('/property/save', [ProperMasterController::class, 'saveProperty'])->name('property.save');
Route::put('/property/update', [ProperMasterController::class, 'updateProperty'])->name('property.update');
Route::delete('/property/delete', [ProperMasterController::class, 'deleteProperty'])->name('property.delete');
Route::get('/load-branches/{companyId}', [ProperMasterController::class, 'loadBranches']);
Route::post('/load-buildings', [ProperMasterController::class, 'loadBuildings']);
Route::post('/load-floors', [ProperMasterController::class, 'loadFloors']);
Route::post('/load-properties', [ProperMasterController::class, 'loadPropety']);




Route::get('/tenant', [TenantManagementController::class, 'index'])->name('tenant');
Route::put('/tenant/update', [TenantManagementController::class, 'update'])->name('tenant.update');
Route::delete('/tenant/delete', [TenantManagementController::class, 'destroy'])->name('tenant.delete');
Route::post('/tenant/save', [TenantManagementController::class, 'create'])->name('tenant.save');


Route::get('/branch', [BranchManagementController::class, 'index'])->name('branch');
Route::post('/branch/update', [BranchManagementController::class, 'update'])->name('branch.update');
Route::post('/branch/delete', [BranchManagementController::class, 'destroy'])->name('branch.delete');
Route::post('/branch/save', [BranchManagementController::class, 'create'])->name('branch.save');


Route::get('/bulding', [BuldingManagementController::class, 'index'])->name('bulding');
Route::post('/bulding/update', [BuldingManagementController::class, 'update'])->name('bulding.update');
Route::post('/bulding/delete', [BuldingManagementController::class, 'destroy'])->name('bulding.delete');
Route::post('/bulding/save', [BuldingManagementController::class, 'create'])->name('bulding.save');


Route::get('/agreement', [TenantAgreementMappingController::class, 'index'])->name('agreement');
Route::post('/agreement/update', [TenantAgreementMappingController::class, 'update'])->name('agreement.update');
Route::post('/agreement/delete', [TenantAgreementMappingController::class, 'destroy'])->name('agreement.delete');
Route::post('/agreement/save', [TenantAgreementMappingController::class, 'create'])->name('agreement.save');
Route::get('/increase-vat', [TenantAgreementMappingController::class, 'increaseVatUsingRenewal']);
Route::get('/get-tenant-details', [TenantAgreementMappingController::class, 'showInvoiceDetails']);


Route::post('/agreement/document/save', [TenantAgreementMappingController::class, 'createDocumentsAgreement'])->name('agreement.document.save');
 Route::get('/agreements/documents/{DOC_ID}', [TenantAgreementMappingController::class, 'showTenantDocument'])->name('agreement.document.view');



 Route::get('/branch-details/{id}', [TenantAgreementMappingController::class, 'getBranchDetails']);
Route::get('/agreements-by-tenant/{tenantId}', [TenantAgreementMappingController::class, 'getAgreementByTenant']);
Route::get('/price-details/{id}', [TenantAgreementMappingController::class, 'getPriceDetails'])->name('price.details');
Route::get('/common-dropdown/{id}', [TenantAgreementMappingController::class, 'getCommonDropdownDetails'])->name('common.dropdown');
Route::get('/renewal-mapping', [TenantAgreementMappingController::class, 'showRenewalMapping'])->name('renewal.mapping');

Route::get('/load-tenant-by-company', [TenantAgreementMappingController::class, 'loadTenantByCompanyID']);
Route::get('/load-branch-by-company', [TenantAgreementMappingController::class, 'loadBranchByCompanyID']);
Route::get('/load-buildings-by-branch', [TenantAgreementMappingController::class, 'loadBuildingsByBranch']);
Route::get('/load-floors', [TenantAgreementMappingController::class, 'getFloors']);
Route::get('/load-property', [TenantAgreementMappingController::class, 'loadProperty']);
Route::get('/load-price_id', [TenantAgreementMappingController::class, 'getPriceID']);




Route::get('/tenant', [TenantManagementController::class, 'index'])->name('tenant');
Route::post('/tenant/update', [TenantManagementController::class, 'update'])->name('tenant.update');
Route::post('/tenant/delete', [TenantManagementController::class, 'destroy'])->name('tenant.delete');
Route::post('/tenant/save', [TenantManagementController::class, 'create'])->name('tenant.save');
Route::get('/tenant-details/{id}', [TenantManagementController::class, 'getBranchDetails']);
Route::post('/tenant/document/save', [TenantManagementController::class, 'createDocumentsTenant'])->name('tenant.document.save');
Route::get('/LoadDocumentPathTenant/{id}', [TenantManagementController::class, 'LoadDocumentPath']);


Route::get('/invoice', [InvoiceManagementController::class, 'index'])->name('invoice');
Route::post('/invoice/update', [InvoiceManagementController::class, 'update'])->name('invoice.update');
Route::post('/invoice/delete', [InvoiceManagementController::class, 'destroy'])->name('invoice.delete');
Route::post('/invoice/save', [InvoiceManagementController::class, 'create'])->name('invoice.save');

Route::post('/get-next-due-details', [InvoiceManagementController::class, 'getNextDueDetails'])->name('due.details');
Route::get('/agreement-id/{tenantId}/{propertyId}', [InvoiceManagementController::class, 'getAgreementId'])->name('agreement.id');


//Route::get('/invoice-details/{id}', [InvoiceManagementController::class, 'getBranchDetails']);


Route::get('/company',[CompanyManagementController::class, 'showCompanyForm'])->name('comapany');
Route::post('/company/save', [CompanyManagementController::class, 'createCompany'])->name('company.save');
Route::put('/company/update', [CompanyManagementController::class, 'updateCompany'])->name('company.update');



//Route::get('/branch', [DynamicSPController::class, 'index'])->name('branch');
//Route::post('/branch/save', [DynamicSPController::class, 'SP_INSERT_PROPERTY_SELECTION'])->name('branch.save');
//Route::post('/branch/update', [DynamicSPController::class, 'update'])->name('branch.update');
//Route::post('/branch/delete', [DynamicSPController::class, 'destroy'])->name('branch.delete');

Route::get('/load-dropdowns', [TenantAgreementMappingController::class, 'loadDropdownData'])->name('dropdown.load');

Route::get('/common-dropdown', [TenantAgreementMappingController::class, 'loadDropdownByFieldId']);
Route::get('/LoadDocumentPath/{id}', [TenantAgreementMappingController::class, 'LoadDocumentPath']);
Route::get('/LoadAgreementMappingDetails/{id}', [TenantAgreementMappingController::class, 'LoadDetails']);
Route::get('/LoadInvoiceDetails/{id}', [TenantAgreementMappingController::class, 'LoadInvoiceDetails']);



Route::get('/user', [UserManagementController::class, 'index'])->name('userManagement');
Route::post('/user/save', [UserManagementController::class, 'create'])->name('user.save');
Route::post('/user/update', [UserManagementController::class, 'update'])->name('user.update');
Route::post('/user/delete', [UserManagementController::class, 'destroy'])->name('user.delete');

Route::get('/floor', [FloorManagementController::class, 'index'])->name('floor');
Route::post('/floor/save', [FloorManagementController::class, 'create'])->name('floor.save');
Route::post('/floor/update', [FloorManagementController::class, 'update'])->name('floor.update');
Route::post('/floor/delete', [FloorManagementController::class, 'destroy'])->name('floor.delete');


Route::get('/rental-type', [RentalTypeManagementController::class, 'index'])->name('rental-type');
Route::post('/rental-type/save', [RentalTypeManagementController::class, 'create'])->name('rental-type.save');
Route::post('/rental-type/update', [RentalTypeManagementController::class, 'update'])->name('rental-type.update');
Route::post('/rental-type/delete', [RentalTypeManagementController::class, 'destroy'])->name('rental-type.delete');


Route::get('/pricesetting',[PriceMasterController ::class, 'index'])->name('pricesetting');
Route::Post('/pricesetting/save',[PriceMasterController ::class, 'create'])->name('pricesetting.save');
Route::PUT('/pricesetting/update',[PriceMasterController ::class, 'update'])->name('pricesetting.update');
Route::post('/pricesetting/delete',[PriceMasterController ::class, 'destroy'])->name('pricesetting.delete');
Route::get('/branches/{companyId}', [PriceMasterController::class, 'loadBranches']);
Route::get('/buildings', [PriceMasterController::class, 'loadBuildings']);
Route::get('/floors', [PriceMasterController::class, 'loadFloors']);
Route::get('/properties', [PriceMasterController::class, 'loadProperties']);


Route::get('/company',[CompanyMasterController::class, 'showCompanyForm'])->name('company');
Route::post('/company/save', [CompanyMasterController::class, 'createCompany'])->name('company.save');
Route::post('/company/update', [CompanyMasterController::class, 'updateCompany'])->name('company.update');
Route::post('/company/delete', [CompanyMasterController::class, 'destroy'])->name('company.delete');
