<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Branch\BranchManagementController;
use App\Http\Controllers\Bulding\BuldingManagementController;
use App\Http\Controllers\Agreements\TenantAgreementMappingController;
use App\Http\Controllers\Tenant\TenantManagementController;
use App\Http\Controllers\Invoice\InvoiceManagementController;
use App\Http\Controllers\Company\CompanyManagementController;
use App\Http\Controllers\Common\DynamicSPController;


Route::get('/branch', [DynamicSPController::class, 'index'])->name('branch');
Route::post('/branch/save', [DynamicSPController::class, 'SP_INSERT_PROPERTY_SELECTION'])->name('branch.save');
Route::post('/branch/update', [DynamicSPController::class, 'update'])->name('branch.update');
Route::post('/branch/delete', [DynamicSPController::class, 'destroy'])->name('branch.delete');

Route::get('/load-dropdowns', [DynamicSPController::class, 'loadDropdownData'])->name('dropdown.load');

Route::get('/common-dropdown', [DynamicSPController::class, 'loadDropdownByFieldId']);


