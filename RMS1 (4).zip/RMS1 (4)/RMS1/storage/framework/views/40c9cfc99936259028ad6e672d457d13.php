
<?php echo $__env->make('layout.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->make('layout.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('layout.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="page-wrapper">
    <div class="content">
        <div class="page-header">
            <div class="page-title">
                <h4>Invoice List</h4>
                <h6>Manage your Invoice</h6>
            </div>

            <?php if(isset($message)): ?>
                <div id="session-alert" class="alert alert-<?php echo e($status === 'Error' ? 'danger' : 'success'); ?> alert-dismissible fade show"
                     role="alert"
                     style="position: fixed; top: 90px; right: 500px; z-index: 1055; min-width: 450px;">
                    <?php echo e($message); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>

            <?php endif; ?>

            <div class="page-btn">
                <a href="javascript:void(0);" class="btn btn-added" data-bs-toggle="modal" data-bs-target="#addModal">
                    <img src="assets/img/icons/plus.svg" alt="img" class="me-1">Add New Invoice
                </a>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="table-top">
                    <div class="search-set">
                        <div class="search-path">
                            <a class="btn btn-filter" id="filter_search">
                                <img src="assets/img/icons/filter.svg" alt="img">
                                <span><img src="assets/img/icons/closes.svg" alt="img"></span>
                            </a>
                        </div>
                        <div class="search-input">
                            <a class="btn btn-searchset"><img src="assets/img/icons/search-white.svg" alt="img"></a>
                        </div>
                    </div>
                    <div class="wordset">
                        <ul>
                            <li>
                                <a data-bs-toggle="tooltip" data-bs-placement="top" title="pdf">
                                    <img src="assets/img/icons/pdf.svg" alt="img">
                                </a>
                            </li>
                            <li>
                                <a data-bs-toggle="tooltip" data-bs-placement="top" title="excel">
                                    <img src="assets/img/icons/excel.svg" alt="img">
                                </a>
                            </li>
                            <li>
                                <a data-bs-toggle="tooltip" data-bs-placement="top" title="print">
                                    <img src="assets/img/icons/printer.svg" alt="img">
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="card mb-0" id="filter_inputs">
                    <div class="card-body pb-0">
                        <div class="row">
                            <div class="col-lg-12 col-sm-12">
                                <div class="row">
                                

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table datanew">
                        <thead>
                            <tr>
                                <th>
                                    <label class="checkboxs">
                                        <input type="checkbox" id="select-all">
                                        <span class="checkmarks"></span>
                                    </label>
                                </th>
                                <th>ID</th>
                                <th>INVOICE_NO</th>
                                <th>INVOICE_DATE</th>
                                <th>PAYMENT_FOR</th>
                                <th>Remarks</th>
                                <th>Action</th>
                            </tr>
                        </thead>

  <tbody>
<?php $__currentLoopData = $invoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td>
            <label class="checkboxs">
                <input type="checkbox">
                <span class="checkmarks"></span>
            </label>
        </td>

        <td><?php echo e($item->id ?? 'N/A'); ?></td>
        <td><?php echo e($item->INVOICE_NO ?? 'N/A'); ?></td>
        <td><?php echo e($item->INVOICE_DATE ?? 'N/A'); ?></td>
        <td><?php echo e($item->PAYMENT_FOR ?? 'N/A'); ?></td>
        <td><?php echo e($item->REMARKS ?? 'N/A'); ?></td>

        <td>
         <a class="me-3 view-btn"
   href="javascript:void(0);"
 data-invoice_id="<?php echo e($item->id); ?>"
   data-invoice_no="<?php echo e($item->INVOICE_NO); ?>"
   data-invoice_date="<?php echo e($item->INVOICE_DATE); ?>"
   data-payment_for="<?php echo e($item->PAYMENT_FOR); ?>"
   data-tenant_id="<?php echo e($item->TENANT_NAME); ?>"
   data-branch_id="<?php echo e($item->BRANCH_NAME); ?>"
    data-building_id="<?php echo e($item->BUILDING_ID); ?>"
   data-building_name="<?php echo e($item->BUILDING_NAME); ?>"
   data-floor_id="<?php echo e($item->FLOOR_ID); ?>"
   data-floor_name="<?php echo e($item->FLOOR_NAME); ?>"
   data-property_id="<?php echo e($item->PROPERTY_ID); ?>"
   data-property_name="<?php echo e($item->PROPERTY_NAME); ?>"
   data-due_id="<?php echo e($item->DUE_ID); ?>"
   data-due_month="<?php echo e($item->DUE_MONTH); ?>"
   data-due_year="<?php echo e($item->DUE_YEAR); ?>"
   data-due_amount="<?php echo e($item->DUE_AMOUNT); ?>"
   data-invoice_amount_with_vat="<?php echo e($item->INVOICE_AMOUNT_WITH_VAT); ?>"
   data-total_amount="<?php echo e($item->TOTAL_AMOUNT); ?>"
   data-vat_percentage="<?php echo e($item->VAT_PERCENTAGE); ?>"
   data-vat_amount="<?php echo e($item->VAT_AMOUNT); ?>"
   data-with_holding_percentage="<?php echo e($item->WITH_HOLDING_PERCENTAGE); ?>"
   data-total_income_after_withholding_tax="<?php echo e($item->TOTAL_INCOME_AFTER_WITH_HOLDING_TAX); ?>"
   data-payment_type="<?php echo e($item->PAYMENT_TYPE); ?>"
   data-remarks="<?php echo e($item->REMARKS); ?>"
   data-status_master="<?php echo e($item->STATUS_MASTER); ?>"
   data-agreement_id="<?php echo e($item->AGREEMENT_ID); ?>"
   data-bs-toggle="modal"
   data-bs-target="#viewAgreementMappingModal">
    <img src="assets/img/icons/eye.svg" alt="View">
</a>



<a class="me-3 edit-btn"
   href="javascript:void(0);"
   data-bs-toggle="modal"
   data-bs-target="#editAgreementModal"
   data-invoice_id="<?php echo e($item->id); ?>"
   data-invoice_no="<?php echo e($item->INVOICE_NO); ?>"
   data-invoice_date="<?php echo e($item->INVOICE_DATE); ?>"
   data-payment_for="<?php echo e($item->PAYMENT_FOR); ?>"
   data-tenant_id="<?php echo e($item->TENANT_ID); ?>"
   data-branch_id="<?php echo e($item->BRANCH_ID); ?>"
    data-building_id="<?php echo e($item->BUILDING_ID); ?>"
   data-building_name="<?php echo e($item->BUILDING_NAME); ?>"
   data-floor_id="<?php echo e($item->FLOOR_ID); ?>"
   data-floor_name="<?php echo e($item->FLOOR_NAME); ?>"
   data-property_id="<?php echo e($item->PROPERTY_ID); ?>"
   data-property_name="<?php echo e($item->PROPERTY_NAME); ?>"
   data-due_id="<?php echo e($item->DUE_ID); ?>"
   data-due_month="<?php echo e($item->DUE_MONTH); ?>"
   data-due_year="<?php echo e($item->DUE_YEAR); ?>"
   data-due_amount="<?php echo e($item->DUE_AMOUNT); ?>"
   data-invoice_amount_with_vat="<?php echo e($item->INVOICE_AMOUNT_WITH_VAT); ?>"
   data-total_amount="<?php echo e($item->TOTAL_AMOUNT); ?>"
   data-vat_percentage="<?php echo e($item->VAT_PERCENTAGE); ?>"
   data-vat_amount="<?php echo e($item->VAT_AMOUNT); ?>"
   data-with_holding_percentage="<?php echo e($item->WITH_HOLDING_PERCENTAGE); ?>"
   data-total_income_after_withholding_tax="<?php echo e($item->TOTAL_INCOME_AFTER_WITH_HOLDING_TAX); ?>"
   data-payment_type="<?php echo e($item->PAYMENT_TYPE); ?>"
   data-remarks="<?php echo e($item->REMARKS); ?>"
   data-status_master="<?php echo e($item->STATUS_MASTER); ?>"
   data-agreement_id="<?php echo e($item->AGREEMENT_ID); ?>"
>
    <img src="assets/img/icons/edit.svg" alt="Edit">
</a>




<a class="confirm-text delete-agreement-btn disabled"
   href="javascript:void(0);"
   data-invoice_id="<?php echo e($item->id); ?>"
   data-invoice_no="<?php echo e($item->INVOICE_NO); ?>"
   data-bs-toggle="modal"
   data-bs-target="#deletebuldingModal"
   tabindex="-1"
   aria-disabled="true"
   style="pointer-events: none; opacity: 0.5;">
    <img src="assets/img/icons/delete.svg" alt="Delete">
</a>



        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>

                    </table>
                </div> <!-- .table-responsive -->
            </div> <!-- .card-body -->
        </div> <!-- .card -->
    </div> <!-- .content -->
</div> <!-- .page-wrapper -->


<!-- Document Preview Modal -->
<div class="modal fade" id="documentPreviewModal" tabindex="-1" aria-labelledby="documentPreviewModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="documentPreviewModalLabel">Document Preview</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="documentPreviewContent">
        <p class="text-muted">Loading document...</p>
      </div>
    </div>
  </div>
</div>






<div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg custom-modal-width">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Invoice</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="<?php echo e(route('invoice.save')); ?>">
                    <?php echo csrf_field(); ?>
<div class="row">
                        <!-- First two fields in one row -->
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Invoice No</label>
                            <input type="text" class="form-control" name="invoice_no" required>
                        </div>

                                                <div class="col-md-6 mb-3">
                            <label class="form-label">Agreement ID</label>
                            <input type="text" class="form-control" name="agreement_id" id="agreement_id">
                        </div>

<div class="col-md-6 mb-3">
    <label class="form-label">Invoice Date</label>
    <input type="date" class="form-control" name="invoice_date" value="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>" required>
</div>

                                       
      <div class="col-md-6  mb-3">
                <label class="form-label">Tenant</label>
                <select class="form-select" name="tenant_id" id="tenant_id" required>
                    <option value="">Select Tenant </option>
                    <?php $__currentLoopData = $tenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tenant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tenant->TENANT_ID); ?>"><?php echo e($tenant->TENANT_NAME); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>


            <div class="col-md-6  mb-3">
                <label class="form-label">Branch</label>
                <select class="form-select" name="branch_id" id="branch_id" required>
                    <option value=""> Select Branch </option>
                    <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($branch->BRANCH_ID); ?>"><?php echo e($branch->BRANCH_NAME); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

                         

           <div class="col-md-6  mb-3">
    <label class="form-label">Building</label>
      <select class="form-select" name="building_id" id="building_id" required>
         <option value="">Select Building </option>
         <?php $__currentLoopData = $building; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($branch->BUILDING_ID); ?>"><?php echo e($branch->BUILDING_NAME); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

            <div class="col-md-6  mb-3">
                <label class="form-label">Floor</label>
                    <select class="form-select" name="floor_id" id="floor_id" required>
        <option value="">Select Floor </option>
          <?php $__currentLoopData = $floor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($branch->FLOOR_ID); ?>"><?php echo e($branch->FLOOR_NAME); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
            </div>

               <div class="col-md-6  mb-3">
                <label class="form-label">Property</label>
                    <select class="form-select" name="property_id" id="property_id" required>
        <option value="">Select Property</option>
            <?php $__currentLoopData = $property; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($branch->PROPERTY_ID); ?>"><?php echo e($branch->PROPERTY_NAME); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
            </div>
                        
             <div class="col-md-6 mb-3">
                            <label class="form-label">Payment For</label>
                                <select class="form-select" name="payment_for" id="payment_for" required>
                                <option value="">Select Payment For</option>
                                    <option value="ADVANCE">ADVANCE</option>
                                    <option value="RENT">RENT</option>
                            </select>
                        </div>



                        <div class="col-md-6 mb-3">
                            <label class="form-label">Due ID</label>
                            <input type="text" class="form-control" name="due_id" id="due_id" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Due Month</label>
                            <input type="text" class="form-control" name="due_month" id="due_month"  required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Due Year</label>
                            <input type="number" class="form-control" name="due_year" id="due_year" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Due Amount</label>
                            <input type="number" class="form-control" name="due_amount" id="due_amount" step="0.01" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Invoice Amount with VAT</label>
                            <input type="number" class="form-control" name="invoice_amount_with_vat" id="invoice_amount_with_vat" step="0.01" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Total Amount</label>
                            <input type="number" class="form-control" name="total_amount" id="total_amount" step="0.01" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">VAT %</label>
                            <input type="number" class="form-control" name="vat_percentage" id="vat_percentage" step="0.01" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">VAT Amount</label>
                            <input type="number" class="form-control" name="vat_amount" id="vat_amount" step="0.01" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Withholding %</label>
                            <input type="number" class="form-control" name="with_holding_percentage" id="with_holding_percentage"  step="0.01" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Total Income After Withholding</label>
                            <input type="number" class="form-control" name="total_income_after_withholding_tax" id="total_income_after_withholding_tax" step="0.01" required>
                       
                        </div>
    <div class="col-md-6 mb-3">
                            <label class="form-label">Payment Type</label>

                                                        <select class="form-select" name="payment_type" id="payment_type" required>
                                <option value="">Select Payment Type</option>
        
                                    <option value="CASH">CASH</option>
                                    <option value="BANK">BANK</option>

                            </select>
                        </div>

                    
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Remarks</label>
                            <input type="text" class="form-control" name="remarks" id="remarks" maxlength="256">
                        </div>

                              <div class="col-md-6 mb-3">
                            <label for="status_master" class="form-label">Status</label>
                            <select class="form-select" id="status_master" name="status_master" required>
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                            </select>
                        </div>


                    <!-- Hidden Metadata -->
                    <input type="hidden" name="created_by" value="<?php echo e($createdBy); ?>">
                    <input type="hidden" name="created_mac_address" value="<?php echo e($macAddress); ?>">

                    <div class="modal-footer mt-3">
                        <button type="submit" class="btn btn-primary">Save Invoice</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    </div>


                </div>

                </form>
            
            </div>
        </div>
    </div>
</div>




<!-- Edit Agreement Modal -->
<div class="modal fade" id="editAgreementModal" tabindex="-1" aria-labelledby="editAgreementLabel" aria-hidden="true">

    <div class="modal-dialog modal-lg custom-modal-width">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">Edit Invoice</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
       <div class="modal-body">
               

        <form method="POST" action="<?php echo e(route('invoice.update')); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>

                <div class="modal-body">
                    <input type="hidden" name="invoice_id" id="edit_invoice_id">

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="edit_invoice_no" class="form-label">Invoice No</label>
                            <input type="text" class="form-control" id="edit_invoice_no" name="invoice_no" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="edit_invoice_date" class="form-label">Invoice Date</label>
                            <input type="date" class="form-control" id="edit_invoice_date" name="invoice_date" required>
                        </div>
                          
                                                <div class="col-md-6 mb-3">
                            <label class="form-label">Agreement ID</label>
                            <input type="text" class="form-control" name="agreement_id" id="edit_agreement_id" disabled>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="edit_payment_for" class="form-label">Payment For</label>
                            <select class="form-select" id="edit_payment_for" name="payment_for" required>
                                <option value="">Select Payment For</option>
                                <option value="ADVANCE">ADVANCE</option>
                                <option value="RENT">RENT</option>
                            </select>
                        </div>

                        
                    <!-- TENANT -->
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Tenant</label>
                        <select class="form-select" name="tenant_id" id="edit_tenant_id" required>
                            <option value="">-- Select Tenant --</option>
                            <?php $__currentLoopData = $tenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tenant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tenant->TENANT_ID); ?>"><?php echo e($tenant->TENANT_NAME); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- BRANCH -->
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Branch</label>
                        <select class="form-select" name="branch_id" id="edit_branch_id" required>
                            <option value="">-- Select Branch --</option>
                            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($branch->BRANCH_ID); ?>"><?php echo e($branch->BRANCH_NAME); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- BUILDING -->
                 

               <div class="col-md-6 mb-3">
    <label class="form-label">Building</label>
    <select class="form-select" name="building_id" id="edit_building_id" required>
        <option value="">-- Select Building --</option>
        <?php $__currentLoopData = $building; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($branch->BUILDING_ID); ?>"><?php echo e($branch->BUILDING_NAME); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>


<!-- FLOOR -->

     <div class="col-md-6  mb-3">
                <label class="form-label">Floor</label>
                    <select class="form-select" name="floor_id" id="edit_floor_id" required>
        <option value="">Select Floor</option>
          <?php $__currentLoopData = $floor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($branch->FLOOR_ID); ?>"><?php echo e($branch->FLOOR_NAME); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
            </div>

                

                    <!-- PROPERTY -->
          <div class="col-md-6  mb-3">
                <label class="form-label">Property</label>
                    <select class="form-select" name="property_id" id="edit_property_id" required>
        <option value=""> Select Property</option>
            <?php $__currentLoopData = $property; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($branch->PROPERTY_ID); ?>"><?php echo e($branch->PROPERTY_NAME); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
            </div>
                        <div class="col-md-6 mb-3">
                            <label for="edit_due_id" class="form-label">Due ID</label>
                            <input type="text" class="form-control" id="edit_due_id" name="due_id" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="edit_due_month" class="form-label">Due Month</label>
                            <input type="text" class="form-control" id="edit_due_month" name="due_month" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="edit_due_year" class="form-label">Due Year</label>
                            <input type="number" class="form-control" id="edit_due_year" name="due_year" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="edit_due_amount" class="form-label">Due Amount</label>
                            <input type="number" class="form-control" id="edit_due_amount" name="due_amount" step="0.01" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="edit_invoice_amount_with_vat" class="form-label">Invoice Amount with VAT</label>
                            <input type="number" class="form-control" id="edit_invoice_amount_with_vat" name="invoice_amount_with_vat" step="0.01" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="edit_total_amount" class="form-label">Total Amount</label>
                            <input type="number" class="form-control" id="edit_total_amount" name="total_amount" step="0.01" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="edit_vat_percentage" class="form-label">VAT %</label>
                            <input type="number" class="form-control" id="edit_vat_percentage" name="vat_percentage" step="0.01" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="edit_vat_amount" class="form-label">VAT Amount</label>
                            <input type="number" class="form-control" id="edit_vat_amount" name="vat_amount" step="0.01" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="edit_with_holding_percentage" class="form-label">Withholding %</label>
                            <input type="number" class="form-control" id="edit_with_holding_percentage" name="with_holding_percentage" step="0.01" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="edit_total_income_after_withholding_tax" class="form-label">Total Income After Withholding</label>
                            <input type="number" class="form-control" id="edit_total_income_after_withholding_tax" name="total_income_after_withholding_tax" step="0.01" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="edit_payment_type" class="form-label">Payment Type</label>
                            <select class="form-select" id="edit_payment_type" name="payment_type" required>
                                <option value="CASH">CASH</option>
                                <option value="BANK">BANK</option>
                            </select>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="edit_remarks" class="form-label">Remarks</label>
                            <input type="text" class="form-control" id="edit_remarks" name="remarks" maxlength="256">
                        </div>

                      <div class="col-md-6 mb-3">
                            <label for="edit_status_master" class="form-label">Status</label>
                            <select class="form-select" id="edit_status_master" name="status_master" required>
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                            </select>
                        </div>

                  

                        <input type="hidden" name="agreement_id" id="edit_agreement_id">
                    <input type="hidden" name="created_by" value="<?php echo e($createdBy); ?>">
                    <input type="hidden" name="modified_by" value="<?php echo e($createdBy); ?>">
                    <input type="hidden" name="created_mac_address" value="<?php echo e($macAddress); ?>">
                    <input type="hidden" name="updated_mac_address" value="<?php echo e($macAddress); ?>">
                    <input type="hidden" name="created_date" value="<?php echo e(now()); ?>">
                    <input type="hidden" name="modified_date" value="<?php echo e(now()); ?>">
                </div>

                <div class="modal-footer mt-3">
                    <button type="submit" class="btn btn-success">Update Invoice</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
            </form>

                </div>
            </div>
           
        </div>
    </div>
</div>



<!-- View Invoice Modal -->
<div class="modal fade" id="viewAgreementMappingModal" tabindex="-1" aria-labelledby="viewAgreementMappingModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="viewAgreementMappingModalLabel">Invoice Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body">
        <div class="row">
          <!-- Core Invoice Info -->
          <div class="col-md-6 mb-3"><label class="form-label">Invoice ID</label><input type="text" class="form-control" id="view_invoice_id" readonly></div>
          <div class="col-md-6 mb-3"><label class="form-label">Invoice No</label><input type="text" class="form-control" id="view_invoice_no" readonly></div>
          <div class="col-md-6 mb-3"><label class="form-label">Invoice Date</label><input type="text" class="form-control" id="view_invoice_date" readonly></div>
                     <div class="col-md-6 mb-3">
                            <label class="form-label">Agreement ID</label>
                            <input type="text" class="form-control" id="view_agreement_id" disabled>
                        </div>
          <div class="col-md-6 mb-3"><label class="form-label">Payment For</label><input type="text" class="form-control" id="view_payment_for" readonly></div>

          <!-- Location & Tenant -->
          <div class="col-md-6 mb-3"><label class="form-label">Tenant</label><input type="text" class="form-control" id="view_tenant_id" readonly></div>
          <div class="col-md-6 mb-3"><label class="form-label">Branch</label><input type="text" class="form-control" id="view_branch_id" readonly></div>
          <div class="col-md-6 mb-3"><label class="form-label">Building</label><input type="text" class="form-control" id="view_building_id" readonly></div>
          <div class="col-md-6 mb-3"><label class="form-label">Floor</label><input type="text" class="form-control" id="view_floor_id" readonly></div>
          <div class="col-md-6 mb-3"><label class="form-label">Property</label><input type="text" class="form-control" id="view_property_id" readonly></div>

          <!-- Financials -->
          <div class="col-md-6 mb-3"><label class="form-label">Due ID</label><input type="text" class="form-control" id="view_due_id" readonly></div>
          <div class="col-md-6 mb-3"><label class="form-label">Due Month</label><input type="text" class="form-control" id="view_due_month" readonly></div>
          <div class="col-md-6 mb-3"><label class="form-label">Due Year</label><input type="text" class="form-control" id="view_due_year" readonly></div>
          <div class="col-md-6 mb-3"><label class="form-label">Due Amount</label><input type="text" class="form-control" id="view_due_amount" readonly></div>

          <div class="col-md-6 mb-3"><label class="form-label">Invoice Amount with VAT</label><input type="text" class="form-control" id="view_invoice_amount_with_vat" readonly></div>
          <div class="col-md-6 mb-3"><label class="form-label">Total Amount</label><input type="text" class="form-control" id="view_total_amount" readonly></div>
          <div class="col-md-6 mb-3"><label class="form-label">VAT Percentage</label><input type="text" class="form-control" id="view_vat_percentage" readonly></div>
          <div class="col-md-6 mb-3"><label class="form-label">VAT Amount</label><input type="text" class="form-control" id="view_vat_amount" readonly></div>
          <div class="col-md-6 mb-3"><label class="form-label">Withholding Percentage</label><input type="text" class="form-control" id="view_with_holding_percentage" readonly></div>
          <div class="col-md-6 mb-3"><label class="form-label">Total Income After Withholding</label><input type="text" class="form-control" id="view_total_income_after_withholding_tax" readonly></div>

          <!-- Other Info -->
          <div class="col-md-6 mb-3"><label class="form-label">Payment Type</label><input type="text" class="form-control" id="view_payment_type" readonly></div>
          <div class="col-md-6 mb-3"><label class="form-label">Status</label><input type="text" class="form-control" id="view_status_master" readonly></div>
         <!--  <div class="col-12 mb-3"><label class="form-label">Remarks</label><textarea class="form-control" id="view_remarks" rows="2" readonly></textarea></div>
-->
          <div class="mb-3 mt-4" id="detailsListContainer" >
                </div>
 
          <!-- Agreement Linkage
          <div class="col-md-6 mb-3"><label class="form-label">Agreement ID</label><input type="text" class="form-control" id="view_agreement_id_ref" readonly></div>
         -->
        </div>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Delete Invoice Modal -->
<div class="modal fade" id="deletebuldingModal" tabindex="-1" aria-labelledby="deletebuldingModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form method="POST" action="<?php echo e(route('invoice.delete')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" id="delete_Agreement_Mapping_id">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="deletebuldingModalLabel">Confirm Invoice Deletion</h5>
                    <button type="button" class="btn-close text-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                
                <div class="modal-body text-center">
                    <p>Are you sure you want to delete <strong id="delete_Agreement_Mapping_name">Invoice</strong> from the system?</p>
                    <p>This action cannot be undone.</p>
                </div>
                
                <div class="modal-footer justify-content-center">
                    <button type="submit" class="btn btn-danger">Yes, Delete</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
            </div>
        </form>
    </div>
</div>



<!--Documents Invoice Modal -->
<div class="modal fade" id="documentModal" tabindex="-1" aria-labelledby="documentModal" aria-hidden="true">
    <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
        <h5 class="modal-title" id="documentModal">Documents Upload</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
                <div class="modal-body">  
        <form method="POST" action="<?php echo e(route('agreement.document.save')); ?>" enctype="multipart/form-data">

    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label class="form-label">Tenant</label>
        <select class="form-select" name="tenant_id" id="tenant_id" required>
            <option value="">Select Tenant</option>
            <?php $__currentLoopData = $tenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tenant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($tenant->TENANT_ID); ?>"><?php echo e($tenant->TENANT_NAME); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>


    
<div class="mb-3">
    <label class="form-label">Agreement Id</label>
    <select class="form-select" name="agreement_id" id="agreement_id" required>
        <option value="">Loading Agreements</option>
    </select>
</div>

        <div class="mb-3">
            <label class="form-label">Document Name</label>
            <input type="text" class="form-control" name="document_name" id="document_name" required>
    </div>

     <div class="mb-3">
        <label class="form-label">Document Upload</label>
        <input type="file" class="form-control" name="FILE" id="FILE">
    </div>

    <!-- Remarks -->
    <div class="mb-3">
        <label class="form-label">Remarks</label>
        <input type="text" class="form-control" name="remarks" maxlength="256">
    </div>

    <!-- Status -->
    <div class="mb-3">
        <label class="form-label">Status</label>
        <select class="form-select" name="status_master">
            <option value="YES" selected>Active</option>
            <option value="NO">Inactive</option>
        </select>
    </div>

    <div class="modal-footer mt-4">
        <button type="submit" class="btn btn-primary">Save Agreement</button>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
    </div>
</form>
                </div>
            </div>
    </div>
</div>


<?php echo $__env->make('layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<script>
    <?php if($errors->any()): ?>
        var editModal = new bootstrap.Modal(document.getElementById('editInvoiceModal'));
        editModal.show();
    <?php endif; ?>
</script>

<script>

document.addEventListener('DOMContentLoaded', function () {
    const tenantSelect = document.getElementById('tenant_id');

    if (tenantSelect) {
        tenantSelect.addEventListener('change', function () {
            const tenantId = tenantSelect.value;

            if (tenantId) {
                console.log('🔄 Tenant changed:', tenantId);

                fetch(`/get-tenant-details?tenant_id=${tenantId}`, {
                    method: 'GET',
                    headers: { 'Accept': 'application/json' }
                })
                .then(response => response.json())
                .then(result => {
                    const mapping = result.data?.[0];
                    console.log('✅ Mapping received:', mapping);

                    if (!mapping) {
                        console.warn("⚠️ No mapping data available.");
                        return;
                    }                  // Map response to form fields
document.getElementById('agreement_id').value = mapping.AGREEMENT_ID || '';
document.getElementById('building_id').value = mapping.BUILDING_ID || '';
document.getElementById('floor_id').value = mapping.FLOOR_ID || '';
document.getElementById('property_id').value = mapping.PROPERTY_ID || '';
document.getElementById('branch_id').value = mapping.BRANCH_ID || '';
document.getElementById('status_master').value = mapping.STATUS_MASTER || '';
   document.getElementById('due_id').value = mapping.DUE_ID || '';
   document.getElementById('due_month').value = mapping.DUE_MONTH || '';
   document.getElementById('due_year').value = mapping.DUE_YEAR || '';
   document.getElementById('due_amount').value = mapping.RENTAL_AMOUNT || '';
   document.getElementById('invoice_amount_with_vat').value = mapping.FINAL_RENT_AMOUNT_WITH_VAT || '';
   document.getElementById('total_amount').value = mapping.TOTAL_RENT_AMOUNT || '';
   const vatValue = parseFloat(mapping.VAT_PERCENTAGE) || 0;
document.getElementById('vat_percentage').value = vatValue.toFixed(2); // e.g. "0.00"
   document.getElementById('vat_amount').value = mapping.VAT_RENT_AMOUNT || '';
   document.getElementById('with_holding_percentage').value = mapping.WITH_HOLDING_TAX_PERCENTAGE || '';
   document.getElementById('total_income_after_withholding_tax').value = mapping.RENTAL_AMOUNT || '';
   document.getElementById('remarks').value = mapping.REMARKS || '';
 //  
   
 //Optional: set tenant ID again if needed
//document.getElementById('edit_tenant_id').value = tenantSelect.value || '';              

                    // You can now use mapping to update fields
                })
                .catch(error => {
                    console.error("🚨 Error fetching tenant details:", error);
                });
            } else {
                console.warn("⚠️ Tenant ID missing — request not sent.");
            }
        });
    }
});


</script>



<script>
    
document.addEventListener('DOMContentLoaded', function () {
    const branchSelect   = document.getElementById('branch_id');
    const buildingSelect = document.getElementById('building_id');
    const floorSelect    = document.getElementById('floor_id');
    const propertySelect = document.getElementById('property_id');

    floorSelect?.addEventListener('change', function () {
        const floorId   = floorSelect.value;
        const branchId  = branchSelect?.value;
        const buildingId = buildingSelect?.value;

        if (!branchId || !buildingId || !floorId) {
            console.warn("⚠️ One or more required fields are missing.");
            propertySelect.innerHTML = '<option value="">Select Property</option>';
            return;
        }

        console.log("📤 Requesting property for Branch:", branchId, "Building:", buildingId, "Floor:", floorId);

        fetch(`/load-property?branch_id=${encodeURIComponent(branchId)}&building_id=${encodeURIComponent(buildingId)}&floor_id=${encodeURIComponent(floorId)}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' }
        })
        .then(response => {
            if (!response.ok) throw new Error(`Server error: ${response.status}`);
            return response.json();
        })
        .then(result => {
            const properties = result.data || [];
            console.log("🏠 Properties received:", properties);

            // Populate property dropdown
            propertySelect.innerHTML = '<option value="">Select Property</option>';
            properties.forEach(p => {
                if (p.PROPERTY_ID && p.PROPERTY_NAME) {
                    const option = document.createElement('option');
                    option.value = p.PROPERTY_ID;
                    option.textContent = p.PROPERTY_NAME;
                    propertySelect.appendChild(option);
                }
            });
        })
        .catch(error => {
            console.error("🚨 Failed to load properties:", error);
            propertySelect.innerHTML = '<option value="">Select Property</option>';
        });
    });
});
</script>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const branchSelect   = document.getElementById('branch_id');
    const buildingSelect = document.getElementById('building_id');
    const floorSelect    = document.getElementById('floor_id');

    buildingSelect?.addEventListener('change', function () {
        const buildingId = this.value;
        const branchId   = branchSelect?.value;

        if (!branchId || !buildingId) {
            console.warn("⚠️ Missing branch or building ID.");
            floorSelect.innerHTML = '<option value="">Select Floor</option>';
            return;
        }

        console.log("📤 Fetching floors for Branch:", branchId, "and Building:", buildingId);

        fetch(`/load-floors?branch_id=${encodeURIComponent(branchId)}&building_id=${encodeURIComponent(buildingId)}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' }
        })
        .then(response => {
            if (!response.ok) throw new Error(`Server error: ${response.status}`);
            return response.json();
        })
        .then(result => {
            const floors = result.data || [];
            console.log("🏢 Floors received:", floors);

            // Clear and repopulate floor dropdown
            floorSelect.innerHTML = '<option value="">Select Floor</option>';
            floors.forEach(floor => {
                if (floor.FLOOR_ID && floor.FLOOR_NAME) {
                    const option = document.createElement('option');
                    option.value = floor.FLOOR_ID;
                    option.textContent = floor.FLOOR_NAME;
                    floorSelect.appendChild(option);
                }
            });
        })
        .catch(error => {
            console.error("🚨 Failed to load floors:", error);
            floorSelect.innerHTML = '<option value="">Select Floor</option>';
        });
    });
});
</script>


<script>
document.addEventListener('DOMContentLoaded', function () {
    const branchSelect = document.getElementById('branch_id');
    const buildingSelect = document.getElementById('building_id');

    branchSelect?.addEventListener('change', function () {
        const branchId = this.value;

        if (!branchId) {
            console.warn("⚠️ No branch selected.");
            buildingSelect.innerHTML = '<option value="">Select Building</option>';
            return;
        }

        console.log("📤 Fetching buildings for Branch ID:", branchId);

        fetch(`/load-buildings-by-branch?branch_id=${encodeURIComponent(branchId)}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' }
        })
        .then(response => {
            if (!response.ok) throw new Error(`Server error: ${response.status}`);
            return response.json();
        })
        .then(result => {
            const buildings = result.data || [];
            console.log("🏢 Buildings received:", buildings);

            // Clear and repopulate building dropdown
            buildingSelect.innerHTML = '<option value="">Select Building </option>';
            buildings.forEach(b => {
                if (b.BUILDING_ID && b.BUILDING_NAME) {
                    const option = document.createElement('option');
                    option.value = b.BUILDING_ID;
                    option.textContent = b.BUILDING_NAME;
                    buildingSelect.appendChild(option);
                }
            });
        })
        .catch(error => {
            console.error("🚨 Could not load buildings:", error);
            buildingSelect.innerHTML = '<option value=""> Select Building </option>';
        });
    });
});
</script>





<script>
document.addEventListener('DOMContentLoaded', function () {
    const branchSelect  = document.getElementById('branch_id');
    const tenantSelect  = document.getElementById('tenant_id');
    const propertyInput = document.getElementById('property_id');

    if (tenantSelect) {
        tenantSelect.addEventListener('change', function () {
            const tenantId   = tenantSelect?.value;
            const propertyId = propertyInput?.value;

            console.log("📦 Branch selected");
            console.log("📍 Tenant ID:", tenantId);
            console.log("🏠 Property ID:", propertyId);

            if (tenantId && propertyId) {
                fetch(`/agreement-id/${tenantId}/${propertyId}`, {
                    method: 'GET',
                    headers: { 'Accept': 'application/json' }
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`Server responded with ${response.status}`);
                    }
                    return response.json();
                })
                .then(data => {
                    console.log("✅ Agreement ID data received:", data);
                })
                .catch(error => {
                    console.error("🚨 Error fetching agreement ID:", error);
                });
            } else {
                console.warn("⚠️ Missing tenant or property ID, cannot fetch agreement ID.");
            }
        });
    }
});
</script>


<script>
document.addEventListener('DOMContentLoaded', function () {
    const paymentForSelect = document.getElementById('payment_for');

    if (!paymentForSelect) return;

    paymentForSelect.addEventListener('change', function () {
        const paymentFor = this.value;

        const branchId   = document.getElementById('branch_id')?.value;
        const tenantId   = document.getElementById('tenant_id')?.value;
        const buildingId = document.getElementById('building_id')?.value;
        const floorId    = document.getElementById('floor_id')?.value;
        const propertyId = document.getElementById('property_id')?.value;

        console.log('🔎 Selected:', { paymentFor, branchId, tenantId, buildingId, floorId, propertyId });

        if (paymentFor && branchId && tenantId && buildingId && floorId && propertyId) {
            fetch("<?php echo e(route('due.details')); ?>", {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                body: JSON.stringify({
                    payment_for: paymentFor,
                    branch_id: branchId,
                    tenant_id: tenantId,
                    building_id: buildingId,
                    floor_id: floorId,
                    property_id: propertyId
                })
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                console.log('📥 Response data:', data);

                if (Array.isArray(data) && data.length > 0) {
                    const due = data[0];

                    // Populate basic fields
                    document.querySelector('input[name="due_month"]').value = due.DUE_MONTH || '';
                    document.querySelector('input[name="due_year"]').value = due.DUE_YEAR || '';
                  document.querySelector('input[name="due_amount"]').value = due["DUE AMOUNT"] || '';

                    document.querySelector('input[name="due_id"]').value = due.DUE_ID || '';
                    document.querySelector('input[name="invoice_amount_with_vat"]').value = due.FINAL_PAYABLE_AMOUNT_WITH_VAT || '';
                    document.querySelector('input[name="vat_amount"]').value = due.Vat_Amount || '';

                    // Populate extended financials
                    document.querySelector('input[name="total_amount"]').value = due["Total amount"] || '';
                    document.querySelector('input[name="vat_percentage"]').value = due["VAT %"] || '';
                    document.querySelector('input[name="with_holding_percentage"]').value = due["WITH_HOLDING_TAX_PERCENTAGE"] || '';
                    document.querySelector('input[name="total_income_after_withholding_tax"]').value = due["TOTAL_INCOME_AFTER_WITH_HOLDING_TAX"] || '';

                    // Update the due ID select input if needed
                    const dueIdSelect = document.querySelector('select[name="due_id"]');
                    if (dueIdSelect && due.DUE_ID) {
                        dueIdSelect.innerHTML = '';
                        const option = new Option(`Due ${due.DUE_MONTH}/${due.DUE_YEAR}`, due.DUE_ID, true, true);
                        dueIdSelect.appendChild(option);
                    }
                } else {
                    console.warn('⚠️ No due details returned.');
                }
            })
            .catch(error => {
                console.error('🚨 Fetch error:', error);
            });
        } else {
            console.warn('⚠️ Missing required fields — cannot fetch due details.');
        }
    });
});
</script>



<script>
document.addEventListener('DOMContentLoaded', function () {
    const agreementTypeSelect = document.getElementById('agreement_type');
    const renewalGroup = document.getElementById('renewal_percentage');

    console.log(agreementTypeSelect)
    function toggleRenewalVisibility() {
        const type = agreementTypeSelect.value;
        if (type === 'NEW') {
            renewalGroup.style.display = 'none';
        } else {
            renewalGroup.style.display = 'block';
        }
    }

    // Initial check when modal loads
    toggleRenewalVisibility();

    // Check again whenever value changes
    agreementTypeSelect.addEventListener('change', toggleRenewalVisibility);

    
});
</script>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const buttons = document.querySelectorAll('.view-document-btn');
    const modalTitle = document.getElementById('documentPreviewModalLabel');
    const modalContent = document.getElementById('documentPreviewContent');

    buttons.forEach(button => {
        button.addEventListener('click', function () {
            const docName = this.getAttribute('data-doc-name') || 'Document';
            const filePath = this.getAttribute('data-file-path');
            const fileExt = filePath.split('.').pop().toLowerCase();

            modalTitle.textContent = docName;

            if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(fileExt)) {
                modalContent.innerHTML = `<img src="${filePath}" class="img-fluid" alt="${docName}" />`;
            } else if (fileExt === 'pdf') {
                // ✅ Use <embed> to avoid toolbar
                modalContent.innerHTML = `
                    <embed src="${filePath}" type="application/pdf" width="100%" height="600px" />
                `;
            } else {
                modalContent.innerHTML = `<p class="text-danger">Unsupported file type: ${fileExt}</p>`;
            }
        });
    });
});

</script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const editButtons = document.querySelectorAll('.edit-btn');

    editButtons.forEach(button => {
        button.addEventListener('click', function () {
            // Standard field mapping: data-key => input ID
            const fields = {
                invoice_id: 'edit_invoice_id',
                invoice_no: 'edit_invoice_no',
                invoice_date: 'edit_invoice_date',
                payment_for: 'edit_payment_for',
                tenant_id: 'edit_tenant_id',
                branch_id: 'edit_branch_id',
                building_id: 'edit_building_id',
                floor_id: 'edit_floor_id',
                property_id: 'edit_property_id',
                due_id: 'edit_due_id',
                due_month: 'edit_due_month',
                due_year: 'edit_due_year',
                due_amount: 'edit_due_amount',
                invoice_amount_with_vat: 'edit_invoice_amount_with_vat',
                total_amount: 'edit_total_amount',
                vat_percentage: 'edit_vat_percentage',
                vat_amount: 'edit_vat_amount',
                with_holding_percentage: 'edit_with_holding_percentage',
                total_income_after_withholding_tax: 'edit_total_income_after_withholding_tax',
                payment_type: 'edit_payment_type',
                remarks: 'edit_remarks',
                status_master: 'edit_status_master',
                agreement_id: 'edit_agreement_id'
            };

            // Populate standard fields
            Object.entries(fields).forEach(([dataKey, inputId]) => {
                const value = button.getAttribute(`data-${dataKey}`);
                if (inputId && value !== null) {
                    const inputField = document.getElementById(inputId);
                    if (inputField) inputField.value = value;
                }
            });

            // Populate display-only name fields
            const displayFields = {
                building_name: 'edit_building_name',
                floor_name: 'edit_floor_name',
                property_name: 'edit_property_name'
            };

            Object.entries(displayFields).forEach(([dataKey, inputId]) => {
                const value = button.getAttribute(`data-${dataKey}`);
                if (value !== null) {
                    const displayField = document.getElementById(inputId);
                    if (displayField) displayField.value = value;
                }
            });

            // Debugging log
            console.log("✅ Edit modal data loaded:", {
                invoice_id: button.getAttribute('data-invoice_id'),
                invoice_no: button.getAttribute('data-invoice_no'),
                building_name: button.getAttribute('data-building_name'),
                floor_name: button.getAttribute('data-floor_name'),
                property_name: button.getAttribute('data-property_name')
                // Add more keys if needed
            });
        });
    });
});
</script>


<script>


   document.addEventListener('DOMContentLoaded', function () {
    const deleteButtons = document.querySelectorAll('.delete-agreement-btn');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function () {
            const AgreementId = this.dataset.id;
            const AgreementName = this.dataset.name;

            document.getElementById('delete_Agreement_Mapping_id').value = AgreementId;
            document.getElementById('delete_Agreement_Mapping_name').textContent = AgreementName;
        });
    });
});





    document.addEventListener('DOMContentLoaded', function () {
        const branchSelect = document.getElementById('branch_id');
        const companySelect = document.getElementById('company_id');

        branchSelect.addEventListener('change', function () {
            const selectedOption = this.options[this.selectedIndex];
            const companyId = selectedOption.getAttribute('data-company');

            if (companyId) {
                companySelect.value = companyId;
            }
        });
    });



</script>
<script>
document.addEventListener('DOMContentLoaded', function () {
   
  const viewButtons = document.querySelectorAll('.view-btn');

  viewButtons.forEach(button => {
    button.addEventListener('click', function () {
         const data = this.dataset;
         console.log('id clicked is',data.invoice_id)
         LoadDetails(data.invoice_id);

    document.getElementById('view_tenant_id').value = data.tenant_id || '';
    document.getElementById('view_branch_id').value = data.branch_id || '';
      document.getElementById('view_building_id').value = data.building_name || '';
      document.getElementById('view_floor_id').value = data.floor_name || '';
      document.getElementById('view_property_id').value = data.property_name || '';

      const fields = {
        invoice_id: 'view_invoice_id',
        invoice_no: 'view_invoice_no',
        invoice_date: 'view_invoice_date',
        payment_for: 'view_payment_for',
       // tenant_id: 'view_tenant_id',
       // branch_id: 'view_branch_id',
       // building_id: 'view_building_id',
       // building_name: 'view_building_name', // Optional if needed
      //  floor_id: 'view_floor_id',
      //  floor_name: 'view_floor_name',
      //  property_id: 'view_property_id',
      //  property_name: 'view_property_name',
        due_id: 'view_due_id',
        due_month: 'view_due_month',
        due_year: 'view_due_year',
        due_amount: 'view_due_amount',
        invoice_amount_with_vat: 'view_invoice_amount_with_vat',
        total_amount: 'view_total_amount',
        vat_percentage: 'view_vat_percentage',
        vat_amount: 'view_vat_amount',
        with_holding_percentage: 'view_with_holding_percentage',
        total_income_after_withholding_tax: 'view_total_income_after_withholding_tax',
        payment_type: 'view_payment_type',
        remarks: 'view_remarks',
        status_master: 'view_status_master',
        agreement_id: 'view_agreement_id'
      };

    
      Object.entries(fields).forEach(([dataKey, fieldId]) => {
        const value = button.getAttribute(`data-${dataKey}`);
        const input = document.getElementById(fieldId);
        if (input) {
          input.tagName === 'TEXTAREA'
            ? input.textContent = value ?? ''
            : input.value = value ?? '';
        }
      });

     
      function LoadDetails(data) {
    fetch(`/LoadInvoiceDetails/${data}`)
        .then(response => response.json())
        .then(data => {
            console.log('Parsed document data:', data);

            const detailsListContainer = document.getElementById('detailsListContainer');
            detailsListContainer.innerHTML = ''; // Clear previous content

            if (Array.isArray(data) && data.length > 0) {
                // Start building the table
                let tableHTML = `
                <h3>Invoice Due Details</h3>
                    <table class="table table-bordered table-striped mt-3">
                        <thead>
                            <tr>
                                <th>Invoice ID</th>
                                  <th>Due ID</th>
                                    <th>Due Month</th>
                                      <th>Due Year</th>
                                        <th>Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                `;

                data.forEach(doc => {
                    const invoiceID = doc.INVOICE_ID || 'N/A';
                    const dueID = doc.DUE_ID || 'N/A';
                    const dueAmount = doc.DUE_MONTH || 'N/A';
                    const dueYear = doc.DUE_YEAR || 'N/A';
                    const amount = doc.AMOUNT || 'N/A';

                    tableHTML += `
                        <tr>
                            <td>${invoiceID}</td>
                            <td>${dueID}</td>
                            <td>${dueAmount}</td>
                            <td>${dueYear}</td>
                            <td>${amount}</td>
                        </tr>
                    `;
                });

                tableHTML += `
                        </tbody>
                    </table>
                `;

                detailsListContainer.innerHTML = tableHTML;
            } else {
                detailsListContainer.innerHTML = `<span class="text-muted fst-italic">No Details available</span>`;
            }
        })
        .catch(err => console.error('Error loading documents:', err));
}


      console.log("🔎 View modal populated:", {
        invoice_no: button.getAttribute('data-invoice_no'),
        invoice_date: button.getAttribute('data-invoice_date'),
        tenant_id: button.getAttribute('data-tenant_id')
        // Add more fields if needed
      });
    });
  });
});
</script>


<script>
document.addEventListener('DOMContentLoaded', function () {
    const branchSelect = document.getElementById('branch_id');

    branchSelect.addEventListener('change', function () {
        const branchId = this.value;
        console.log('Selected Branch ID:', branchId);

        if (branchId) {
            fetch(`/branch-details/${branchId}`)
                .then(response => {
                    console.log('Raw response:', response);
                    return response.json();
                })
                .then(data => {
                    console.log('Parsed data:', data);

                    if (data.length > 0) {
                        const item = data[0];

                        // Set visible fields (names)
                        document.getElementById('building_name').value = item.BUILDING_NAME || '';
                        document.getElementById('floor_name').value = item.FLOOR_NAME || '';
                        document.getElementById('property_name').value = item.PROPERTY_NAME || '';

                        // Set hidden fields (IDs)
                        document.getElementById('building_id').value = item.BUILDING_ID || '';
                        document.getElementById('floor_id').value = item.FLOOR_ID || '';
                        document.getElementById('property_id').value = item.PROPERTY_ID || '';
                    } else {
                        // Clear all
                        ['building_name', 'floor_name', 'property_name',
                         'building_id', 'floor_id', 'property_id'].forEach(id => {
                            document.getElementById(id).value = '';
                        });
                    }
                })
                .catch(err => console.error('Error loading branch details:', err));
        } else {
            // Clear all if no branch selected
            ['building_name', 'floor_name', 'property_name',
             'building_id', 'floor_id', 'property_id'].forEach(id => {
                document.getElementById(id).value = '';
            });
        }
    });
});

</script>

<script>
document.addEventListener('DOMContentLoaded', function () {
    var documentModal = document.getElementById('documentModal');

    if (!documentModal) {
        console.error('Modal element #documentModal not found!');
        return;
    }

    documentModal.addEventListener('shown.bs.modal', function () {
        console.log('Document Modal is opened');

        const tenantSelect = documentModal.querySelector('#tenant_id');
        const agreementSelect = documentModal.querySelector('#agreement_id');

        if (!tenantSelect) {
            console.error('Tenant select #tenant_id not found in modal!');
            return;
        }
        if (!agreementSelect) {
            console.error('Agreement select #agreement_id not found in modal!');
            return;
        }

        // Clear agreement dropdown every time modal opens
        agreementSelect.innerHTML = '<option value="">-- Select Agreement --</option>';

        // Remove existing change listener by cloning the node (clean slate)
        const newTenantSelect = tenantSelect.cloneNode(true);
        tenantSelect.parentNode.replaceChild(newTenantSelect, tenantSelect);

        console.log('Attaching change event listener to tenant select');

        newTenantSelect.addEventListener('change', function () {
            const tenantId = this.value;
            console.log('Tenant selected:', tenantId);

            if (tenantId) {
                fetch(`/agreements-by-tenant/${tenantId}`)
                    .then(response => {
                        console.log('Raw fetch response:', response);
                        return response.json();
                    })
                    .then(data => {
                        console.log('Parsed agreements data:', data);

                        agreementSelect.innerHTML = '<option value="">-- Select Agreement --</option>';

                        if (!data || data.length === 0) {
                            console.log('No agreements found for this tenant.');
                            agreementSelect.innerHTML = '<option value="">-- No agreements found --</option>';
                        } else {
                            data.forEach(agreement => {
                                console.log('Adding agreement option:', agreement);
                                const option = document.createElement('option');
                                option.value = agreement.AGREEMENT_ID;
                                option.text = agreement.AGREEMENT_NAME || `Agreement #${agreement.AGREEMENT_ID}`;
                                agreementSelect.appendChild(option);
                            });
                        }
                    })
                    .catch(err => {
                        console.error('Fetch error:', err);
                        agreementSelect.innerHTML = '<option value="">-- Error loading --</option>';
                    });
            } else {
                console.log('No tenant selected, clearing agreement dropdown.');
                agreementSelect.innerHTML = '<option value="">-- Select Agreement --</option>';
            }
        });

        // For debugging: show attached event listeners in console
        console.log('Event listeners on tenant select:', getEventListeners(newTenantSelect));
    });
});




</script>






</body>
</html><?php /**PATH C:\xampp\htdocs\RMS1\RMS1\RMS1\resources\views/Invoice/invoice.blade.php ENDPATH**/ ?>