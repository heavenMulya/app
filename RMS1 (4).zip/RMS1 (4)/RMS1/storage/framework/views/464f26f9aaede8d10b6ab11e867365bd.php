
<?php echo $__env->make('layout.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('layout.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('layout.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<div class="page-wrapper">
    <div class="content">
        <div class="page-header">
            <div class="page-title">
                <h4>Property List</h4>
                <h6>Manage your Property</h6>
            </div>

            <?php if(isset($message)): ?>
    <div id="session-alert" class="alert alert-<?php echo e($status === 'Error' ? 'danger' : 'success'); ?> alert-dismissible fade show"
         role="alert"
         style="position: fixed; top: 90px; right: 230px; z-index: 1055; min-width: 550px;">
        <?php echo e($message); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>

    <?php if($status !== 'Error'): ?>
        <script>
            // Auto dismiss success messages after 5 seconds
            setTimeout(function () {
                const alert = document.getElementById('session-alert');
                if (alert) {
                    alert.classList.remove('show');
                    alert.classList.add('fade');
                    setTimeout(() => alert.remove(), 1000);
                }
            }, 5000);
        </script>
    <?php endif; ?>
<?php endif; ?>
<div class="page-btn">
    <a href="javascript:void(0);" class="btn btn-added" data-bs-toggle="modal" data-bs-target="#addPropertyModal">
        <img src="assets/img/icons/plus.svg" alt="img" class="me-1">Add New Property
    </a>
</div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-top">
            <div class="search-set">
                <div class="search-path">
                    <a class="btn btn-filter" id="filter_search">
                        <img src="assets/img/icons/filter.svg" alt="img">
                        <span><img src="assets/img/icons/closes.svg" alt="img"></span>
                    </a>
                </div>
                <div class="search-input">
                    <a class="btn btn-searchset"><img src="assets/img/icons/search-white.svg" alt="img"></a>
                </div>
            </div>
            <div class="wordset">
                <ul>
                    <li><a data-bs-toggle="tooltip" data-bs-placement="top" title="PDF"><img src="assets/img/icons/pdf.svg" alt="PDF"></a></li>
                    <li><a data-bs-toggle="tooltip" data-bs-placement="top" title="Excel"><img src="assets/img/icons/excel.svg" alt="Excel"></a></li>
                    <li><a data-bs-toggle="tooltip" data-bs-placement="top" title="Print"><img src="assets/img/icons/printer.svg" alt="Print"></a></li>
                </ul>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table datanew">
                <thead>
                    <tr>
                        <th>
                            <label class="checkboxs">
                                <input type="checkbox" id="select-all">
                                <span class="checkmarks"></span>
                            </label>
                        </th>
                        <th>ID</th>
                        <th>Property Name</th>
                        <th>Size</th>
                        <th>Remarks</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <label class="checkboxs">
                                    <input type="checkbox">
                                    <span class="checkmarks"></span>
                                </label>
                            </td>
                            <td><?php echo e($item->PROPERTY_ID ?? 'N/A'); ?></td>
                            <td><a href="javascript:void(0);"><?php echo e($item->PROPERTY_NAME ?? 'N/A'); ?></a></td>
                            <td><?php echo e($item->PROPERTY_SIZE ?? 'N/A'); ?></td>
                            <td><?php echo e($item->REMARKS ?? ''); ?></td>
                            <td>
                                <?php if(strtolower($item->IS_ACTIVE) === 'active'): ?>
                                    <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <!-- View -->
                                <a href="javascript:void(0);"
                                class="me-2 view-property-btn"
                                data-bs-toggle="modal"
                                data-bs-target="#viewPropertyModal"
                                data-id="<?php echo e($item->PROPERTY_ID); ?>"
                                data-name="<?php echo e($item->PROPERTY_NAME); ?>"
                                data-size="<?php echo e($item->PROPERTY_SIZE); ?>"
                                data-remarks="<?php echo e($item->REMARKS); ?>"
                                data-status="<?php echo e($item->IS_ACTIVE); ?>"
                                data-company-id="<?php echo e($item->COMPANY_ID); ?>"
                                data-branch-id="<?php echo e($item->BRANCH_ID); ?>"
                                data-building-id="<?php echo e($item->BUILDING_ID); ?>"
                                data-floor-id="<?php echo e($item->FLOOR_ID); ?>"
                                data-property-type-id="<?php echo e($item->PROPERTY_TYPE_ID); ?>">
                                <img src="assets/img/icons/eye.svg" alt="View">
                               </a>



                                <!-- Edit -->
                                                                 <!-- Edit -->
                                <a class="me-2 edit-property-btn"
                                   href="javascript:void(0);"
                                   data-bs-toggle="modal"
                                   data-bs-target="#editPropertyModal"
                                   data-id="<?php echo e($item->PROPERTY_ID); ?>"
                                   data-name="<?php echo e($item->PROPERTY_NAME); ?>"
                                   data-size="<?php echo e($item->PROPERTY_SIZE); ?>"
                                   data-remarks="<?php echo e($item->REMARKS); ?>"
                                   data-status="<?php echo e($item->IS_ACTIVE); ?>"
                                   data-company-id="<?php echo e($item->COMPANY_ID); ?>"
                                   data-branch-id="<?php echo e($item->BRANCH_ID); ?>"
                                   data-building-id="<?php echo e($item->BUILDING_ID); ?>"
                                   data-floor-id="<?php echo e($item->FLOOR_ID); ?>"
                                   data-property-type-id="<?php echo e($item->PROPERTY_TYPE_ID); ?>">
                                   <img src="assets/img/icons/edit.svg" alt="Edit">
                                </a>
                                
                                <!-- Delete -->
                                 <a class="delete-property-btn confirm-text"
                                  href="javascript:void(0);"
                                  data-id="<?php echo e($item->PROPERTY_ID); ?>"
                                  data-name="<?php echo e($item->PROPERTY_NAME); ?>"
                                  data-bs-toggle="modal"
                                  data-bs-target="#deletePropertyModal">
                                  <img src="assets/img/icons/delete.svg" alt="Delete">
                                  </a>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div> <!-- .table-responsive -->
    </div> <!-- .card-body -->
</div> <!-- .card -->
</div> <!-- .content -->
</div> <!-- .page-wrapper -->


<!-- Add Property Modal -->
<div class="modal fade" id="addPropertyModal" tabindex="-1" aria-labelledby="addPropertyLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addPropertyLabel">Add New Property</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form method="POST" action="<?php echo e(route('property.save')); ?>">
          <?php echo csrf_field(); ?>
          <div class="row">
            <div class="col-md-6 mb-3">
              <label for="company_id" class="form-label">Company</label>
              <select class="form-select" name="company_id" id="company_id" required>
                <option value="">-- Select Company --</option>
                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($company->COMPANY_ID); ?>"><?php echo e($company->COMPANY_NAME); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="col-md-6 mb-3">
              <label for="branch_id" class="form-label">Branch</label>
              <select class="form-select" name="branch_id" id="branch_id" required>
                <option value="">-- Select Branch --</option>
                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($branch->BRANCH_ID); ?>"><?php echo e($branch->BRANCH_NAME); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="col-md-6 mb-3">
              <label for="building_id" class="form-label">Building</label>
              <select class="form-select" name="building_id" id="building_id" required>
                <option value="">-- Select Building --</option>
                <?php $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $building): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($building->BUILDING_ID); ?>"><?php echo e($building->BUILDING_NAME); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="col-md-6 mb-3">
              <label for="floor_id" class="form-label">Floor</label>
              <select class="form-select" name="floor_id" id="floor_id" required>
                <option value="">-- Select Floor --</option>
                <?php $__currentLoopData = $floors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $floor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($floor->FLOOR_ID); ?>"><?php echo e($floor->FLOOR_NAME); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
             <div class="col-md-6 mb-3">
              <label for="property_type_id" class="form-label">Property Type</label>
              <select class="form-select" name="property_type_id" id="property_type_id" required>
                <option value="">-- Select Property Type --</option>
                <?php $__currentLoopData = $propertyTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($type->PROPERTY_TYPE_ID); ?>"><?php echo e($type->PROPERTY_TYPE_NAME); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="col-md-6 mb-3">
              <label for="property_name" class="form-label">Property Name</label>
              <input type="text" class="form-control" name="property_name" id="property_name" required>
            </div>

            <div class="col-md-6 mb-3">
              <label for="property_size" class="form-label">Property Size</label>
              <input type="text" class="form-control" name="property_size" id="property_size">
            </div>

            <div class="col-md-6 mb-3">
              <label for="status_master" class="form-label">Status</label>
              <select class="form-select" name="status_master" id="status_master" required>
                <option value="ACTIVE" selected>Active</option>
                <option value="INACTIVE">Inactive</option>
              </select>
            </div>
            <div class="col-md-12 mb-3">
              <label for="remarks" class="form-label">Remarks</label>
              <input type="text" class="form-control" name="remarks" id="remarks">
            </div>
          </div>

          <!-- Hidden Fields -->
          <input type="hidden" name="created_by" value="<?php echo e($createdBy); ?>">
          <input type="hidden" name="mac_address" value="<?php echo e($macAddress); ?>">

          <div class="modal-footer">
            <button type="submit" class="btn btn-primary">Save</button>
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          </div>

        </form>
      </div>
    </div>
  </div>
</div>

<!-- Edit Property Modal -->

<div class="modal fade" id="editPropertyModal" tabindex="-1" aria-labelledby="editPropertyLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editPropertyLabel">Edit Property</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body">
        <form id="editPropertyForm" method="POST" action="<?php echo e(route('property.update')); ?>">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <input type="hidden" name="property_id" id="edit_property_id">

          <div class="row">
            <div class="col-md-6 mb-3">
              <label for="edit_company_id" class="form-label">Company</label>
              <select class="form-select" name="company_id" id="edit_company_id" required>
                <option value="">-- Select Company --</option>
                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($company->COMPANY_ID); ?>"><?php echo e($company->COMPANY_NAME); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_branch_id" class="form-label">Branch</label>
              <select class="form-select" name="branch_id" id="edit_branch_id" required>
                <option value="">-- Select Branch --</option>
                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($branch->BRANCH_ID); ?>"><?php echo e($branch->BRANCH_NAME); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_building_id" class="form-label">Building</label>
              <select class="form-select" name="building_id" id="edit_building_id" required>
                <option value="">-- Select Building --</option>
                <?php $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $building): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($building->BUILDING_ID); ?>"><?php echo e($building->BUILDING_NAME); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_floor_id" class="form-label">Floor</label>
              <select class="form-select" name="floor_id" id="edit_floor_id" required>
                <option value="">-- Select Floor --</option>
                <?php $__currentLoopData = $floors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $floor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($floor->FLOOR_ID); ?>"><?php echo e($floor->FLOOR_NAME); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_property_type_id" class="form-label">Property Type</label>
              <select class="form-select" name="property_type_id" id="edit_property_type_id" required>
                <option value="">-- Select Property Type --</option>
                <?php $__currentLoopData = $propertyTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($type->PROPERTY_TYPE_ID); ?>"><?php echo e($type->PROPERTY_TYPE_NAME); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_property_name" class="form-label">Property Name</label>
              <input type="text" class="form-control" name="property_name" id="edit_property_name" required>
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_property_size" class="form-label">Property Size</label>
              <input type="text" class="form-control" name="property_size" id="edit_property_size">
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_status_master" class="form-label">Status</label>
              <select class="form-select" name="status_master" id="edit_status_master" required>
                <option value="ACTIVE">Active</option>
                <option value="INACTIVE">Inactive</option>
              </select>
            </div>

            <div class="col-md-12 mb-3">
              <label for="edit_remarks" class="form-label">Remarks</label>
              <input type="text" class="form-control" name="remarks" id="edit_remarks">
            </div>
          </div>

          <!-- Hidden Fields -->
          <input type="hidden" name="created_by" value="<?php echo e($createdBy); ?>">
          <input type="hidden" name="mac_address" value="<?php echo e($macAddress); ?>">

          <div class="modal-footer">
            <button type="submit" class="btn btn-primary">Update</button>
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- View Property Modal -->

<div class="modal fade" id="viewPropertyModal" tabindex="-1" aria-labelledby="viewPropertyLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="viewPropertyLabel">View Property</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body">
        <form id="viewPropertyForm">
          <div class="row">
            <div class="col-md-6 mb-3">
              <label class="form-label">Company</label>
              <select class="form-select" id="view_company_id" disabled>
                <option value="">-- Select Company --</option>
                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($company->COMPANY_ID); ?>"><?php echo e($company->COMPANY_NAME); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="col-md-6 mb-3">
              <label class="form-label">Branch</label>
              <select class="form-select" id="view_branch_id" disabled>
                <option value="">-- Select Branch --</option>
                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($branch->BRANCH_ID); ?>"><?php echo e($branch->BRANCH_NAME); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="col-md-6 mb-3">
              <label class="form-label">Building</label>
              <select class="form-select" id="view_building_id" disabled>
                <option value="">-- Select Building --</option>
                <?php $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $building): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($building->BUILDING_ID); ?>"><?php echo e($building->BUILDING_NAME); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="col-md-6 mb-3">
              <label class="form-label">Floor</label>
              <select class="form-select" id="view_floor_id" disabled>
                <option value="">-- Select Floor --</option>
                <?php $__currentLoopData = $floors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $floor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($floor->FLOOR_ID); ?>"><?php echo e($floor->FLOOR_NAME); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="col-md-6 mb-3">
              <label class="form-label">Property Type</label>
              <select class="form-select" id="view_property_type_id" disabled>
                <option value="">-- Select Property Type --</option>
                <?php $__currentLoopData = $propertyTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($type->PROPERTY_TYPE_ID); ?>"><?php echo e($type->PROPERTY_TYPE_NAME); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="col-md-6 mb-3">
              <label class="form-label">Property Name</label>
              <input type="text" class="form-control" id="view_property_name" disabled>
            </div>

            <div class="col-md-6 mb-3">
              <label class="form-label">Property Size</label>
              <input type="text" class="form-control" id="view_property_size" disabled>
            </div>

            <div class="col-md-6 mb-3">
              <label class="form-label">Status</label>
              <select class="form-select" id="view_status_master" disabled>
                <option value="ACTIVE">Active</option>
                <option value="INACTIVE">Inactive</option>
              </select>
            </div>

            <div class="col-md-12 mb-3">
              <label class="form-label">Remarks</label>
              <input type="text" class="form-control" id="view_remarks" disabled>
            </div>
          </div>

          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>


<!-- Delete Tenant Modal -->

 <div class="modal fade" id="deletePropertyModal" tabindex="-1" aria-labelledby="deletePropertyLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form method="POST" action="<?php echo e(route('property.delete')); ?>">
      <?php echo csrf_field(); ?>
      <?php echo method_field('DELETE'); ?>
      <input type="hidden" name="property_id" id="delete_property_id">

      <div class="modal-content">
        <div class="modal-header bg-danger text-white">
          <h5 class="modal-title" id="deletePropertyLabel">Confirm Property Deletion</h5>
          <button type="button" class="btn-close text-white" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body text-center">
          <p>Are you sure you want to delete <strong id="delete_property_name">Property XYZ</strong> from the system?</p>
          <p>This action cannot be undone.</p>
        </div>
        <div class="modal-footer justify-content-center">
          <button type="submit" class="btn btn-danger">Yes, Delete</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        </div>
      </div>
    </form>
  </div>
</div>


<?php echo $__env->make('layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>




<script>
    //edit property
document.addEventListener('DOMContentLoaded', function () {
  const editButtons = document.querySelectorAll('.edit-property-btn');
  editButtons.forEach(button => {
    button.addEventListener('click', function () {
      // Basic fields
      document.getElementById('edit_property_id').value = this.dataset.id || '';
      document.getElementById('edit_property_name').value = this.dataset.name || '';
      document.getElementById('edit_property_size').value = this.dataset.size || '';
      document.getElementById('edit_remarks').value = this.dataset.remarks || '';
      document.getElementById('edit_status_master').value = this.dataset.status || '';

      // Dropdowns
      document.getElementById('edit_company_id').value = this.dataset.companyId || '';
      document.getElementById('edit_branch_id').value = this.dataset.branchId || '';
      document.getElementById('edit_building_id').value = this.dataset.buildingId || '';
      document.getElementById('edit_floor_id').value = this.dataset.floorId || '';
      document.getElementById('edit_property_type_id').value = this.dataset.propertyTypeId || '';
    });
  });
});



//view property

  // Trigger when "view" button is clicked
  document.querySelectorAll('.view-property-btn').forEach(function (button) {
    button.addEventListener('click', function () {
      // Set values from data attributes
      document.getElementById('view_property_name').value = this.dataset.name || '';
      document.getElementById('view_property_size').value = this.dataset.size || '';
      document.getElementById('view_remarks').value = this.dataset.remarks || '';
      document.getElementById('view_status_master').value = this.dataset.status || '';

      // Set dropdowns
      setSelectValue('view_company_id', this.dataset.companyId);
      setSelectValue('view_branch_id', this.dataset.branchId);
      setSelectValue('view_building_id', this.dataset.buildingId);
      setSelectValue('view_floor_id', this.dataset.floorId);
      setSelectValue('view_property_type_id', this.dataset.propertyTypeId);
    });
  });
  // Helper function to select dropdown option by value
  function setSelectValue(selectId, value) {
    const select = document.getElementById(selectId);
    if (!select) return;
    [...select.options].forEach(opt => {
      opt.selected = (opt.value == value);
    });
  }
//delete btn

document.addEventListener('DOMContentLoaded', function () {
  const deleteButtons = document.querySelectorAll('.delete-property-btn');
  deleteButtons.forEach(button => {
    button.addEventListener('click', function () {
      const propertyId = this.dataset.id || '';
      const propertyName = this.dataset.name || '';
      document.getElementById('delete_property_id').value = propertyId;
      document.getElementById('delete_property_name').textContent = propertyName;
    });
  });
});




//loading data 


  $(document).ready(function () {
    // Load Branches when Company changes
    $('#company_id').on('change', function () {
      let companyId = $(this).val();
      resetDropdowns(['#branch_id', '#building_id', '#floor_id']);

      if (companyId) {
        $.ajax({
          url: '/load-branches/' + companyId,
          type: 'GET',
          success: function (data) {
            populateDropdown('#branch_id', data, 'BRANCH_ID', 'BRANCH_NAME');
          },
          error: function () {
            alert('Failed to load branches');
          }
        });
      }
    });

    // Load Buildings when Branch changes
    $('#branch_id').on('change', function () {
      let companyId = $('#company_id').val();
      let branchId = $(this).val();
      resetDropdowns(['#building_id', '#floor_id']);

      if (companyId && branchId) {
        $.ajax({
          url: '/load-buildings',
          type: 'POST',
          data: {
            company_id: companyId,
            branch_id: branchId,
            _token: '<?php echo e(csrf_token()); ?>'
          },
          success: function (data) {
            populateDropdown('#building_id', data, 'BUILDING_ID', 'BUILDING_NAME');
          },
          error: function () {
            alert('Failed to load buildings');
          }
        });
      }
    });

    // Load Floors when Building changes
    $('#building_id').on('change', function () {
      let companyId = $('#company_id').val();
      let branchId = $('#branch_id').val();
      let buildingId = $(this).val();
      resetDropdowns(['#floor_id']);

      if (companyId && branchId && buildingId) {
        $.ajax({
          url: '/load-floors',
          type: 'POST',
          data: {
            company_id: companyId,
            branch_id: branchId,
            building_id: buildingId,
            _token: '<?php echo e(csrf_token()); ?>'
          },
          success: function (data) {
            populateDropdown('#floor_id', data, 'id', 'FLOOR_NAME');
          },
          error: function () {
            alert('Failed to load floors');
          }
        });
      }
    });


    // Utility: Reset dependent dropdowns
    function resetDropdowns(selectors) {
      selectors.forEach(function (selector) {
        $(selector).html('<option value="">-- Select --</option>');
      });
    }

    // Utility: Populate dropdown with AJAX data
    function populateDropdown(selector, data, valueField, textField) {
      if (data.length === 0) {
        $(selector).html('<option value="">-- No Data Found --</option>');
      } else {
        let options = '<option value="">-- Select --</option>';
        $.each(data, function (index, item) {
          options += `<option value="${item[valueField]}">${item[textField]}</option>`;
        });
        $(selector).html(options);
      }
    }
  });
  

</script>
<?php /**PATH C:\xampp\htdocs\RMS1\RMS1\RMS1\resources\views/property/property.blade.php ENDPATH**/ ?>