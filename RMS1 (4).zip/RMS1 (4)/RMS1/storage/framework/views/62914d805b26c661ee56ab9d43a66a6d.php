
<?php echo $__env->make('layout.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->make('layout.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('layout.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>



<div class="page-wrapper">
    <div class="content">
        <div class="page-header">
            <div class="page-title">
                <h4>bulding List</h4>
                <h6>Manage your bulding</h6>
            </div>

            <?php if(isset($message)): ?>
                <div id="session-alert" class="alert alert-<?php echo e($status === 'Error' ? 'danger' : 'success'); ?> alert-dismissible fade show"
                     role="alert"
                     style="position: fixed; top: 90px; right: 230px; z-index: 1055; min-width: 550px;">
                    <?php echo e($message); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>

         
            <?php endif; ?>

            <div class="page-btn">
                <a href="javascript:void(0);" class="btn btn-added" data-bs-toggle="modal" data-bs-target="#addbuldingModal">
                    <img src="assets/img/icons/plus.svg" alt="img" class="me-1">Add New bulding
                </a>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="table-top">
                    <div class="search-set">
                        <div class="search-path">
                            <a class="btn btn-filter" id="filter_search">
                                <img src="assets/img/icons/filter.svg" alt="img">
                                <span><img src="assets/img/icons/closes.svg" alt="img"></span>
                            </a>
                        </div>
                        <div class="search-input">
                            <a class="btn btn-searchset"><img src="assets/img/icons/search-white.svg" alt="img"></a>
                        </div>
                    </div>
                    <div class="wordset">
                        <ul>
                            <li>
                                <a data-bs-toggle="tooltip" data-bs-placement="top" title="pdf">
                                    <img src="assets/img/icons/pdf.svg" alt="img">
                                </a>
                            </li>
                            <li>
                                <a data-bs-toggle="tooltip" data-bs-placement="top" title="excel">
                                    <img src="assets/img/icons/excel.svg" alt="img">
                                </a>
                            </li>
                            <li>
                                <a data-bs-toggle="tooltip" data-bs-placement="top" title="print">
                                    <img src="assets/img/icons/printer.svg" alt="img">
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="card mb-0" id="filter_inputs">
                    <div class="card-body pb-0">
                        <div class="row">
                            <div class="col-lg-12 col-sm-12">
                                <div class="row">
                                

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table datanew">
                        <thead>
                            <tr>
                                <th>
                                    <label class="checkboxs">
                                        <input type="checkbox" id="select-all">
                                        <span class="checkmarks"></span>
                                    </label>
                                </th>
                                <th>ID</th>
                                <th>bulding Name</th>
                                <th>bulding Address</th>
                                <th>Remarks</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $bulding; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <label class="checkboxs">
                                            <input type="checkbox">
                                            <span class="checkmarks"></span>
                                        </label>
                                    </td>
                                    <td><?php echo e($item->id ?? 'N/A'); ?></td>
                                    <td class="buldingimgname">
                                        <a href="javascript:void(0);"><?php echo e($item->BUILDING_NAME ?? 'N/A'); ?></a>
                                    </td>
                                    <td><?php echo e($item->BUILDING_ADDRESS ?? 'N/A'); ?></td>
                                    <td><?php echo e($item->Remarks ?? 'N/A'); ?></td>
                                    <td><?php echo e($item->STATUS_MASTER); ?></td>
                                    <td>
<a class="me-3" href="javascript:void(0);"
   data-id="<?php echo e($item->id); ?>"
   data-name="<?php echo e($item->BUILDING_NAME); ?>"
   data-company_id="<?php echo e($item->COMPANY_ID); ?>"
    data-branch_id="<?php echo e($item->BRANCH_ID); ?>"
   data-address="<?php echo e($item->BUILDING_ADDRESS); ?>"
   data-remarks="<?php echo e($item->Remarks); ?>"
   data-status="<?php echo e($item->STATUS_MASTER); ?>"
   data-bs-toggle="modal"
   data-bs-target="#viewbuldingModal">
    <img src="assets/img/icons/eye.svg" alt="View">
</a>


                                        <a class="me-3 edit-bulding-btn"
                                           href="javascript:void(0);"
                                           data-id="<?php echo e($item->id); ?>"
                                            data-name="<?php echo e($item->BUILDING_NAME); ?>"
                                           data-branch_id="<?php echo e($item->BRANCH_ID); ?>"
                                           data-company_id="<?php echo e($item->COMPANY_ID); ?>"
                                           data-address="<?php echo e($item->BUILDING_ADDRESS); ?>"
                                           data-remarks="<?php echo e($item->Remarks); ?>"
                                           data-status="<?php echo e($item->STATUS_MASTER); ?>"
                                           data-bs-toggle="modal"
                                           data-bs-target="#editbuldingModal">
                                            <img src="assets/img/icons/edit.svg" alt="Edit">
                                        </a>

                                        <a class="confirm-text delete-bulding-btn" href="javascript:void(0);" 
                                           data-id="<?php echo e($item->id); ?>" 
                                           data-name="<?php echo e($item->BUILDING_NAME); ?>" 
                                           data-bs-toggle="modal" 
                                           data-bs-target="#deletebuldingModal">
                                            <img src="assets/img/icons/delete.svg" alt="Delete">
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div> <!-- .table-responsive -->
            </div> <!-- .card-body -->
        </div> <!-- .card -->
    </div> <!-- .content -->
</div> <!-- .page-wrapper -->

<!-- Add bulding Modal -->
<div class="modal fade" id="addbuldingModal" tabindex="-1" aria-labelledby="addbuldingLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addbuldingLabel">Add New bulding</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="<?php echo e(route('bulding.save')); ?>">
                    <?php echo csrf_field(); ?>
                    
                 <!-- Building Name (Select Branch) -->
<div class="mb-3">
    <label for="branch_id" class="form-label">Building Name</label>
    <select class="form-select" name="branch_id" id="branch_id" required>
        <option value="">-- Select Branch --</option>
        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($branch->BRANCH_ID); ?>" data-company="<?php echo e($branch->COMPANY_ID); ?>">
                <?php echo e($branch->BRANCH_NAME); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<!-- Company Name (Auto-filled) -->
<div class="mb-3">
    <label for="company_id" class="form-label">Company Name</label>
    <select class="form-select" name="company_id" id="company_id" required>
        <option value="">-- Select Company --</option>
        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($company->COMPANY_ID); ?>"><?php echo e($company->COMPANY_NAME); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>




                    <div class="mb-3">
                        <label for="bulding_name" class="form-label">bulding Name</label>
                        <input type="text" class="form-control" name="bulding_name" id="bulding_name" required>
                    </div>

                    <div class="mb-3">
                        <label for="bulding_address" class="form-label">bulding Address</label>
                        <input type="text" class="form-control" name="bulding_address" id="bulding_address" required>
                    </div>

                    <div class="mb-3">
                        <label for="remarks" class="form-label">Remarks</label>
                        <input type="text" class="form-control" name="remarks" id="remarks">
                    </div>

                    <div class="mb-3">
                        <label for="status_master" class="form-label">Status</label>
                        <select class="form-select" name="status_master" id="status_master">
                            <option value="ACTIVE" selected>Active</option>
                            <option value="INACTIVE">Inactive</option>
                        </select>
                    </div>

                    <input type="hidden" name="created_by" value="<?php echo e($createdBy); ?>">
                    <input type="hidden" name="mac_address" value="<?php echo e($macAddress); ?>">

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Edit bulding Modal -->
<div class="modal fade" id="editbuldingModal" tabindex="-1" aria-labelledby="editbuldingLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editbuldingLabel">Edit bulding</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form id="editbuldingForm" method="POST" action="<?php echo e(route('bulding.update')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" id="edit_id">
                    
                                     <!-- Building Name (Select Branch) -->
<div class="mb-3">
    <label for="branch_id" class="form-label">Branch Name</label>
    <select class="form-select" name="branch_id" id="edit_branch_id" required>
        <option value="">-- Select Branch --</option>
        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($branch->BRANCH_ID); ?>" data-company="<?php echo e($branch->COMPANY_ID); ?>">
                <?php echo e($branch->BRANCH_NAME); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
                    <div class="mb-3">
                        <label for="edit_company_id" class="form-label">Company Name</label>
                        <select class="form-select" name="company_id" id="edit_company_id" required>
                            <option value="">-- Select Company --</option>
                            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($company->COMPANY_ID); ?>"><?php echo e($company->COMPANY_NAME); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="edit_bulding_name" class="form-label">bulding Name</label>
                        <input type="text" class="form-control" name="bulding_name" id="edit_bulding_name">
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_bulding_address" class="form-label">bulding Address</label>
                        <input type="text" class="form-control" name="bulding_address" id="edit_bulding_address">
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_remarks" class="form-label">Remarks</label>
                        <input type="text" class="form-control" name="remarks" id="edit_remarks">
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_status_master" class="form-label">Status</label>
                        <select class="form-select" name="status_master" id="edit_status_master">
                            <option value="ACTIVE">Active</option>
                            <option value="INACTIVE">Inactive</option>
                        </select>
                    </div>

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Update</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>



<!-- View bulding Modal -->
<div class="modal fade" id="viewbuldingModal" tabindex="-1" aria-labelledby="viewbuldingLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="viewbuldingLabel">bulding Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

       <div class="mb-3">
          <label class="form-label">Branch Name</label>
          <input type="text" class="form-control" id="view_branch_name" readonly>
        </div>
        <div class="mb-3">
          <label class="form-label">Company Name</label>
          <input type="text" class="form-control" id="view_company_name" readonly>
        </div>

        <div class="mb-3">
          <label class="form-label">bulding Name</label>
          <input type="text" class="form-control" id="view_bulding_name" readonly>
        </div>

        <div class="mb-3">
          <label class="form-label">bulding Address</label>
          <input type="text" class="form-control" id="view_bulding_address" readonly>
        </div>

        <div class="mb-3">
          <label class="form-label">Remarks</label>
          <input type="text" class="form-control" id="view_remarks" readonly>
        </div>

        <div class="mb-3">
          <label class="form-label">Status</label>
          <input type="text" class="form-control" id="view_status_master" readonly>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
</div>


<!-- Delete bulding Modal -->
<div class="modal fade" id="deletebuldingModal" tabindex="-1" aria-labelledby="deletebuldingLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form method="POST" action="<?php echo e(route('bulding.delete')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" id="delete_bulding_id">

            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="deletebuldingLabel">Confirm bulding Deletion</h5>
                    <button type="button" class="btn-close text-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    <p>Are you sure you want to delete <strong id="delete_bulding_name">bulding A102</strong> from the system?</p>
                    <p>This action cannot be undone.</p>
                </div>
                <div class="modal-footer justify-content-center">
                    <button type="submit" class="btn btn-danger">Yes, Delete</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
            </div>
        </form>
    </div>
</div>


<?php echo $__env->make('layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<script>
    <?php if($errors->any()): ?>
        var editModal = new bootstrap.Modal(document.getElementById('editbuldingModal'));
        editModal.show();
    <?php endif; ?>
</script>


<script>
    document.addEventListener('DOMContentLoaded', function () {
        const editButtons = document.querySelectorAll('.edit-bulding-btn');
        editButtons.forEach(button => {
            button.addEventListener('click', function () {
                console.log("Edit clicked");

                document.getElementById('edit_id').value = this.dataset.id;
                document.getElementById('edit_bulding_name').value = this.dataset.name;
                document.getElementById('edit_company_id').value = this.dataset.company_id;
                document.getElementById('edit_bulding_address').value = this.dataset.address;
                document.getElementById('edit_remarks').value = this.dataset.remarks;
                document.getElementById('edit_status_master').value = this.dataset.status;
                document.getElementById('edit_branch_id').value = this.dataset.branch_id;
            });
        });

        document.getElementById('editbuldingForm').addEventListener('submit', function () {
            console.log('Form submitted');
        });
    });

    document.addEventListener('DOMContentLoaded', function () {
    const deleteButtons = document.querySelectorAll('.delete-bulding-btn');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function () {
            const buldingId = this.dataset.id;
            const buldingName = this.dataset.name;

            document.getElementById('delete_bulding_id').value = buldingId;
            document.getElementById('delete_bulding_name').textContent = buldingName;
        });
    });
});



document.addEventListener('DOMContentLoaded', function () {
    const viewButtons = document.querySelectorAll('[data-bs-target="#viewbuldingModal"]');
    viewButtons.forEach(button => {
        button.addEventListener('click', function () {
            const companyId = this.dataset.company_id;
            const branchId = this.dataset.branch_id;
            const companyName = [...document.querySelectorAll('#company_id option, #edit_company_id option')]
                .find(opt => opt.value == companyId)?.textContent || 'N/A';
   const branchName = [...document.querySelectorAll('#branch_id option, #edit_branch_id option')]
                .find(opt => opt.value == branchId)?.textContent || 'N/A';
            document.getElementById('view_company_name').value = companyName;
            document.getElementById('view_bulding_name').value = this.dataset.name;
            document.getElementById('view_bulding_address').value = this.dataset.address;
            document.getElementById('view_remarks').value = this.dataset.remarks;
             document.getElementById('view_branch_name').value = branchName.trim();
            document.getElementById('view_status_master').value = this.dataset.status;
        });
    });
});


    document.addEventListener('DOMContentLoaded', function () {
        const branchSelect = document.getElementById('branch_id');
        const companySelect = document.getElementById('company_id');
        branchSelect.addEventListener('change', function () {
            const selectedOption = this.options[this.selectedIndex];
            const companyId = selectedOption.getAttribute('data-company');
            if (companyId) {
                companySelect.value = companyId;
            }
        });
    });



</script>



</body>
</html><?php /**PATH C:\xampp\htdocs\RMS1\RMS1\RMS1\resources\views/bulding/bulding.blade.php ENDPATH**/ ?>