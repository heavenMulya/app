<?php echo $__env->make('layout.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('layout.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('layout.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="page-wrapper">
    <div class="content">
        <!-- Main User List View -->
        <div id="userListView" class="view-section">
            <div class="page-header">
                <div class="page-title">
                    <h4>User List</h4>
                    <h6>User Management</h6>
                </div>

                <?php if(isset($message) && !session('show_edit_view')): ?>
                    <div id="session-alert" class="alert alert-<?php echo e($status === 'Error' ? 'danger' : 'success'); ?> alert-dismissible fade show"
                         role="alert"
                         style="position: fixed; top: 90px; right: 230px; z-index: 1055; min-width: 550px;">
                        <?php echo e($message); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>


                <?php endif; ?>

                <div class="page-btn">
                    <button type="button" class="btn btn-added" onclick="showAddUserView()">
                        <img src="assets/img/icons/plus.svg" alt="img" class="me-1">Add User
                    </button>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table datanew">
                            <thead>
                                <tr>
                                    <th><input type="checkbox" id="select-all"></th>
                                    <th>ID</th>
                                    <th>User Name</th>
                                    <th>User Type</th>
                                    <th>Email</th>
                                    <th>Mobile No</th>
                                    <th>Remarks</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><input type="checkbox"></td>
                                        <td><?php echo e($item->id); ?></td>
                                        <td><?php echo e($item->USERNAME); ?></td>
                                        <td><?php echo e($item->USER_TYPE); ?></td>
                                        <td><?php echo e($item->EMAIL); ?></td>
                                        <td><?php echo e($item->MOBILE_NO); ?></td>
                                        <td><?php echo e($item->Remarks); ?></td>
                                        <td><?php echo e($item->IS_ACTIVE); ?></td>
                                        <td>
                                            <button type="button" class="btn btn-sm btn-outline-primary me-1" 
                                                    onclick="showViewUser('<?php echo e($item->id); ?>', '<?php echo e($item->USERNAME); ?>', '<?php echo e($item->USER_TYPE); ?>', '<?php echo e($item->EMAIL); ?>', '<?php echo e($item->MOBILE_NO); ?>', '<?php echo e($item->Remarks); ?>', '<?php echo e($item->IS_ACTIVE); ?>')">
                                                <img src="assets/img/icons/eye.svg" alt="View" width="16">
                                            </button>
                                            <button type="button" class="btn btn-sm btn-outline-warning me-1" 
                                                    onclick="showEditUser('<?php echo e($item->id); ?>', '<?php echo e($item->USERNAME); ?>', '<?php echo e($item->USER_TYPE); ?>', '<?php echo e($item->EMAIL); ?>', '<?php echo e($item->MOBILE_NO); ?>', '<?php echo e($item->Remarks); ?>', '<?php echo e($item->IS_ACTIVE); ?>')">
                                                <img src="assets/img/icons/edit.svg" alt="Edit" width="16">
                                            </button>
                                            <button type="button" class="btn btn-sm btn-outline-danger" 
                                                    onclick="showDeleteUserModal('<?php echo e($item->id); ?>', '<?php echo e($item->USERNAME); ?>')">
                                                <img src="assets/img/icons/delete.svg" alt="Delete" width="16">
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Add User View -->
        <div id="addUserView" class="view-section" style="display: none;">
            <div class="page-header">
                <div class="page-title">
                    <h4>Add New User</h4>
                    <h6>Create a new user account</h6>
                </div>
                <div class="page-btn">
                    <button type="button" class="btn btn-secondary" onclick="showUserListView()">
                        <i class="fas fa-arrow-left me-1"></i>Back to List
                    </button>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('user.save')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="role_name" class="form-label">Role Name *</label>
                                    <select class="form-select" id="role_name" name="role_name" required>
                                        <option value="">Select Role</option>
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($role->ROLE_NAME); ?>"><?php echo e($role->ROLE_NAME); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="user_name" class="form-label">User Name *</label>
                                    <input type="text" class="form-control" name="user_name" id="user_name" required>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="user_password" class="form-label">Password *</label>
                                    <input type="password" class="form-control" name="user_password" id="user_password" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="email_address" class="form-label">Email *</label>
                                    <input type="email" class="form-control" name="email_address" id="email_address" required>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="mobile_number" class="form-label">Mobile *</label>
                                    <input type="text" class="form-control" name="mobile_number" id="mobile_number" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="status_master" class="form-label">Status *</label>
                                    <select class="form-select" name="status_master" id="status_master" required>
                                        <option value="">-- Select Status --</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="mb-3">
                                    <label for="remarks" class="form-label">Remarks</label>
                                    <textarea class="form-control" name="remarks" id="remarks" rows="3"></textarea>
                                </div>
                            </div>
                        </div>

                        <input type="hidden" name="created_by" value="<?php echo e($createdBy); ?>">
                        <input type="hidden" name="mac_address" value="<?php echo e($macAddress); ?>">

                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary me-2">Save User</button>
                            <button type="button" class="btn btn-secondary" onclick="showUserListView()">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Edit User View -->
        <div id="editUserView" class="view-section" style="display: none;">
            <div class="page-header">
                <div class="page-title">
                    <h4>Edit User</h4>
                    <h6>Update user information</h6>
                </div>
                <div class="page-btn">
                    <button type="button" class="btn btn-secondary" onclick="showUserListView()">
                        <i class="fas fa-arrow-left me-1"></i>Back to List
                    </button>
                </div>
            </div>

            <!-- Success message for edit view -->
            <?php if(isset($message) && session('show_edit_view')): ?>
                <div id="edit-success-alert" class="alert alert-<?php echo e($status === 'Error' ? 'danger' : 'success'); ?> alert-dismissible fade show mb-3"
                     role="alert">
                    <i class="fas fa-check-circle me-2"></i><?php echo e($message); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>

                <script>
                    setTimeout(function () {
                        const alert = document.getElementById('edit-success-alert');
                        if (alert) {
                            alert.classList.remove('show');
                            alert.classList.add('fade');
                            setTimeout(() => alert.remove(), 500);
                        }
                    }, 8000); // Show for 8 seconds
                </script>
            <?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('user.update')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" id="edit_id">
                        <input type="hidden" name="stay_on_edit" value="1">
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="edit_role_name" class="form-label">Role Name *</label>
                                    <select class="form-select" name="role_name" id="edit_role_name" required>
                                        <option value="">Select Role</option>
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($role->ROLE_NAME); ?>"><?php echo e($role->ROLE_NAME); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="edit_user_name" class="form-label">User Name *</label>
                                    <input type="text" class="form-control" name="user_name" id="edit_user_name" required>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="edit_user_password" class="form-label">Password</label>
                                    <input type="password" class="form-control" name="user_password" id="edit_user_password">
                                    <small class="form-text text-muted">Leave blank to keep current password</small>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="edit_email_address" class="form-label">Email *</label>
                                    <input type="email" class="form-control" name="email_address" id="edit_email_address" required>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="edit_mobile_number" class="form-label">Mobile *</label>
                                    <input type="text" class="form-control" name="mobile_number" id="edit_mobile_number" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="edit_status_master" class="form-label">Status *</label>
                                    <select class="form-select" name="status_master" id="edit_status_master" required>
                                        <option value="">-- Select Status --</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="mb-3">
                                    <label for="edit_remarks" class="form-label">Remarks</label>
                                    <textarea class="form-control" name="remarks" id="edit_remarks" rows="3"></textarea>
                                </div>
                            </div>
                        </div>

                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary me-2">
                                <i class="fas fa-save me-1"></i>Update User
                            </button>
                            <button type="button" class="btn btn-success me-2" onclick="showUserListView()">
                                <i class="fas fa-list me-1"></i>Back to User List
                            </button>
                            <button type="button" class="btn btn-secondary" onclick="resetEditForm()">
                                <i class="fas fa-undo me-1"></i>Reset Form
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- View User Details -->
        <div id="viewUserView" class="view-section" style="display: none;">
            <div class="page-header">
                <div class="page-title">
                    <h4>User Details</h4>
                    <h6>View user information</h6>
                </div>
                <div class="page-btn">
                    <button type="button" class="btn btn-secondary" onclick="showUserListView()">
                        <i class="fas fa-arrow-left me-1"></i>Back to List
                    </button>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">User Name</label>
                                <input type="text" class="form-control" id="view_username" readonly>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">User Type</label>
                                <input type="text" class="form-control" id="view_user_type" readonly>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Email</label>
                                <input type="text" class="form-control" id="view_email" readonly>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Mobile</label>
                                <input type="text" class="form-control" id="view_mobile" readonly>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Status</label>
                                <input type="text" class="form-control" id="view_status" readonly>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">User ID</label>
                                <input type="text" class="form-control" id="view_user_id" readonly>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="mb-3">
                                <label class="form-label">Remarks</label>
                                <textarea class="form-control" id="view_remarks" rows="3" readonly></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="button" class="btn btn-warning me-2" onclick="switchToEditFromView()">Edit User</button>
                        <button type="button" class="btn btn-secondary" onclick="showUserListView()">Back to List</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Delete User Modal -->
<div class="modal fade" id="deleteUserModal" tabindex="-1" aria-labelledby="deleteUserModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header border-0">
                <h5 class="modal-title" id="deleteUserModalLabel">
                    <i class="fas fa-exclamation-triangle text-warning me-2"></i>Delete User
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center py-4">
                <div class="mb-4">
                    <i class="fas fa-user-times fa-4x text-danger mb-3"></i>
                    <h4 class="mb-3">Are you sure?</h4>
                    <p class="mb-2">You are about to delete user:</p>
                    <p class="fs-5 fw-bold text-dark" id="delete_user_name_display"></p>
                    <p class="text-muted small">This action cannot be undone and will permanently remove the user from the system.</p>
                </div>
            </div>
            <div class="modal-footer border-0 justify-content-center">
                <form method="POST" action="<?php echo e(route('user.delete')); ?>" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" id="delete_user_id">
                    <button type="submit" class="btn btn-danger me-2">
                        <i class="fas fa-trash me-1"></i>Yes, Delete User
                    </button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-1"></i>Cancel
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<script>
// View switching functions with animations
function showUserListView() {
    hideAllViews();
    showViewWithAnimation('userListView');
}

function showAddUserView() {
    hideAllViews();
    showViewWithAnimation('addUserView');
    fetchCommonDropdown(9, data => populateDropdown(document.getElementById('status_master'), data, '-- Select Status --', 'ACTIVE'));
}

function showEditUser(id, username, userType, email, mobile, remarks, status) {
    hideAllViews();
    showViewWithAnimation('editUserView');
    
    // Store original data for reset functionality
    window.originalEditData = {id, username, userType, email, mobile, remarks, status};
    
    // Populate form fields
    populateEditForm(id, username, userType, email, mobile, remarks, status);
}

function populateEditForm(id, username, userType, email, mobile, remarks, status) {
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_role_name').value = userType;
    document.getElementById('edit_user_name').value = username;
    document.getElementById('edit_email_address').value = email;
    document.getElementById('edit_mobile_number').value = mobile;
    document.getElementById('edit_remarks').value = remarks;
    
    // Clear password field
    document.getElementById('edit_user_password').value = '';
    
    // Store current status and fetch dropdown
    window.currentEditStatus = status;
    fetchCommonDropdown(9, data => {
        populateDropdown(document.getElementById('edit_status_master'), data, '-- Select Status --');
        document.getElementById('edit_status_master').value = status;
    });
}

function resetEditForm() {
    const data = window.originalEditData;
    if (data) {
        populateEditForm(data.id, data.username, data.userType, data.email, data.mobile, data.remarks, data.status);
    }
}

function showViewUser(id, username, userType, email, mobile, remarks, status) {
    hideAllViews();
    showViewWithAnimation('viewUserView');
    
    // Populate view fields
    document.getElementById('view_user_id').value = id;
    document.getElementById('view_username').value = username;
    document.getElementById('view_user_type').value = userType;
    document.getElementById('view_email').value = email;
    document.getElementById('view_mobile').value = mobile;
    document.getElementById('view_remarks').value = remarks;
    document.getElementById('view_status').value = status;
    
    // Store data for potential edit switch
    window.currentViewData = {id, username, userType, email, mobile, remarks, status};
}

function showDeleteUserModal(id, username) {
    document.getElementById('delete_user_id').value = id;
    document.getElementById('delete_user_name_display').textContent = username;
    
    // Show modal with Bootstrap
    const modal = new bootstrap.Modal(document.getElementById('deleteUserModal'));
    modal.show();
}

function switchToEditFromView() {
    const data = window.currentViewData;
    if (data) {
        showEditUser(data.id, data.username, data.userType, data.email, data.mobile, data.remarks, data.status);
    }
}

function hideAllViews() {
    const views = ['userListView', 'addUserView', 'editUserView', 'viewUserView'];
    views.forEach(view => {
        const element = document.getElementById(view);
        if (element) {
            element.style.display = 'none';
            element.classList.remove('view-active');
        }
    });
}

function showViewWithAnimation(viewId) {
    const element = document.getElementById(viewId);
    if (element) {
        element.style.display = 'block';
        // Force reflow
        element.offsetHeight;
        element.classList.add('view-active');
    }
}

// Dropdown functions
function fetchCommonDropdown(id, callback = null) {
    fetch(`/common-dropdown/${id}`, {
        method: 'GET',
        headers: { 'Accept': 'application/json' }
    })
    .then(response => {
        if (!response.ok) throw new Error(`Server returned ${response.status}`);
        return response.json();
    })
    .then(data => {
        console.log(`✅ Data for Common ID ${id}:`, data);
        if (typeof callback === 'function') callback(data);
    })
    .catch(error => {
        console.error(`🚨 Error fetching Common ID ${id}:`, error);
    });
}

function populateDropdown(selectElement, dataArray, defaultLabel, defaultValue = null) {
    if (!selectElement || !Array.isArray(dataArray)) return;

    const currentValue = selectElement.value || defaultValue;
    selectElement.innerHTML = `<option value="">${defaultLabel}</option>`;

    dataArray.forEach(item => {
        if (item.ACTIVITY_NAME) {
            const option = document.createElement('option');
            option.value = item.ACTIVITY_NAME;
            option.textContent = item.ACTIVITY_NAME;
            if (item.ACTIVITY_NAME === currentValue) {
                option.selected = true;
            }
            selectElement.appendChild(option);
        }
    });

    console.log(`🎯 Status dropdown populated${defaultValue ? ` with default "${defaultValue}"` : ''}`);
}

// Handle form errors and edit view display
document.addEventListener('DOMContentLoaded', function () {
    <?php if($errors->any()): ?>
        showAddUserView();
    <?php endif; ?>
    
    <?php if(session('show_edit_view')): ?>
        // Show edit view with updated data
        <?php if(session('updated_user_data')): ?>
            const userData = <?php echo json_encode(session('updated_user_data'), 15, 512) ?>;
            // Use setTimeout to ensure DOM is fully loaded
            setTimeout(() => {
                showEditUser(
                    userData.id,
                    userData.username,
                    userData.user_type,
                    userData.email,
                    userData.mobile,
                    userData.remarks,
                    userData.status
                );
            }, 100);
        <?php endif; ?>
    <?php else: ?>
        // Show user list by default
        showUserListView();
    <?php endif; ?>
});
</script>

<style>
.view-section {
    opacity: 0;
    transform: translateX(30px);
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    display: none;
}

.view-section.view-active {
    opacity: 1;
    transform: translateX(0);
}

.form-actions {
    margin-top: 2rem;
    padding-top: 1rem;
    border-top: 1px solid #dee2e6;
}

.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
}

.btn-sm {
    padding: 0.25rem 0.5rem;
    border-radius: 0.25rem;
    transition: all 0.3s ease;
}

.btn-sm:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.alert i {
    display: block;
    margin-bottom: 1rem;
}

#edit-success-alert {
    border-left: 4px solid #28a745;
    background-color: #d4edda;
    border-color: #c3e6cb;
}

#edit-success-alert .fas {
    color: #28a745;
}

.form-actions .btn {
    min-width: 120px;
    transition: all 0.3s ease;
}

.form-actions .btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}

.card {
    transition: all 0.3s ease;
    border: none;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.card:hover {
    box-shadow: 0 4px 20px rgba(0,0,0,0.15);
}

.table-responsive {
    animation: fadeInUp 0.5s ease-out;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Modal Enhancements */
.modal-content {
    border: none;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
}

.modal-header {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-radius: 15px 15px 0 0;
}

.modal-body {
    padding: 2rem;
}

.modal-footer {
    background: #f8f9fa;
    border-radius: 0 0 15px 15px;
}

.modal .btn {
    transition: all 0.3s ease;
    border-radius: 8px;
    padding: 0.5rem 1.5rem;
}

.modal .btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}

.form-control, .form-select {
    transition: all 0.3s ease;
    border-radius: 8px;
}

.form-control:focus, .form-select:focus {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,123,255,0.2);
}

/* Page transition effects */
.page-wrapper {
    animation: fadeIn 0.5s ease-out;
}

@keyframes fadeIn {
    from {
        opacity: 0;
    }
    to {
        opacity: 1;
    }
}

/* Button hover effects */
.btn-added:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,123,255,0.3);
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .page-header {
        flex-direction: column;
        gap: 1rem;
    }
    
    .page-btn {
        width: 100%;
    }
    
    .form-actions .btn {
        width: 100%;
        margin-bottom: 0.5rem;
    }
    
    .view-section {
        transform: translateY(20px);
    }
    
    .view-section.view-active {
        transform: translateY(0);
    }
}

/* Loading animation for forms */
.form-control:focus, .form-select:focus {
    animation: inputFocus 0.3s ease;
}



   /* //===========================      */
   @keyframes inputFocus {
    0% {
        box-shadow: 0 0 0 0 rgba(0,123,255,0.5);
    }
    100% {
        box-shadow: 0 0 0 3px rgba(0,123,255,0.2);
    }
}

/* Status badge styling */
.status-badge {
    padding: 0.25rem 0.75rem;
    border-radius: 50px;
    font-size: 0.875rem;
    font-weight: 500;
}

.status-active {
    background-color: #d4edda;
    color: #155724;
}

.status-inactive {
    background-color: #f8d7da;
    color: #721c24;
}
</style><?php /**PATH C:\xampp\htdocs\RMS1\RMS1\RMS1\resources\views/user/user.blade.php ENDPATH**/ ?>