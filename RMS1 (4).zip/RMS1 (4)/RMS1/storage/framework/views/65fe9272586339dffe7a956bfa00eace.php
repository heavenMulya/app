

<div class="sidebar" id="sidebar">
<div class="sidebar-inner slimscroll">
<div id="sidebar-menu" class="sidebar-menu">
<ul>
<li class="active">
<a href="<?php echo e(url('/')); ?>"><i class="fa fa-home" style="font-size: 24px;"></i><span> Dashboard</span> </a>
</li>
<li class="submenu">
<a href="javascript:void(0);"><i class="fa fa-building" style="font-size: 24px;"></i>

<span>Master</span> <span class="menu-arrow"></span></a>
<ul>
<li><a href="<?php echo e(url('/user')); ?>">User</a></li>
<li><a href="<?php echo e(url('/company')); ?>">Company master</a></li>
<li><a href="<?php echo e(url('/branch')); ?>">Branch Master</a></li>
<li><a href="<?php echo e(url('/bulding')); ?>">Buildings Master</a></li>
<li><a href="<?php echo e(url('/floor')); ?>">Floor Master</a></li>
<li><a href="<?php echo e(url('/property')); ?>">Property Master</a></li>
<li><a href="<?php echo e(url('/pricesetting')); ?>">Price Setting Master</a></li>
<li><a href="<?php echo e(url('/rental-type')); ?>">Rental Type</a></li>

</ul>
</li>
<li class="submenu">
<a href="javascript:void(0);"><i class="fa fa-money-check-alt" style=" font-size: 24px;"></i><span>Tenant</span> <span class="menu-arrow"></span></a>
<ul>
<li><a href="<?php echo e(url('/tenant')); ?>">Tenant</a></li>
<li><a href="<?php echo e(url('/agreement')); ?>">Agreement Mapping</a></li>
</ul>
</li>


<li class="submenu">
<a href="javascript:void(0);"><i class="fa fa-money-check-alt" style=" font-size: 24px;"></i><span>Invoice</span> <span class="menu-arrow"></span></a>
<ul>
<li><a href="<?php echo e(url('/invoice')); ?>">View Invoice</a></li>
</ul>
</li>

<li class="">
<a href="javascript:void(0);"><i class="fa fa-file" style=" font-size: 24px;"></i><span>Reports</span></a>
</li>
<li class="">
<a href="javascript:void(0);"><i class="fa fa-cog" style=" font-size: 24px;"></i><span>Settings</span></a>
</li>
</ul>
</div>
</div>
</div>


<?php /**PATH C:\xampp\htdocs\RMS1\RMS1\RMS1\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>