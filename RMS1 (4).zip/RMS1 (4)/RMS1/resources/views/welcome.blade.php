
@include ('layout.header')

@include ('layout.navbar')
@include ('layout.sidebar')



<div class="page-wrapper">
    <div class="content">
        <div class="page-header">
           
<div class="modal fade left-side-modal" id="viewAgreementMappingModal" tabindex="-1" aria-labelledby="viewAgreementMappingLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <!-- Modal content here -->
    </div>
  </div>
</div>



</body>
</html>