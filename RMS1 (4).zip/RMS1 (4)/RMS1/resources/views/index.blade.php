@include ('layout.header')

@include ('layout.navbar')


@include ('layout.sidebar')

@include ('layout.main')

@include ('layout.footer')