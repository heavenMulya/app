@include ('layout.header')
@include ('layout.navbar')
@include ('layout.sidebar')

<div class="page-wrapper">
    <div class="content">
        <!-- Session Alert Modal -->
        <div class="modal fade" id="sessionAlertModal" tabindex="-1" aria-labelledby="sessionAlertModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header border-0">
                        <h5 class="modal-title" id="sessionAlertModalLabel">
                            <i class="fas fa-{{ $status === 'Error' ? 'exclamation-circle text-danger' : 'check-circle text-success' }} me-2"></i>
                            {{ $status === 'Error' ? 'Error' : 'Success' }}
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        
                        @if(isset($message))
             
                            {{ $message }}
                        @endif

                    </div>
                    <div class="modal-footer border-0">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Company List View -->
        <div id="companyListView" class="view-section">
            <div class="page-header">
                <div class="page-title">
                    <h4>Company List</h4>
                    <h6>Manage Companies</h6>
                </div>
                <div class="page-btn">
                    <button type="button" class="btn btn-added" onclick="showAddView()">
                        <img src="assets/img/icons/plus.svg" alt="img" class="me-1">Add New Company
                    </button>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="table-top">
                        <div class="search-set">
                            <div class="search-path">
                                <a class="btn btn-filter" id="filter_search">
                                    <img src="assets/img/icons/filter.svg" alt="img">
                                    <span><img src="assets/img/icons/closes.svg" alt="img"></span>
                                </a>
                            </div>
                            <div class="search-input">
                                <input type="text" id="companySearch" class="form-control" placeholder="Search companies...">
                                <a class="btn btn-searchset"><img src="assets/img/icons/search-white.svg" alt="img"></a>
                            </div>
                        </div>
                        <div class="wordset">
                            <ul>
                                <li>
                                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="Export to PDF">
                                        <img src="assets/img/icons/pdf.svg" alt="img">
                                    </a>
                                </li>
                                <li>
                                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="Export to Excel">
                                        <img src="assets/img/icons/excel.svg" alt="img">
                                    </a>
                                </li>
                                <li>
                                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="Print">
                                        <img src="assets/img/icons/printer.svg" alt="img">
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="card mb-0" id="filter_inputs" style="display: none;">
                        <div class="card-body pb-0">
                            <div class="row">
                                <div class="col-lg-4 col-sm-6">
                                    <div class="mb-3">
                                        <label for="filter_company_name" class="form-label">Company Name</label>
                                        <input type="text" class="form-control" id="filter_company_name" placeholder="Enter company name">
                                    </div>
                                </div>
                                <div class="col-lg-4 col-sm-6">
                                    <div class="mb-3">
                                        <label for="filter_contact_person" class="form-label">Contact Person</label>
                                        <input type="text" class="form-control" id="filter_contact_person" placeholder="Enter contact person">
                                    </div>
                                </div>
                                <div class="col-lg-4 col-sm-6">
                                    <div class="mb-3">
                                        <label for="filter_status" class="form-label">Status</label>
                                        <select class="form-select" id="filter_status">
                                            <option value="">All Statuses</option>
                                            <option value="YES">Active</option>
                                            <option value="NO">Inactive</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table datanew">
                            <thead>
                                <tr>
                                    <th>
                                        <label class="checkboxs">
                                            <input type="checkbox" id="select-all">
                                            <span class="checkmarks"></span>
                                        </label>
                                    </th>
                                    <th>ID</th>
                                    <th>Company Name</th>
                                    <th>Short Code</th>
                                    <th>Contact Person</th>
                                    <th>Email</th>
                                    <th>Mobile No</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($companies as $item)
                                    <tr>
                                        <td>
                                            <label class="checkboxs">
                                                <input type="checkbox">
                                                <span class="checkmarks"></span>
                                            </label>
                                        </td>
                                        <td>{{ $item->id }}</td>
                                        <td>{{ $item->Company }}</td>
                                        <td>{{ $item->ShortCode }}</td>
                                        <td>{{ $item->ContactPerson }}</td>
                                        <td>{{ $item->EMAIL }}</td>
                                        <td>{{ $item->MOBILE_NO }}</td>
                                        <td>
                                            <span class="status-badge status-{{ strtolower($item->STATUS_MASTER) }}">
                                                {{ $item->STATUS_MASTER }}
                                            </span>
                                        </td>
                                        <td>
                                            <a class="me-3" href="javascript:void(0);" onclick="showViewCompany({{ json_encode($item) }})">
                                                <img src="assets/img/icons/eye.svg" alt="View">
                                            </a>
                                            <a class="me-3 edit-company-btn" href="javascript:void(0);"
                                               data-id="{{ $item->id }}"
                                               data-company-name="{{ $item->Company }}"
                                               data-shortcode="{{ $item->ShortCode }}"
                                               data-currency-id="{{ $item->CURRENCY_ID }}"
                                               data-contact-person="{{ $item->ContactPerson }}"
                                               data-f-year-start="{{ $item->f_year_start }}"
                                               data-f-year-end="{{ $item->f_year_end }}"
                                               data-email="{{ $item->EMAIL }}"
                                               data-mobile-no="{{ $item->MOBILE_NO }}"
                                               data-status-master="{{ $item->STATUS_MASTER }}"
                                               onclick="showEditCompany(this)">
                                                <img src="assets/img/icons/edit.svg" alt="Edit">
                                            </a>
                                            <a class="confirm-text delete-company-btn" href="javascript:void(0);" onclick="showDeleteCompany({{ $item->id }}, '{{ $item->Company }}')">
                                                <img src="assets/img/icons/delete.svg" alt="Delete">
                                            </a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Add Company View -->
        <div id="addCompanyView" class="view-section" style="display: none;">
            <div class="page-header">
                <div class="page-title">
                    <h4>Add New Company</h4>
                    <h6>Create a new company record</h6>
                </div>
                <div class="page-btn">
                    <button type="button" class="btn btn-secondary" onclick="showListView()">
                        <img src="assets/img/icons/arrow-left.svg" alt="img" class="me-1">Back to Company List
                    </button>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <form method="POST" action="{{ route('company.save') }}">
                        @csrf
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="company_name" class="form-label">Company Name *</label>
                                    <input type="text" class="form-control" name="company_name" id="company_name" required>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="shortcode" class="form-label">Short Code *</label>
                                    <input type="text" class="form-control" name="shortcode" id="shortcode" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="currency_id" class="form-label">Currency *</label>
                                    <select class="form-select" name="currency_id" id="currency_id" required>
                                        <option value="">-- Select Currency --</option>
                                        @foreach ($currencies as $currency)
                                            <option value="{{ $currency->CURRENCY_ID }}">{{ $currency->CURRENCY_NAME }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="contact_person" class="form-label">Contact Person *</label>
                                    <input type="text" class="form-control" name="contact_person" id="contact_person" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="f_year_start" class="form-label">Financial Year Start Month *</label>
                                    <input type="text" class="form-control" name="f_year_start" id="f_year_start" required>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="f_year_end" class="form-label">Financial Year End Month *</label>
                                    <input type="text" class="form-control" name="f_year_end" id="f_year_end" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="email" class="form-label">Email *</label>
                                    <input type="email" class="form-control" name="email" id="email" required>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="mobile_no" class="form-label">Mobile Number *</label>
                                    <input type="text" class="form-control" name="mobile_no" id="mobile_no" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="remarks" class="form-label">Remarks</label>
                                    <input type="text" class="form-control" name="remarks" id="remarks">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="status_master" class="form-label">Status *</label>
                                    <select class="form-select" name="status_master" id="status_master" required>
                                        <option value="">-- Select Status --</option>
                                        @foreach ($statusies as $status)
                                            <option value="{{ $status->ACTIVITY_NAME }}">{{ $status->ACTIVITY_DESC }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="created_by" value="{{ $createdBy }}">
                        <input type="hidden" name="mac_address" value="{{ $macAddress }}">
                        <div class="form-actions mt-4">
                            <button type="submit" class="btn btn-primary me-2">
                                <img src="assets/img/icons/save.svg" alt="img" class="me-1">Save Company
                            </button>
                            <button type="button" class="btn btn-secondary" onclick="showListView()">
                                Cancel
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Edit Company View -->
        <div id="editCompanyView" class="view-section" style="display: none;">
            <div class="page-header">
                <div class="page-title">
                    <h4>Edit Company</h4>
                    <h6>Update company information</h6>
                </div>
                <div class="page-btn">
                    <button type="button" class="btn btn-secondary" onclick="showListView()">
                        <img src="assets/img/icons/arrow-left.svg" alt="img" class="me-1">Back to Company List
                    </button>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                    <form id="editCompanyForm" method="POST" action="{{ route('company.update') }}">
                        @csrf
                        <input type="hidden" name="id" id="edit_id">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="edit_company_name" class="form-label">Company Name *</label>
                                    <input type="text" class="form-control" name="company_name" id="edit_company_name" required>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="edit_shortcode" class="form-label">Short Code *</label>
                                    <input type="text" class="form-control" name="shortcode" id="edit_shortcode" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="edit_currency_id" class="form-label">Currency *</label>
                                    <select class="form-select" name="currency_id" id="edit_currency_id" required>
                                        <option value="">-- Select Currency --</option>
                                        @foreach ($currencies as $currency)
                                            <option value="{{ $currency->CURRENCY_ID }}">{{ $currency->CURRENCY_NAME }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="edit_contact_person" class="form-label">Contact Person *</label>
                                    <input type="text" class="form-control" name="contact_person" id="edit_contact_person" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="edit_f_year_start" class="form-label">Financial Year Start Month *</label>
                                    <input type="text" class="form-control" name="f_year_start" id="edit_f_year_start" required>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="edit_f_year_end" class="form-label">Financial Year End Month *</label>
                                    <input type="text" class="form-control" name="f_year_end" id="edit_f_year_end" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="edit_email" class="form-label">Email *</label>
                                    <input type="email" class="form-control" name="email" id="edit_email" required>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="edit_mobile_no" class="form-label">Mobile Number *</label>
                                    <input type="text" class="form-control" name="mobile_no" id="edit_mobile_no" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="remarks" class="form-label">Remarks</label>
                                    <input type="text" class="form-control" name="remarks" id="edit_remarks">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="edit_status_master" class="form-label">Status *</label>
                                    <select class="form-select" name="status_master" id="edit_status_master" required>
                                        <option value="">-- Select Status --</option>
                                        @foreach ($statusies as $status)
                                            <option value="{{ $status->ACTIVITY_NAME }}">{{ $status->ACTIVITY_DESC }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="form-actions mt-4">
                            <button type="submit" class="btn btn-primary me-2">
                                <img src="assets/img/icons/save.svg" alt="img" class="me-1">Update Company
                            </button>
                            <button type="button" class="btn btn-secondary" onclick="showListView()">
                                Cancel
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- View Company Details -->
        <div id="viewCompanyView" class="view-section" style="display: none;">
            <div class="page-header">
                <div class="page-title">
                    <h4>Company Details</h4>
                    <h6>View company information</h6>
                </div>
                <div class="page-btn">
                    <button type="button" class="btn btn-warning me-2" onclick="switchToEditFromView()">
                        <img src="assets/img/icons/edit.svg" alt="img" class="me-1">Edit Company
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="showListView()">
                        <img src="assets/img/icons/arrow-left.svg" alt="img" class="me-1">Back to Company List
                    </button>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label class="form-label">Company ID</label>
                                <input type="text" class="form-control" id="view_id" readonly>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label class="form-label">Company Name</label>
                                <input type="text" class="form-control" id="view_company_name" readonly>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label class="form-label">Short Code</label>
                                <input type="text" class="form-control" id="view_shortcode" readonly>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label class="form-label">Currency</label>
                                <input type="text" class="form-control" id="view_currency_name" readonly>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label class="form-label">Financial Year Start Month</label>
                                <input type="text" class="form-control" id="view_f_year_start" readonly>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label class="form-label">Financial Year End Month</label>
                                <input type="text" class="form-control" id="view_f_year_end" readonly>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label class="form-label">Contact Person</label>
                                <input type="text" class="form-control" id="view_contact_person" readonly>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label class="form-label">Email</label>
                                <input type="text" class="form-control" id="view_email" readonly>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label class="form-label">Mobile Number</label>
                                <input type="text" class="form-control" id="view_mobile_no" readonly>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label class="form-label">Status</label>
                                <input type="text" class="form-control" id="view_status_master" readonly>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Delete Company Confirmation -->
        <div class="modal fade" id="deleteCompanyModal" tabindex="-1" aria-labelledby="deleteCompanyModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header border-0">
                        <h5 class="modal-title" id="deleteCompanyModalLabel">
                            <i class="fas fa-exclamation-triangle text-warning me-2"></i>Delete Company
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body text-center py-4">
                        <div class="mb-4">
                            <i class="fas fa-trash fa-4x text-danger mb-3"></i>
                            <h4 class="mb-3">Are you sure?</h4>
                            <p class="mb-2">You are about to delete company:</p>
                            <p class="fs-5 fw-bold text-dark" id="delete_company_name"></p>
                            <p class="text-muted small">This action cannot be undone and will permanently remove the company from the system.</p>
                        </div>
                    </div>
                    <div class="modal-footer border-0 justify-content-center">
                        <form method="POST" action="{{ route('company.delete') }}" class="d-inline">
                            @csrf
                            <input type="hidden" name="id" id="delete_company_id">
                            <button type="submit" class="btn btn-danger me-2">
                                <i class="fas fa-trash me-1"></i>Yes, Delete Company
                            </button>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                <i class="fas fa-times me-1"></i>Cancel
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@include ('layout.footer')

<script>
    // Suppress all DataTables error alerts
    $.fn.dataTable.ext.errMode = 'none';

    let currentCompanyData = {};

    // View navigation functions
    function showListView() {
        hideAllViews();
        document.getElementById('companyListView').style.display = 'block';
        // Reinitialize DataTable if needed
        if ($.fn.DataTable.isDataTable('.datanew')) {
            $('.datanew').DataTable().draw();
        }
    }

    function showAddView() {
        hideAllViews();
        document.getElementById('addCompanyView').style.display = 'block';
        // Clear form
        document.querySelector('#addCompanyView form').reset();
    }

    function showEditCompany(element) {
        hideAllViews();
        document.getElementById('editCompanyView').style.display = 'block';

        // Retrieve data from data attributes
        const id = element.dataset.id || '';
        const companyName = element.dataset.companyName || '';
        const shortcode = element.dataset.shortcode || '';
        const currencyId = element.dataset.currencyId || '';
        const contactPerson = element.dataset.contactPerson || '';
        const fYearStart = element.dataset.fYearStart || '';
        const fYearEnd = element.dataset.fYearEnd || '';
        const email = element.dataset.email || '';
        const mobileNo = element.dataset.mobileNo || '';
        const statusMaster = element.dataset.statusMaster || '';

        // Populate form fields
        document.getElementById('edit_id').value = id;
        document.getElementById('edit_company_name').value = companyName;
        document.getElementById('edit_shortcode').value = shortcode;
        document.getElementById('edit_currency_id').value = currencyId;
        document.getElementById('edit_contact_person').value = contactPerson;
        document.getElementById('edit_f_year_start').value = fYearStart;
        document.getElementById('edit_f_year_end').value = fYearEnd;
        document.getElementById('edit_email').value = email;
        document.getElementById('edit_mobile_no').value = mobileNo;
        document.getElementById('edit_status_master').value = statusMaster;

        // Store data for potential switch to edit
        currentCompanyData = {
            id,
            Company: companyName,
            ShortCode: shortcode,
            CURRENCY_ID: currencyId,
            ContactPerson: contactPerson,
            f_year_start: fYearStart,
            f_year_end: fYearEnd,
            EMAIL: email,
            MOBILE_NO: mobileNo,
            STATUS_MASTER: statusMaster
        };
    }

    function showViewCompany(data) {
        hideAllViews();
        document.getElementById('viewCompanyView').style.display = 'block';
        
        // Get currency name
        const currencySelect = document.getElementById('currency_id');
        const currencyOption = Array.from(currencySelect.options).find(opt => opt.value == data.CURRENCY_ID);
        const currencyName = currencyOption ? currencyOption.textContent : 'N/A';
        
        // Populate view fields
        document.getElementById('view_id').value = data.id;
        document.getElementById('view_company_name').value = data.Company;
        document.getElementById('view_shortcode').value = data.ShortCode;
        document.getElementById('view_currency_name').value = currencyName;
        document.getElementById('view_f_year_start').value = data.f_year_start;
        document.getElementById('view_f_year_end').value = data.f_year_end;
        document.getElementById('view_contact_person').value = data.ContactPerson;
        document.getElementById('view_email').value = data.EMAIL;
        document.getElementById('view_mobile_no').value = data.MOBILE_NO;
        document.getElementById('view_status_master').value = data.STATUS_MASTER;
        
        // Store data for potential switch to edit
        currentCompanyData = data;
    }

    function showDeleteCompany(id, name) {
        hideAllViews();
        document.getElementById('delete_company_id').value = id;
        document.getElementById('delete_company_name').textContent = name;
        const modal = new bootstrap.Modal(document.getElementById('deleteCompanyModal'));
        modal.show();
    }

    function switchToEditFromView() {
        if (currentCompanyData) {
            showEditCompany(currentCompanyData);
        }
    }

    function hideAllViews() {
        const views = document.querySelectorAll('.view-section');
        views.forEach(view => view.style.display = 'none');
    }

    document.addEventListener('DOMContentLoaded', function () {
        // Initialize DataTable
        const dataTable = $('.datanew').DataTable({
            responsive: true,
            pageLength: 10,
            order: [[1, 'asc']],
            search: {
                caseInsensitive: true,
                return: true
            },
            columnDefs: [
                { orderable: false, targets: [0, 8] } // Disable sorting for checkbox and action columns
            ]
        });

        // Search input handling
        $('#companySearch').on('keyup', function () {
            dataTable.search(this.value).draw();
        });

        // Filter toggle
        $('#filter_search').on('click', function () {
            const filterInputs = $('#filter_inputs');
            filterInputs.toggle();
            $(this).find('span').toggle();
        });

        // Filter handling
        $('#filter_company_name, #filter_contact_person, #filter_status').on('change keyup', function () {
            const companyName = $('#filter_company_name').val();
            const contactPerson = $('#filter_contact_person').val();
            const status = $('#filter_status').val();

            dataTable.column(2).search(companyName).column(4).search(contactPerson).column(7).search(status).draw();
        });

        // Select all checkboxes
        $('#select-all').on('click', function () {
            const checked = this.checked;
            $('.datanew tbody input[type="checkbox"]').prop('checked', checked);
        });

        // Show session alert modal if message exists
        @if (isset($message))
            const sessionAlertModal = new bootstrap.Modal(document.getElementById('sessionAlertModal'));
            sessionAlertModal.show();
            setTimeout(() => {
                sessionAlertModal.hide();
            }, 5000);
        @endif

        // Show edit view if there are errors or session indicates edit view
        @if ($errors->any() || session('show_edit_view'))
            hideAllViews();
            document.getElementById('editCompanyView').style.display = 'block';
            @if (session('updated_company_data'))
                const companyData = @json(session('updated_company_data'));
                setTimeout(() => {
                    showEditCompany({
                        dataset: {
                            id: companyData.id,
                            companyName: companyData.Company,
                            shortcode: companyData.ShortCode,
                            currencyId: companyData.CURRENCY_ID,
                            contactPerson: companyData.ContactPerson,
                            fYearStart: companyData.f_year_start,
                            fYearEnd: companyData.f_year_end,
                            email: companyData.EMAIL,
                            mobileNo: companyData.MOBILE_NO,
                            statusMaster: companyData.STATUS_MASTER
                        }
                    });
                }, 100);
            @endif
        @else
            showListView();
        @endif
    });
</script>

<style>
.view-section {
    animation: fadeInUp 0.5s ease-out;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.table-top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
}

.search-set {
    display: flex;
    align-items: center;
    gap: 1rem;
}

.search-set input {
    width: 250px;
}

.status-badge {
    padding: 0.25rem 0.75rem;
    border-radius: 50px;
    font-size: 0.875rem;
    font-weight: 500;
}

.status-yes {
    background-color: #d4edda;
    color: #155724;
}

.status-no {
    background-color: #f8d7da;
    color: #721c24;
}

.modal-content {
    border: none;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
}

.modal-header {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-radius: 15px 15px 0 0;
}

.modal-body {
    padding: 2rem;
}

.modal-footer {
    background: #f8f9fa;
    border-radius: 0 0 15px 15px;
}

.modal .btn {
    transition: all 0.3s ease;
    border-radius: 8px;
    padding: 0.5rem 1.5rem;
}

.modal .btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}
</style>