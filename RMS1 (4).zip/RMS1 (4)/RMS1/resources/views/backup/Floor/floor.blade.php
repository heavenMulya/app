```blade
@include ('layout.header')
@include ('layout.navbar')
@include ('layout.sidebar')

<div class="page-wrapper">
    <div class="content">
        <!-- Main Floor List View -->
        <div id="floorListView" class="view-section">
            <div class="page-header">
                <div class="page-title">
                    <h4>Floor List</h4>
                    <h6>Floor Management</h6>
                </div>

                @if(isset($message) && !session('show_edit_view'))
                    <div id="session-alert" class="alert alert-{{ $status === 'Error' ? 'danger' : 'success' }} alert-dismissible fade show"
                         role="alert"
                         style="position: fixed; top: 90px; right: 230px; z-index: 1055; min-width: 550px;">
                        {{ $message }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>

       
                @endif

                <div class="page-btn">
                    <button type="button" class="btn btn-added" onclick="showAddFloorView()">
                        <img src="assets/img/icons/plus.svg" alt="img" class="me-1">Add Floor
                    </button>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table datanew">
                            <thead>
                                <tr>
                                    <th><input type="checkbox" id="select-all"></th>
                                    <th>ID</th>
                                    <th>Company</th>
                                    <th>Branch</th>
                                    <th>Building</th>
                                    <th>Floor Name</th>
                                    <th>Remarks</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($floors as $floor)
                                    <tr>
                                        <td><input type="checkbox"></td>
                                        <td>{{ $floor->id }}</td>
                                        <td>{{ $floor->COMPANY_NAME }}</td>
                                        <td>{{ $floor->BRANCH_NAME }}</td>
                                        <td>{{ $floor->BUILDING_NAME }}</td>
                                        <td>{{ $floor->FLOOR_NAME }}</td>
                                        <td>{{ $floor->Remarks ?? 'N/A' }}</td>
                                        <td>
                                            <span class="status-badge status-{{ strtolower($floor->IS_ACTIVE) }}">
                                                {{ $floor->IS_ACTIVE }}
                                            </span>
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-sm btn-outline-primary me-1" 
                                                    onclick="showViewFloor('{{ $floor->id }}', '{{ $floor->COMPANY_NAME }}', '{{ $floor->BRANCH_NAME }}', '{{ $floor->BUILDING_NAME }}', '{{ $floor->FLOOR_NAME }}', '{{ $floor->Remarks ?? '' }}', '{{ $floor->IS_ACTIVE }}')">
                                                <img src="assets/img/icons/eye.svg" alt="View" width="16">
                                            </button>
                                            <button type="button" class="btn btn-sm btn-outline-warning me-1" 
                                                    onclick="showEditFloor('{{ $floor->id }}', '{{ $floor->COMPANY_NAME }}', '{{ $floor->BRANCH_NAME }}', '{{ $floor->BUILDING_NAME }}', '{{ $floor->FLOOR_NAME }}', '{{ $floor->Remarks ?? '' }}', '{{ $floor->IS_ACTIVE }}')">
                                                <img src="assets/img/icons/edit.svg" alt="Edit" width="16">
                                            </button>
                                            <button type="button" class="btn btn-sm btn-outline-danger" 
                                                    onclick="showDeleteFloorModal('{{ $floor->id }}', '{{ $floor->FLOOR_NAME }}')">
                                                <img src="assets/img/icons/delete.svg" alt="Delete" width="16">
                                            </button>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Add Floor View -->
        <div id="addFloorView" class="view-section" style="display: none;">
            <div class="page-header">
                <div class="page-title">
                    <h4>Add New Floor</h4>
                    <h6>Create a new floor record</h6>
                </div>
                <div class="page-btn">
                    <button type="button" class="btn btn-secondary" onclick="showFloorListView()">
                        <i class="fas fa-arrow-left me-1"></i>Back to List
                    </button>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <form method="POST" action="{{ route('floor.save') }}">
                        @csrf
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="company_id" class="form-label">Company *</label>
                                    <select class="form-select" id="company_id" name="company_id" required>
                                        <option value="">Select Company</option>
                                        @foreach ($companies as $company)
                                            <option value="{{ $company->COMPANY_ID }}" {{ $selectedCompanyId == $company->COMPANY_ID ? 'selected' : '' }}>
                                                {{ $company->COMPANY_NAME }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="branch_id" class="form-label">Branch *</label>
                                    <select class="form-select" id="branch_id" name="branch_id" required>
                                        <option value="">Select Branch</option>
                                        @foreach ($branches as $branch)
                                            <option value="{{ $branch->BRANCH_ID }}" {{ $selectedBranchId == $branch->BRANCH_ID ? 'selected' : '' }}>
                                                {{ $branch->BRANCH_NAME }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="building_id" class="form-label">Building *</label>
                                    <select class="form-select" id="building_id" name="building_id" required>
                                        <option value="">Select Building</option>
                                        @foreach ($buildings as $building)
                                            <option value="{{ $building->BUILDING_ID }}">{{ $building->BUILDING_NAME }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="floor_name" class="form-label">Floor Name *</label>
                                    <input type="text" class="form-control" name="floor_name" id="floor_name" required>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="status_master" class="form-label">Status *</label>
                                    <select class="form-select" name="status_master" id="status_master" required>
                                        <option value="">-- Select Status --</option>
                                        <option value="ACTIVE">ACTIVE</option>
                                        <option value="INACTIVE">INACTIVE</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="remarks" class="form-label">Remarks</label>
                                    <textarea class="form-control" name="remarks" id="remarks" rows="3"></textarea>
                                </div>
                            </div>
                        </div>

                        <input type="hidden" name="created_by" value="{{ $createdBy }}">
                        <input type="hidden" name="mac_address" value="{{ $macAddress }}">

                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary me-2">Save Floor</button>
                            <button type="button" class="btn btn-secondary" onclick="showFloorListView()">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Edit Floor View -->
        <div id="editFloorView" class="view-section" style="display: none;">
            <div class="page-header">
                <div class="page-title">
                    <h4>Edit Floor</h4>
                    <h6>Update floor information</h6>
                </div>
                <div class="page-btn">
                    <button type="button" class="btn btn-secondary" onclick="showFloorListView()">
                        <i class="fas fa-arrow-left me-1"></i>Back to List
                    </button>
                </div>
            </div>

            @if(isset($message) && session('show_edit_view'))
                <div id="edit-success-alert" class="alert alert-{{ $status === 'Error' ? 'danger' : 'success' }} alert-dismissible fade show mb-3"
                     role="alert">
                    <i class="fas fa-check-circle me-2"></i>{{ $message }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>

                <script>
                    setTimeout(function () {
                        const alert = document.getElementById('edit-success-alert');
                        if (alert) {
                            alert.classList.remove('show');
                            alert.classList.add('fade');
                            setTimeout(() => alert.remove(), 500);
                        }
                    }, 8000);
                </script>
            @endif

            <div class="card">
                <div class="card-body">
                    <form method="POST" action="{{ route('floor.update') }}">
                        @csrf
                        <input type="hidden" name="floor_id" id="edit_floor_id">
                        <input type="hidden" name="stay_on_edit" value="1">
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="edit_company_id" class="form-label">Company *</label>
                                    <select class="form-select" name="company_id" id="edit_company_id" required>
                                        <option value="">Select Company</option>
                                        @foreach ($companies as $company)
                                            <option value="{{ $company->COMPANY_ID }}">{{ $company->COMPANY_NAME }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="edit_branch_id" class="form-label">Branch *</label>
                                    <select class="form-select" name="branch_id" id="edit_branch_id" required>
                                        <option value="">Select Branch</option>
                                        @foreach ($branches as $branch)
                                            <option value="{{ $branch->BRANCH_ID }}">{{ $branch->BRANCH_NAME }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="edit_building_id" class="form-label">Building *</label>
                                    <select class="form-select" name="building_id" id="edit_building_id" required>
                                        <option value="">Select Building</option>
                                        @foreach ($buildings as $building)
                                            <option value="{{ $building->BUILDING_ID }}">{{ $building->BUILDING_NAME }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="edit_floor_name" class="form-label">Floor Name *</label>
                                    <input type="text" class="form-control" name="floor_name" id="edit_floor_name" required>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="edit_status_master" class="form-label">Status *</label>
                                    <select class="form-select" name="status_master" id="edit_status_master" required>
                                        <option value="">-- Select Status --</option>
                                        <option value="ACTIVE">ACTIVE</option>
                                        <option value="INACTIVE">INACTIVE</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="edit_remarks" class="form-label">Remarks</label>
                                    <textarea class="form-control" name="remarks" id="edit_remarks" rows="3"></textarea>
                                </div>
                            </div>
                        </div>

                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary me-2">
                                <i class="fas fa-save me-1"></i>Update Floor
                            </button>
                            <button type="button" class="btn btn-success me-2" onclick="showFloorListView()">
                                <i class="fas fa-list me-1"></i>Back to Floor List
                            </button>
                            <button type="button" class="btn btn-secondary" onclick="resetEditForm()">
                                <i class="fas fa-undo me-1"></i>Reset Form
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- View Floor Details -->
        <div id="viewFloorView" class="view-section" style="display: none;">
            <div class="page-header">
                <div class="page-title">
                    <h4>Floor Details</h4>
                    <h6>View floor information</h6>
                </div>
                <div class="page-btn">
                    <button type="button" class="btn btn-secondary" onclick="showFloorListView()">
                        <i class="fas fa-arrow-left me-1"></i>Back to List
                    </button>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Floor ID</label>
                                <input type="text" class="form-control" id="view_floor_id" readonly>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Floor Name</label>
                                <input type="text" class="form-control" id="view_floor_name" readonly>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Company</label>
                                <input type="text" class="form-control" id="view_company_name" readonly>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Branch</label>
                                <input type="text" class="form-control" id="view_branch_name" readonly>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Building</label>
                                <input type="text" class="form-control" id="view_building_name" readonly>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Status</label>
                                <input type="text" class="form-control" id="view_status" readonly>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="mb-3">
                                <label class="form-label">Remarks</label>
                                <textarea class="form-control" id="view_remarks" rows="3" readonly></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="button" class="btn btn-warning me-2" onclick="switchToEditFromView()">Edit Floor</button>
                        <button type="button" class="btn btn-secondary" onclick="showFloorListView()">Back to List</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Delete Floor Modal -->
<div class="modal fade" id="deleteFloorModal" tabindex="-1" aria-labelledby="deleteFloorModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header border-0">
                <h5 class="modal-title" id="deleteFloorModalLabel">
                    <i class="fas fa-exclamation-triangle text-warning me-2"></i>Delete Floor
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center py-4">
                <div class="mb-4">
                    <i class="fas fa-trash fa-4x text-danger mb-3"></i>
                    <h4 class="mb-3">Are you sure?</h4>
                    <p class="mb-2">You are about to delete floor:</p>
                    <p class="fs-5 fw-bold text-dark" id="delete_floor_name_display"></p>
                    <p class="text-muted small">This action cannot be undone and will permanently remove the floor from the system.</p>
                </div>
            </div>
            <div class="modal-footer border-0 justify-content-center">
                <form method="POST" action="{{ route('floor.delete') }}" class="d-inline">
                    @csrf
                    <input type="hidden" name="floor_id" id="delete_floor_id">
                    <button type="submit" class="btn btn-danger me-2">
                        <i class="fas fa-trash me-1"></i>Yes, Delete Floor
                    </button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-1"></i>Cancel
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

@include ('layout.footer')
<script>
    // Suppress all DataTables error alerts
    $.fn.dataTable.ext.errMode = 'none';
</script>

<script>
// View switching functions with animations
function showFloorListView() {
    hideAllViews();
    showViewWithAnimation('floorListView');
}

function showAddFloorView() {
    hideAllViews();
    showViewWithAnimation('addFloorView');
    document.getElementById('status_master').value = 'ACTIVE'; // Default to ACTIVE
}

function showEditFloor(id, company_name, branch_name, building_name, floor_name, remarks, status) {
    hideAllViews();
    showViewWithAnimation('editFloorView');
    
    // Store original data for reset functionality
    window.originalEditData = {id, company_name, branch_name, building_name, floor_name, remarks, status};
    
    // Populate form fields
    populateEditForm(id, company_name, branch_name, building_name, floor_name, remarks, status);
}

function populateEditForm(id, company_name, branch_name, building_name, floor_name, remarks, status) {
    document.getElementById('edit_floor_id').value = id;
    document.getElementById('edit_floor_name').value = floor_name;
    document.getElementById('edit_remarks').value = remarks || '';
    document.getElementById('edit_status_master').value = status;
    
    // Populate dropdowns (matching by name, assuming IDs are fetched correctly by controller)
    document.querySelector(`#edit_company_id option`).selected = true; // Reset to default
    document.querySelector(`#edit_branch_id option`).selected = true; // Reset to default
    document.querySelector(`#edit_building_id option`).selected = true; // Reset to default
}

function resetEditForm() {
    const data = window.originalEditData;
    if (data) {
        populateEditForm(data.id, data.company_name, data.branch_name, data.building_name, data.floor_name, data.remarks, data.status);
    }
}

function showViewFloor(id, company_name, branch_name, building_name, floor_name, remarks, status) {
    hideAllViews();
    showViewWithAnimation('viewFloorView');
    
    // Populate view fields
    document.getElementById('view_floor_id').value = id;
    document.getElementById('view_floor_name').value = floor_name;
    document.getElementById('view_company_name').value = company_name;
    document.getElementById('view_branch_name').value = branch_name;
    document.getElementById('view_building_name').value = building_name;
    document.getElementById('view_remarks').value = remarks || '';
    document.getElementById('view_status').value = status;
    
    // Store data for potential edit switch
    window.currentViewData = {id, company_name, branch_name, building_name, floor_name, remarks, status};
}

function showDeleteFloorModal(id, floor_name) {
    document.getElementById('delete_floor_id').value = id;
    document.getElementById('delete_floor_name_display').textContent = floor_name;
    
    // Show modal with Bootstrap
    const modal = new bootstrap.Modal(document.getElementById('deleteFloorModal'));
    modal.show();
}

function switchToEditFromView() {
    const data = window.currentViewData;
    if (data) {
        showEditFloor(data.id, data.company_name, data.branch_name, data.building_name, data.floor_name, data.remarks, data.status);
    }
}

function hideAllViews() {
    const views = ['floorListView', 'addFloorView', 'editFloorView', 'viewFloorView'];
    views.forEach(view => {
        const element = document.getElementById(view);
        if (element) {
            element.style.display = 'none';
            element.classList.remove('view-active');
        }
    });
}

function showViewWithAnimation(viewId) {
    const element = document.getElementById(viewId);
    if (element) {
        element.style.display = 'block';
        element.offsetHeight; // Force reflow
        element.classList.add('view-active');
    }
}

// Handle form errors and edit view display
document.addEventListener('DOMContentLoaded', function () {
    @if ($errors->any())
        showAddFloorView();
    @endif
    
    @if(session('show_edit_view'))
        // Show edit view with updated data
        @if(session('updated_floor_data'))
            const floorData = @json(session('updated_floor_data'));
            setTimeout(() => {
                showEditFloor(
                    floorData.id,
                    floorData.company_name,
                    floorData.branch_name,
                    floorData.building_name,
                    floorData.floor_name,
                    floorData.remarks,
                    floorData.status
                );
            }, 100);
        @endif
    @else
        showFloorListView();
    @endif
});
</script>

<style>
.view-section {
    opacity: 0;
    transform: translateX(30px);
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    display: none;
}

.view-section.view-active {
    opacity: 1;
    transform: translateX(0);
}

.form-actions {
    margin-top: 2rem;
    padding-top: 1rem;
    border-top: 1px solid #dee2e6;
}

.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
}

.btn-sm {
    padding: 0.25rem 0.5rem;
    border-radius: 0.25rem;
    transition: all 0.3s ease;
}

.btn-sm:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.alert i {
    display: block;
    margin-bottom: 1rem;
}

#edit-success-alert {
    border-left: 4px solid #28a745;
    background-color: #d4edda;
    border-color: #c3e6cb;
}

#edit-success-alert .fas {
    color: #28a745;
}

.form-actions .btn {
    min-width: 120px;
    transition: all 0.3s ease;
}

.form-actions .btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}

.card {
    transition: all 0.3s ease;
    border: none;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.card:hover {
    box-shadow: 0 4px 20px rgba(0,0,0,0.15);
}

.table-responsive {
    animation: fadeInUp 0.5s ease-out;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.modal-content {
    border: none;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
}

.modal-header {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-radius: 15px 15px 0 0;
}

.modal-body {
    padding: 2rem;
}

.modal-footer {
    background: #f8f9fa;
    border-radius: 0 0 15px 15px;
}

.modal .btn {
    transition: all 0.3s ease;
    border-radius: 8px;
    padding: 0.5rem 1.5rem;
}

.modal .btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}

.form-control, .form-select {
    transition: all 0.3s ease;
    border-radius: 8px;
}

.form-control:focus, .form-select:focus {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,123,255,0.2);
}

.page-wrapper {
    animation: fadeIn 0.5s ease-out;
}

@keyframes fadeIn {
    from {
        opacity: 0;
    }
    to {
        opacity: 1;
    }
}

.btn-added:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,123,255,0.3);
}

@media (max-width: 768px) {
    .page-header {
        flex-direction: column;
        gap: 1rem;
    }
    
    .page-btn {
        width: 100%;
    }
    
    .form-actions .btn {
        width: 100%;
        margin-bottom: 0.5rem;
    }
    
    .view-section {
        transform: translateY(20px);
    }
    
    .view-section.view-active {
        transform: translateY(0);
    }
}

.form-control:focus, .form-select:focus {
    animation: inputFocus 0.3s ease;
}

@keyframes inputFocus {
    0% {
        box-shadow: 0 0 0 0 rgba(0,123,255,0.5);
    }
    100% {
        box-shadow: 0 0 0 3px rgba(0,123,255,0.2);
    }
}

.status-badge {
    padding: 0.25rem 0.75rem;
    border-radius: 50px;
    font-size: 0.875rem;
    font-weight: 500;
}

.status-active {
    background-color: #d4edda;
    color: #155724;
}

.status-inactive {
    background-color: #f8d7da;
    color: #721c24;
}
</style>
```