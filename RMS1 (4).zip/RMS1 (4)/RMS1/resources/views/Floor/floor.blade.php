```blade
@include('layout.header')
@include('layout.navbar')
@include('layout.sidebar')

<div class="page-wrapper">
    <div class="content">
        <!-- Unified Session/Error Alert Modal -->
        @if(session('message') || $errors->any())
        <div class="modal fade show" id="sessionAlertModal" tabindex="-1" aria-labelledby="sessionAlertModalLabel" aria-modal="true" style="display: block;">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header border-0">
                        @php
                            $status = session('status') ?? 'Success';
                            $icon = $status === 'Error' ? 'exclamation-circle text-danger' : 'check-circle text-success';
                        @endphp
                        <h5 class="modal-title" id="sessionAlertModalLabel">
                            <i class="fas fa-{{ $icon }} me-2"></i>
                            {{ $status === 'Error' ? 'Error' : 'Success' }}
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        @if(session('message'))
                            <div class="alert alert-{{ $status === 'Error' ? 'danger' : 'success' }} mb-2">
                                {{ session('message') }}
                            </div>
                        @endif
                        @if($errors->any())
                            <ul>
                                @foreach($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        @endif
                    </div>
                    <div class="modal-footer border-0">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        @endif

        <!-- Floor List View -->
        <div id="floorListView" class="view-section">
            <div class="page-header">
                <div class="page-title">
                    <h4>Floor List</h4>
                    <h6>Manage Floors</h6>
                </div>
                <div class="page-btn">
                    <button type="button" class="btn btn-added" onclick="showAddFloorView()">
                        <img src="{{ asset('assets/img/icons/plus.svg') }}" alt="img" class="me-1">Add New Floor
                    </button>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="table-top">
                        <div class="search-set">
                            <div class="search-path">
                                <a class="btn btn-filter" id="filter_search">
                                    <img src="{{ asset('assets/img/icons/filter.svg') }}" alt="img">
                                    <span><img src="{{ asset('assets/img/icons/closes.svg') }}" alt="img"></span>
                                </a>
                            </div>
                            <div class="search-input">
                                <a class="btn btn-searchset"><img src="{{ asset('assets/img/icons/search-white.svg') }}" alt="img"></a>
                                <input type="text" id="floorSearch" class="form-control" placeholder="Search floors...">
                            </div>
                        </div>
                        <div class="wordset">
                            <ul>
                                <li>
                                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="Export to PDF">
                                        <img src="{{ asset('assets/img/icons/pdf.svg') }}" alt="img">
                                    </a>
                                </li>
                                <li>
                                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="Export to Excel">
                                        <img src="{{ asset('assets/img/icons/excel.svg') }}" alt="img">
                                    </a>
                                </li>
                                <li>
                                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="Print">
                                        <img src="{{ asset('assets/img/icons/printer.svg') }}" alt="img">
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="card mb-0" id="filter_inputs" style="display: none;">
                        <div class="card-body pb-0">
                            <div class="row">
                                <div class="col-lg-4 col-sm-6">
                                    <div class="mb-3">
                                        <label for="filter_floor_name" class="form-label">Floor Name</label>
                                        <input type="text" class="form-control" id="filter_floor_name" placeholder="Enter floor name">
                                    </div>
                                </div>
                                <div class="col-lg-4 col-sm-6">
                                    <div class="mb-3">
                                        <label for="filter_company_name" class="form-label">Company</label>
                                        <input type="text" class="form-control" id="filter_company_name" placeholder="Enter company name">
                                    </div>
                                </div>
                                <div class="col-lg-4 col-sm-6">
                                    <div class="mb-3">
                                        <label for="filter_status" class="form-label">Status</label>
                                        <select class="form-select" id="filter_status">
                                            <option value="">All Statuses</option>
                                            <option value="ACTIVE">Active</option>
                                            <option value="INACTIVE">Inactive</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table datanew">
                            <thead>
                                <tr>
                                    <th>
                                        <label class="checkboxs">
                                            <input type="checkbox" id="select-all">
                                            <span class="checkmarks"></span>
                                        </label>
                                    </th>
                                    <th>ID</th>
                                    <th>Company</th>
                                    <th>Branch</th>
                                    <th>Building</th>
                                    <th>Floor Name</th>
                                    <th>Remarks</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($floors as $floor)
                                    <tr>
                                        <td>
                                            <label class="checkboxs">
                                                <input type="checkbox">
                                                <span class="checkmarks"></span>
                                            </label>
                                        </td>
                                        <td>{{ $floor->id }}</td>
                                        <td>{{ $floor->COMPANY_NAME }}</td>
                                        <td>{{ $floor->BRANCH_NAME }}</td>
                                        <td>{{ $floor->BUILDING_NAME }}</td>
                                        <td>{{ $floor->FLOOR_NAME }}</td>
                                        <td>{{ $floor->Remarks ?? 'N/A' }}</td>
                                        <td>
                                            <span class="status-badge status-{{ strtolower($floor->IS_ACTIVE) }}">
                                                {{ $floor->IS_ACTIVE }}
                                            </span>
                                        </td>
                                        <td>
                                            <a class="me-3" href="javascript:void(0);" onclick="showViewFloor({{ json_encode($floor) }})">
                                                <img src="{{ asset('assets/img/icons/eye.svg') }}" alt="View">
                                            </a>
                                            <a class="me-3 edit-floor-btn" href="javascript:void(0);" onclick="showEditFloor({{ json_encode($floor) }})">
                                                <img src="{{ asset('assets/img/icons/edit.svg') }}" alt="Edit">
                                            </a>
                                            <a class="confirm-text delete-floor-btn" href="javascript:void(0);" onclick="showDeleteFloorModal({{ $floor->id }}, '{{ addslashes($floor->FLOOR_NAME) }}')">
                                                <img src="{{ asset('assets/img/icons/delete.svg') }}" alt="Delete">
                                            </a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Add Floor View -->
        <div id="addFloorView" class="view-section" style="display: none;">
            <div class="page-header">
                <div class="page-title">
                    <h4>Add New Floor</h4>
                    <h6>Create a new floor record</h6>
                </div>
                <div class="page-btn">
                    <button type="button" class="btn btn-secondary" onclick="showFloorListView()">
                        <i class="fas fa-arrow-left me-1"></i>Back to Floor List
                    </button>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <form method="POST" action="{{ route('floor.save') }}">
                        @csrf
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="company_id" class="form-label">Company *</label>
                                    <select class="form-select" id="company_id" name="company_id" required>
                                        <option value="">Select Company</option>
                                        @foreach($companies as $company)
                                            <option value="{{ $company->COMPANY_ID }}" {{ old('company_id', $selectedCompanyId) == $company->COMPANY_ID ? 'selected' : '' }}>
                                                {{ $company->COMPANY_NAME }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="branch_id" class="form-label">Branch *</label>
                                    <select class="form-select" id="branch_id" name="branch_id" required>
                                        <option value="">Select Branch</option>
                                        @foreach($branches as $branch)
                                            <option value="{{ $branch->BRANCH_ID }}" {{ old('branch_id', $selectedBranchId) == $branch->BRANCH_ID ? 'selected' : '' }}>
                                                {{ $branch->BRANCH_NAME }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="building_id" class="form-label">Building *</label>
                                    <select class="form-select" id="building_id" name="building_id" required>
                                        <option value="">Select Building</option>
                                        @foreach($buildings as $building)
                                            <option value="{{ $building->BUILDING_ID }}" {{ old('building_id') == $building->BUILDING_ID ? 'selected' : '' }}>
                                                {{ $building->BUILDING_NAME }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="floor_name" class="form-label">Floor Name *</label>
                                    <input type="text" class="form-control" name="floor_name" id="floor_name" value="{{ old('floor_name') }}" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="status_master" class="form-label">Status *</label>
                                    <select class="form-select" name="status_master" id="status_master" required>
                                        <option value="">-- Select Status --</option>
                                        <option value="ACTIVE" {{ old('status_master') == 'ACTIVE' ? 'selected' : '' }}>Active</option>
                                        <option value="INACTIVE" {{ old('status_master') == 'INACTIVE' ? 'selected' : '' }}>Inactive</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="remarks" class="form-label">Remarks</label>
                                    <textarea class="form-control" name="remarks" id="remarks" rows="3">{{ old('remarks') }}</textarea>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="created_by" value="{{ $createdBy }}">
                        <input type="hidden" name="mac_address" value="{{ $macAddress }}">
                        <div class="form-actions mt-4">
                            <button type="submit" class="btn btn-primary me-2">
                                <i class="fas fa-save me-1"></i>Save Floor
                            </button>
                            <button type="button" class="btn btn-secondary" onclick="showFloorListView()">
                                Cancel
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Edit Floor View -->
        <div id="editFloorView" class="view-section" style="display: none;">
            <div class="page-header">
                <div class="page-title">
                    <h4>Edit Floor</h4>
                    <h6>Update floor information</h6>
                </div>
                <div class="page-btn">
                    <button type="button" class="btn btn-secondary" onclick="showFloorListView()">
                        <i class="fas fa-arrow-left me-1"></i>Back to Floor List
                    </button>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <form id="editFloorForm" method="POST" action="{{ route('floor.update') }}">
                        @csrf
                        <input type="hidden" name="id" id="edit_floor_id">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="edit_company_id" class="form-label">Company *</label>
                                    <select class="form-select" name="company_id" id="edit_company_id" required>
                                        <option value="">Select Company</option>
                                        @foreach($companies as $company)
                                            <option value="{{ $company->COMPANY_ID }}" {{ old('company_id') == $company->COMPANY_ID ? 'selected' : '' }}>
                                                {{ $company->COMPANY_NAME }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="edit_branch_id" class="form-label">Branch *</label>
                                    <select class="form-select" name="branch_id" id="edit_branch_id" required>
                                        <option value="">Select Branch</option>
                                        @foreach($branches as $branch)
                                            <option value="{{ $branch->BRANCH_ID }}" {{ old('branch_id') == $branch->BRANCH_ID ? 'selected' : '' }}>
                                                {{ $branch->BRANCH_NAME }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="edit_building_id" class="form-label">Building *</label>
                                    <select class="form-select" name="building_id" id="edit_building_id" required>
                                        <option value="">Select Building</option>
                                        @foreach($buildings as $building)
                                            <option value="{{ $building->BUILDING_ID }}" {{ old('building_id') == $building->BUILDING_ID ? 'selected' : '' }}>
                                                {{ $building->BUILDING_NAME }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="edit_floor_name" class="form-label">Floor Name *</label>
                                    <input type="text" class="form-control" name="floor_name" id="edit_floor_name" value="{{ old('floor_name') }}" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="edit_status_master" class="form-label">Status *</label>
                                    <select class="form-select" name="status_master" id="edit_status_master" required>
                                        <option value="">-- Select Status --</option>
                                        <option value="ACTIVE" {{ old('status_master') == 'ACTIVE' ? 'selected' : '' }}>Active</option>
                                        <option value="INACTIVE" {{ old('status_master') == 'INACTIVE' ? 'selected' : '' }}>Inactive</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="edit_remarks" class="form-label">Remarks</label>
                                    <textarea class="form-control" name="remarks" id="edit_remarks" rows="3">{{ old('remarks') }}</textarea>
                                </div>
                            </div>
                        </div>
                        <div class="form-actions mt-4">
                            <button type="submit" class="btn btn-primary me-2">
                                <i class="fas fa-save me-1"></i>Update Floor
                            </button>
                            <button type="button" class="btn btn-secondary" onclick="showFloorListView()">
                                Cancel
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- View Floor Details -->
        <div id="viewFloorView" class="view-section" style="display: none;">
            <div class="page-header">
                <div class="page-title">
                    <h4>Floor Details</h4>
                    <h6>View floor information</h6>
                </div>
                <div class="page-btn">
                    <button type="button" class="btn btn-warning me-2" onclick="switchToEditFromView()">
                        <img src="{{ asset('assets/img/icons/edit.svg') }}" alt="img" class="me-1">Edit Floor
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="showFloorListView()">
                        <i class="fas fa-arrow-left me-1"></i>Back to Floor List
                    </button>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label class="form-label">Floor ID</label>
                                <input type="text" class="form-control" id="view_floor_id" readonly>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label class="form-label">Floor Name</label>
                                <input type="text" class="form-control" id="view_floor_name" readonly>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label class="form-label">Company</label>
                                <input type="text" class="form-control" id="view_company_name" readonly>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label class="form-label">Branch</label>
                                <input type="text" class="form-control" id="view_branch_name" readonly>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label class="form-label">Building</label>
                                <input type="text" class="form-control" id="view_building_name" readonly>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label class="form-label">Status</label>
                                <input type="text" class="form-control" id="view_status" readonly>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="mb-3">
                                <label class="form-label">Remarks</label>
                                <textarea class="form-control" id="view_remarks" rows="3" readonly></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Delete Floor Confirmation -->
        <div class="modal fade" id="deleteFloorModal" tabindex="-1" aria-labelledby="deleteFloorModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header border-0">
                        <h5 class="modal-title" id="deleteFloorModalLabel">
                            <i class="fas fa-exclamation-triangle text-warning me-2"></i>Delete Floor
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body text-center py-4">
                        <div class="mb-4">
                            <i class="fas fa-trash fa-4x text-danger mb-3"></i>
                            <h4 class="mb-3">Are you sure?</h4>
                            <p class="mb-2">You are about to delete floor:</p>
                            <p class="fs-5 fw-bold text-dark" id="delete_floor_name"></p>
                            <p class="text-muted small">This action cannot be undone and will permanently remove the floor from the system.</p>
                        </div>
                    </div>
                    <div class="modal-footer border-0 justify-content-center">
                        <form method="POST" action="{{ route('floor.delete') }}" class="d-inline">
                            @csrf
                            <input type="hidden" name="id" id="delete_floor_id">
                            <button type="submit" class="btn btn-danger me-2">
                                <i class="fas fa-trash me-1"></i>Yes, Delete Floor
                            </button>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                <i class="fas fa-times me-1"></i>Cancel
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@include('layout.footer')

<script>
    // Suppress all DataTables error alerts
    $.fn.dataTable.ext.errMode = 'none';

    let currentFloorData = {};

    // View navigation functions
    function showFloorListView() {
        hideAllViews();
        document.getElementById('floorListView').style.display = 'block';
        if ($.fn.DataTable.isDataTable('.datanew')) {
            $('.datanew').DataTable().draw();
        }
    }

    function showAddFloorView() {
        hideAllViews();
        document.getElementById('addFloorView').style.display = 'block';
        document.querySelector('#addFloorView form').reset();
        document.getElementById('status_master').value = 'ACTIVE';
    }

    function showEditFloor(floorData) {
        hideAllViews();
        document.getElementById('editFloorView').style.display = 'block';

        // Populate form fields
        document.getElementById('edit_floor_id').value = floorData.id || '';
        document.getElementById('edit_company_id').value = floorData.COMPANY_ID || '';
        document.getElementById('edit_branch_id').value = floorData.BRANCH_ID || '';
        document.getElementById('edit_building_id').value = floorData.BUILDING_ID || '';
        document.getElementById('edit_floor_name').value = floorData.FLOOR_NAME || '';
        document.getElementById('edit_remarks').value = floorData.Remarks || '';
        document.getElementById('edit_status_master').value = floorData.IS_ACTIVE || '';

        // Store data for potential switch to edit
        currentFloorData = floorData;
    }

    function showViewFloor(floorData) {
        hideAllViews();
        document.getElementById('viewFloorView').style.display = 'block';

        // Populate view fields
        document.getElementById('view_floor_id').value = floorData.id || '';
        document.getElementById('view_floor_name').value = floorData.FLOOR_NAME || '';
        document.getElementById('view_company_name').value = floorData.COMPANY_NAME || '';
        document.getElementById('view_branch_name').value = floorData.BRANCH_NAME || '';
        document.getElementById('view_building_name').value = floorData.BUILDING_NAME || '';
        document.getElementById('view_remarks').value = floorData.Remarks || '';
        document.getElementById('view_status').value = floorData.IS_ACTIVE || '';

        // Store data for potential switch to edit
        currentFloorData = floorData;
    }

    function showDeleteFloorModal(id, floorName) {
        document.getElementById('delete_floor_id').value = id;
        document.getElementById('delete_floor_name').textContent = floorName;
        const modal = new bootstrap.Modal(document.getElementById('deleteFloorModal'));
        modal.show();
    }

    function switchToEditFromView() {
        if (currentFloorData) {
            showEditFloor(currentFloorData);
        }
    }

    function hideAllViews() {
        const views = document.querySelectorAll('.view-section');
        views.forEach(view => view.style.display = 'none');
    }

    document.addEventListener('DOMContentLoaded', function () {
        // Initialize DataTable
        const dataTable = $('.datanew').DataTable({
            responsive: true,
            pageLength: 10,
            order: [[1, 'asc']],
            search: {
                caseInsensitive: true,
                return: true
            },
            columnDefs: [
                { orderable: false, targets: [0, 8] }
            ]
        });

        // Search input handling
        $('#floorSearch').on('keyup', function () {
            dataTable.search(this.value).draw();
        });

        // Filter toggle
        $('#filter_search').on('click', function () {
            const filterInputs = $('#filter_inputs');
            filterInputs.toggle();
            $(this).find('span').toggle();
        });

        // Filter handling
        $('#filter_floor_name, #filter_company_name, #filter_status').on('change keyup', function () {
            const floorName = $('#filter_floor_name').val();
            const companyName = $('#filter_company_name').val();
            const status = $('#filter_status').val();
            dataTable.column(5).search(floorName).column(2).search(companyName).column(7).search(status).draw();
        });

        // Select all checkboxes
        $('#select-all').on('click', function () {
            const checked = this.checked;
            $('.datanew tbody input[type="checkbox"]').prop('checked', checked);
        });

        // Show edit view with data if present in session (e.g., after validation error or exception)
        @if(session('updated_floor_data'))
            const floorData = @json(session('updated_floor_data'));
            showEditFloor(floorData);
            const sessionAlertModal = new bootstrap.Modal(document.getElementById('sessionAlertModal'));
            sessionAlertModal.show();
            setTimeout(() => {
                sessionAlertModal.hide();
            }, 5000);
        @elseif($errors->any() || session('message'))
            const sessionAlertModal = new bootstrap.Modal(document.getElementById('sessionAlertModal'));
            sessionAlertModal.show();
            setTimeout(() => {
                sessionAlertModal.hide();
            }, 5000);
            @if(session('show_edit_view'))
                const floorData = @json(session('updated_floor_data'));
                showEditFloor(floorData);
            @else
                showFloorListView();
            @endif
        @else
            showFloorListView();
        @endif
    });
</script>

<style>
.view-section {
    animation: fadeInUp 0.5s ease-out;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.table-top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
}

.search-set {
    display: flex;
    align-items: center;
    gap: 1rem;
}

.search-set input {
    width: 250px;
}

.status-badge {
    padding: 0.25rem 0.75rem;
    border-radius: 50px;
    font-size: 0.875rem;
    font-weight: 500;
}

.status-active {
    background-color: #d4edda;
    color: #155724;
}

.status-inactive {
    background-color: #f8d7da;
    color: #721c24;
}

.modal-content {
    border: none;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
}

.modal-header {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-radius: 15px 15px 0 0;
}

.modal-body {
    padding: 2rem;
}

.modal-footer {
    background: #f8f9fa;
    border-radius: 0 0 15px 15px;
}

.modal .btn {
    transition: all 0.3s ease;
    border-radius: 8px;
    padding: 0.5rem 1.5rem;
}

.modal .btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}

.card {
    border: none;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    transition: all 0.3s ease;
}

.card:hover {
    box-shadow: 0 4px 20px rgba(0,0,0,0.15);
}

.form-control, .form-select {
    border-radius: 8px;
    transition: all 0.3s ease;
}

.form-control:focus, .form-select:focus {
    box-shadow: 0 0 0 3px rgba(0,123,255,0.2);
    transform: translateY(-2px);
}

.btn-added, .btn-primary, .btn-secondary, .btn-warning {
    border-radius: 8px;
    transition: all 0.3s ease;
}

.btn-added:hover, .btn-primary:hover, .btn-secondary:hover, .btn-warning:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}

@media (max-width: 768px) {
    .page-header {
        flex-direction: column;
        gap: 1rem;
    }

    .page-btn {
        width: 100%;
    }

    .form-actions .btn {
        width: 100%;
        margin-bottom: 0.5rem;
    }
}
</style>
```
