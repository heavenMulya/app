

<div class="sidebar" id="sidebar">
<div class="sidebar-inner slimscroll">
<div id="sidebar-menu" class="sidebar-menu">
<ul>
<li class="active">
<a href="{{url('/') }}"><i class="fa fa-home" style="font-size: 24px;"></i><span> Dashboard</span> </a>
</li>
<li class="submenu">
<a href="javascript:void(0);"><i class="fa fa-building" style="font-size: 24px;"></i>

<span>Master</span> <span class="menu-arrow"></span></a>
<ul>
<li><a href="{{url('/user') }}">User</a></li>
<li><a href="{{url('/company') }}">Company master</a></li>
<li><a href="{{url('/branch') }}">Branch Master</a></li>
<li><a href="{{url('/bulding') }}">Buildings Master</a></li>
<li><a href="{{url('/floor') }}">Floor Master</a></li>
<li><a href="{{url('/property') }}">Property Master</a></li>
<li><a href="{{url('/pricesetting') }}">Price Setting Master</a></li>
<li><a href="{{url('/rental-type') }}">Rental Type</a></li>

</ul>
</li>
<li class="submenu">
<a href="javascript:void(0);"><i class="fa fa-money-check-alt" style=" font-size: 24px;"></i><span>Tenant</span> <span class="menu-arrow"></span></a>
<ul>
<li><a href="{{url('/tenant') }}">Tenant</a></li>
<li><a href="{{url('/agreement') }}">Agreement Mapping</a></li>
</ul>
</li>


<li class="submenu">
<a href="javascript:void(0);"><i class="fa fa-money-check-alt" style=" font-size: 24px;"></i><span>Invoice</span> <span class="menu-arrow"></span></a>
<ul>
<li><a href="{{url('/invoice') }}">View Invoice</a></li>
</ul>
</li>

<li class="">
<a href="javascript:void(0);"><i class="fa fa-file" style=" font-size: 24px;"></i><span>Reports</span></a>
</li>
<li class="">
<a href="javascript:void(0);"><i class="fa fa-cog" style=" font-size: 24px;"></i><span>Settings</span></a>
</li>
</ul>
</div>
</div>
</div>


