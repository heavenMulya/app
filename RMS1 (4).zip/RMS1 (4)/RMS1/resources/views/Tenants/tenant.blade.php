
@include ('layout.header')

@include ('layout.navbar')
@include ('layout.sidebar')



<div class="page-wrapper">
    <div class="content">
        <div class="page-header">
            <div class="page-title">
                <h4>Tenants List</h4>
                <h6>Manage your Tenants</h6>
            </div>

            @if(isset($message))
    <div id="session-alert" class="alert alert-{{ $status === 'Error' ? 'danger' : 'success' }} alert-dismissible fade show"
         role="alert"
         style="position: fixed; top: 90px; right: 230px; z-index: 1055; min-width: 550px;">
        {{ $message }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>

    @if($status !== 'Error')
        <script>
            // Auto dismiss success messages after 5 seconds
            setTimeout(function () {
                const alert = document.getElementById('session-alert');
                if (alert) {
                    alert.classList.remove('show');
                    alert.classList.add('fade');
                    setTimeout(() => alert.remove(), 1000);
                }
            }, 5000);
        </script>
    @endif
@endif


            <div class="page-btn">
                <a href="javascript:void(0);" class="btn btn-added" data-bs-toggle="modal" data-bs-target="#addTenantModal">
                    <img src="assets/img/icons/plus.svg" alt="img" class="me-1">Add New Tenants
                </a>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <div class="table-top">
                    <div class="search-set">
                        <div class="search-path">
                            <a class="btn btn-filter" id="filter_search">
                                <img src="assets/img/icons/filter.svg" alt="img">
                                <span><img src="assets/img/icons/closes.svg" alt="img"></span>
                            </a>
                        </div>
                        <div class="search-input">
                            <a class="btn btn-searchset"><img src="assets/img/icons/search-white.svg" alt="img"></a>
                        </div>
                    </div>
                    <div class="wordset">
                        <ul>
                            <li>
                                <a data-bs-toggle="tooltip" data-bs-placement="top" title="pdf">
                                    <img src="assets/img/icons/pdf.svg" alt="img">
                                </a>
                            </li>
                            <li>
                                <a data-bs-toggle="tooltip" data-bs-placement="top" title="excel">
                                    <img src="assets/img/icons/excel.svg" alt="img">
                                </a>
                            </li>
                            <li>
                                <a data-bs-toggle="tooltip" data-bs-placement="top" title="print">
                                    <img src="assets/img/icons/printer.svg" alt="img">
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="card mb-0" id="filter_inputs">
                    <div class="card-body pb-0">
                        <div class="row">
                            <div class="col-lg-12 col-sm-12">
                                <div class="row">
                                

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table datanew">
                        <thead>
                            <tr>
                                <th>
                                    <label class="checkboxs">
                                        <input type="checkbox" id="select-all">
                                        <span class="checkmarks"></span>
                                    </label>
                                </th>
                                  <th>ID</th>
                                  <th>Tenant Name</th>
                                  <th>Login Name</th>
                                  <th>Email</th>
                                  <th>Mobile No</th>
                                  <th>TIN No</th>
                                  <th>NIDA No</th>
                                  <th>KURA ID</th>
                                  <th>Driving License No</th>
                                  <th>Address</th>
                                  <th>City</th>
                                  <th>State</th>
                                  <th>Country</th>
                                  <th>Remarks</th>
                                  <th>Action</th>

                            </tr>
                        </thead>

                        <tbody>
                            @foreach ($tenants as $item)
                                <tr>
                                    <td>
                                        <label class="checkboxs">
                                            <input type="checkbox">
                                            <span class="checkmarks"></span>
                                        </label>
                                    </td>
                                    <td>{{ $item->TENANT_ID ?? 'N/A' }}</td>
                                    <td class="buldingimgname">
                                    <a href="javascript:void(0);">{{ $item->TENANT_NAME ?? 'N/A' }}</a>
                                    </td>
                                    <td>{{ $item->LOGIN_NAME ?? 'N/A' }}</td>
                                    <td>{{ $item->EMAIL ?? 'N/A' }}</td>
                                    <td>{{ $item->MOBILE_NO ?? 'N/A' }}</td>
                                    <td>{{ $item->TIN_NO ?? 'N/A' }}</td>
                                    <td>{{ $item->NIDA_NO ?? 'N/A' }}</td>
                                    <td>{{ $item->KURA_ID ?? 'N/A' }}</td>
                                    <td>{{ $item->DRIVING_LICENSE_NO ?? 'N/A' }}</td>
                                    <td>{{ $item->ADDRESS ?? 'N/A' }}</td>
                                    <td>{{ $item->CITY ?? 'N/A' }}</td>
                                    <td>{{ $item->STATE ?? 'N/A' }}</td>
                                    <td>{{ $item->COUNTRY_NAME ?? 'N/A' }}</td>
                                    <td>{{ $item->REMARKS ?? 'N/A' }}</td>

                                    <td>
                                        <a class="me-3 view-tenant-btn"
                                         href="javascript:void(0);"
                                         data-id="{{ $item->TENANT_ID }}"
                                         data-name="{{ $item->TENANT_NAME }}"
                                         data-login="{{ $item->LOGIN_NAME }}"
                                         data-email="{{ $item->EMAIL }}"
                                         data-mobile="{{ $item->MOBILE_NO }}"
                                         data-tin="{{ $item->TIN_NO }}"
                                         data-nida="{{ $item->NIDA_NO }}"
                                         data-kura="{{ $item->KURA_ID }}"
                                         data-license="{{ $item->DRIVING_LICENSE_NO }}"
                                         data-address="{{ $item->ADDRESS }}"
                                         data-city="{{ $item->CITY }}"
                                         data-state="{{ $item->STATE }}"
                                         data-country="{{ $item->COUNTRY_NAME }}"
                                         data-remarks="{{ $item->REMARKS }}"
                                         data-bs-toggle="modal"
                                         data-bs-target="#viewbuldingModal">
                                         <img src="assets/img/icons/eye.svg" alt="View">
                                        </a>


                                     <!--  <a class="me-3" href="javascript:void(0);"
                                          data-bs-toggle="modal"
                                          data-bs-target="#viewbuldingModal">
                                           <img src="assets/img/icons/eye.svg" alt="View">
                                       </a>-->

                                             <a class="me-3 edit-tenant-btn"
                                                href="javascript:void(0);"
                                                data-bs-toggle="modal"
                                                data-bs-target="#editTenantModal"
                                                data-id="{{ $item->TENANT_ID }}"
                                                data-name="{{ $item->TENANT_NAME }}"
                                                data-login="{{ $item->LOGIN_NAME }}"
                                                data-password="{{ $item->PASSWORD }}"
                                                data-email="{{ $item->EMAIL }}"
                                                data-mobile="{{ $item->MOBILE_NO }}"
                                                data-tin="{{ $item->TIN_NO }}"
                                                data-nida="{{ $item->NIDA_NO }}"
                                                data-kura="{{ $item->KURA_ID }}"
                                                data-license="{{ $item->DRIVING_LICENSE_NO }}"
                                                data-address="{{ $item->ADDRESS }}"
                                                data-city="{{ $item->CITY }}"
                                                data-state="{{ $item->STATE }}"
                                                data-country="{{ $item->COUNTRY_ID }}"
                                                data-remarks="{{ $item->REMARKS }}"
                                                data-status="{{ $item->STATUS_MASTER }}"

                                                >
                                                <img src="assets/img/icons/edit.svg" alt="Edit">
                                             </a>


                                      <a class="confirm-text delete-tenant-btn" 
                                       href="javascript:void(0);" 
                                       data-id="{{ $item->TENANT_ID }}" 
                                       data-name="{{ $item->TENANT_NAME }}" 
                                       data-bs-toggle="modal" 
                                       data-bs-target="#deleteTenantModal">
                                      <img src="assets/img/icons/delete.svg" alt="Delete">
                                      </a>
                                        
                                                     <a class="confirm-text add-document-btn" 
               href="javascript:void(0);" 
                data-tenant="{{ $item->TENANT_ID }}" 
               data-bs-toggle="modal" 
               data-bs-target="#documentModal">
                <img src="assets/img/icons/plus.svg" alt="Delete">
            </a>

                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div> <!-- .table-responsive -->
            </div> <!-- .card-body -->
        </div> <!-- .card -->
    </div> <!-- .content -->
</div> <!-- .page-wrapper -->





<!-- Add Tenant Modal -->
<div class="modal fade" id="addTenantModal" tabindex="-1" aria-labelledby="addTenantLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg"> <!-- use modal-lg for more space -->
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addTenantLabel">Add New Tenant</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form method="POST" action="{{ route('tenant.save') }}">
          @csrf

          <div class="row">
            <div class="col-md-6 mb-3">
              <label for="tenant_name" class="form-label">Tenant Name</label>
              <input type="text" class="form-control" name="tenant_name" id="tenant_name" required>
            </div>
            <div class="col-md-6 mb-3">
              <label for="login_name" class="form-label">Login Name</label>
              <input type="text" class="form-control" name="login_name" id="login_name" required>
            </div>
            <div class="col-md-6 mb-3">
              <label for="password" class="form-label">Password</label>
              <input type="password" class="form-control" name="password" id="password" required>
            </div>
            <div class="col-md-6 mb-3">
              <label for="email" class="form-label">Email</label>
              <input type="email" class="form-control" name="email" id="email">
            </div>
            <div class="col-md-6 mb-3">
              <label for="mobile_no" class="form-label">Mobile Number</label>
              <input type="text" class="form-control" name="mobile_no" id="mobile_no">
            </div>
            <div class="col-md-6 mb-3">
              <label for="tin_no" class="form-label">TIN Number</label>
              <input type="text" class="form-control" name="tin_no" id="tin_no">
            </div>
            <div class="col-md-6 mb-3">
              <label for="nida_no" class="form-label">NIDA Number</label>
              <input type="text" class="form-control" name="nida_no" id="nida_no">
            </div>
            <div class="col-md-6 mb-3">
              <label for="kura_id" class="form-label">KURA ID</label>
              <input type="text" class="form-control" name="kura_id" id="kura_id">
            </div>
            <div class="col-md-6 mb-3">
              <label for="driving_license_no" class="form-label">Driving License No</label>
              <input type="text" class="form-control" name="driving_license_no" id="driving_license_no">
            </div>
            <div class="col-md-6 mb-3">
              <label for="address" class="form-label">Address</label>
              <input type="text" class="form-control" name="address" id="address">
            </div>
            <div class="col-md-6 mb-3">
              <label for="city" class="form-label">City</label>
              <input type="text" class="form-control" name="city" id="city">
            </div>
            <div class="col-md-6 mb-3">
              <label for="state" class="form-label">State</label>
              <input type="text" class="form-control" name="state" id="state">
            </div>
            <div class="col-md-6 mb-3">
              <label for="country_id" class="form-label">Country</label>
              <select class="form-select" name="country_id" id="country_id">
                <option value="">-- Select Country --</option>
                @foreach ($countries as $country)
                  <option value="{{ $country->COUNTRY_ID }}">{{ $country->COUNTRY_NAME }}</option>
                @endforeach
              </select>
            </div>           
            <div class="col-md-6 mb-3">
              <label for="status_master" class="form-label">Status</label>
              <select class="form-select" name="status_master" id="status_master" value="ACTIVE" >
                <option value="ACTIVE" selected>Active</option>
                <option value="INACTIVE">Inactive</option>
              </select>
            </div>
            <div class="col-md-12 mb-3">
              <label for="remarks" class="form-label">Remarks</label>
              <input type="text" class="form-control" name="remarks" id="remarks">
            </div>
          </div>

          <!-- Hidden Fields -->
          <input type="hidden" name="created_by" value="{{ $createdBy }}">
          <input type="hidden" name="mac_address" value="{{ $macAddress }}">

          <div class="modal-footer">
            <button type="submit" class="btn btn-primary">Save</button>
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          </div>

        </form>
      </div>
    </div>
  </div>
</div>


<!-- Edit Tenant Modal -->
<div class="modal fade" id="editTenantModal" tabindex="-1" aria-labelledby="editTenantLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg"> 
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editTenantLabel">Edit Tenant</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body">
        @if ($errors->any())
          <div class="alert alert-danger">
            <ul>
              @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
              @endforeach
            </ul>
          </div>
        @endif

        <form id="editTenantForm" method="POST" action="{{ route('tenant.update') }}">
          @csrf
          @method('PUT')
          <input type="hidden" name="tenant_id" id="edit_tenant_id">

          <div class="row">
            <div class="col-md-6 mb-3">
              <label for="edit_tenant_name" class="form-label">Tenant Name</label>
              <input type="text" class="form-control" name="tenant_name" id="edit_tenant_name" required>
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_login_name" class="form-label">Login Name</label>
              <input type="text" class="form-control" name="login_name" id="edit_login_name" required>
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_password" class="form-label">Password</label>
              <input type="password" class="form-control" name="password" id="edit_password">
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_email" class="form-label">Email</label>
              <input type="email" class="form-control" name="email" id="edit_email">
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_mobile_no" class="form-label">Mobile No</label>
              <input type="text" class="form-control" name="mobile_no" id="edit_mobile_no">
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_tin_no" class="form-label">TIN No</label>
              <input type="text" class="form-control" name="tin_no" id="edit_tin_no">
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_nida_no" class="form-label">NIDA No</label>
              <input type="text" class="form-control" name="nida_no" id="edit_nida_no">
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_kura_id" class="form-label">KURA ID</label>
              <input type="text" class="form-control" name="kura_id" id="edit_kura_id">
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_license" class="form-label">Driving License No</label>
              <input type="text" class="form-control" name="driving_license_no" id="edit_license">
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_address" class="form-label">Address</label>
              <input type="text" class="form-control" name="address" id="edit_address">
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_city" class="form-label">City</label>
              <input type="text" class="form-control" name="city" id="edit_city">
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_state" class="form-label">State</label>
              <input type="text" class="form-control" name="state" id="edit_state">
            </div>
             <div class="col-md-6 mb-3">
              <label for="edit_country" class="form-label">Country</label>
              <select class="form-select" name="country_id" id="edit_country">
                <option value="">-- Select Country --</option>
                @foreach ($countries as $country)
                  <option value="{{ $country->COUNTRY_ID }}">{{ $country->COUNTRY_NAME }}</option>
                @endforeach
              </select>
            </div>
            <!--<div class="col-md-6 mb-3">
              <label for="edit_country" class="form-label">Country</label>
              <input type="text" class="form-control" name="country_name" id="edit_country">
            </div>-->

            <div class="col-md-6 mb-3">
              <label for="edit_remarks" class="form-label">Remarks</label>
              <textarea class="form-control" name="remarks" id="edit_remarks" rows="2"></textarea>
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_status_master" class="form-label">Status</label>
              <select class="form-select" name="status_master" id="edit_status_master" value="ACTIVE">
                <option value="ACTIVE">Active</option>
                <option value="INACTIVE">Inactive</option>
              </select>
            </div>
          </div>

          <div class="modal-footer">
            <button type="submit" class="btn btn-primary">Update</button>
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>


<!--
<div class="modal fade" id="editTenantModal" tabindex="-1" aria-labelledby="editTenantLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editTenantLabel">Edit Tenant</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body">
        @if ($errors->any())
          <div class="alert alert-danger">
            <ul>
              @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
              @endforeach
            </ul>
          </div>
        @endif

        <form id="editTenantForm" method="POST" action="{{ route('tenant.update') }}">
          @csrf
          @method('PUT')
          <input type="hidden" name="tenant_id" id="edit_tenant_id" value="{{ old('tenant_id') }}">
          <input type="hidden" name="modal" value="editTenantModal">

          <div class="row">
            <div class="col-md-6 mb-3">
              <label for="edit_tenant_name" class="form-label">Tenant Name</label>
              <input type="text" class="form-control" name="tenant_name" id="edit_tenant_name" value="{{ old('tenant_name') }}" required>
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_login_name" class="form-label">Login Name</label>
              <input type="text" class="form-control" name="login_name" id="edit_login_name" value="{{ old('login_name') }}" required>
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_password" class="form-label">Password</label>
              <input type="text" class="form-control" name="password" id="edit_password" value="{{ old('password') }}">
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_email" class="form-label">Email</label>
              <input type="email" class="form-control" name="email" id="edit_email" value="{{ old('email') }}">
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_mobile_no" class="form-label">Mobile No</label>
              <input type="text" class="form-control" name="mobile_no" id="edit_mobile_no" value="{{ old('mobile_no') }}">
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_tin_no" class="form-label">TIN No</label>
              <input type="text" class="form-control" name="tin_no" id="edit_tin_no" value="{{ old('tin_no') }}">
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_nida_no" class="form-label">NIDA No</label>
              <input type="text" class="form-control" name="nida_no" id="edit_nida_no" value="{{ old('nida_no') }}">
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_kura_id" class="form-label">KURA ID</label>
              <input type="text" class="form-control" name="kura_id" id="edit_kura_id" value="{{ old('kura_id') }}">
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_license" class="form-label">Driving License No</label>
              <input type="text" class="form-control" name="driving_license_no" id="edit_license" value="{{ old('driving_license_no') }}">
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_address" class="form-label">Address</label>
              <input type="text" class="form-control" name="address" id="edit_address" value="{{ old('address') }}">
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_city" class="form-label">City</label>
              <input type="text" class="form-control" name="city" id="edit_city" value="{{ old('city') }}">
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_state" class="form-label">State</label>
              <input type="text" class="form-control" name="state" id="edit_state" value="{{ old('state') }}">
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_country" class="form-label">Country</label>
              <select class="form-select" name="country_id" id="edit_country">
                <option value="">-- Select Country --</option>
                @foreach ($countries as $country)
                  <option value="{{ $country->COUNTRY_ID }}"
                    {{ old('country_id') == $country->COUNTRY_ID ? 'selected' : '' }}>
                    {{ $country->COUNTRY_NAME }}
                  </option>
                @endforeach
              </select>
            </div>

            <div class="col-md-12 mb-3">
              <label for="edit_remarks" class="form-label">Remarks</label>
              <textarea class="form-control" name="remarks" id="edit_remarks" rows="2">{{ old('remarks') }}</textarea>
            </div>

            <div class="col-md-6 mb-3">
              <label for="edit_status_master" class="form-label">Status</label>
              <select class="form-select" name="status_master" id="edit_status_master">
                <option value="ACTIVE" {{ old('status_master') === 'ACTIVE' ? 'selected' : '' }}>Active</option>
                <option value="INACTIVE" {{ old('status_master') === 'INACTIVE' ? 'selected' : '' }}>Inactive</option>
              </select>
            </div>
          </div>

          <div class="modal-footer">
            <button type="submit" class="btn btn-primary">Update</button>
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>-->


<!-- View Tenant Modal -->
<div class="modal fade" id="viewbuldingModal" tabindex="-1" aria-labelledby="viewbuldingLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg"> <!-- Extra width -->
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="viewbuldingLabel">Tenant Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <!-- Hidden Tenant ID -->
        <input type="hidden" id="view_tenant_id">
        <div class="row">
          <div class="col-md-6 mb-3">
            <label class="form-label">Tenant Name</label>
            <input type="text" class="form-control" id="view_tenant_name" readonly>
          </div>

          <div class="col-md-6 mb-3">
            <label class="form-label">Login Name</label>
            <input type="text" class="form-control" id="view_login_name" readonly>
          </div>

          <div class="col-md-6 mb-3">
            <label class="form-label">Password</label>
            <input type="text" class="form-control" id="view_password" readonly>
          </div>

          <div class="col-md-6 mb-3">
            <label class="form-label">Email</label>
            <input type="text" class="form-control" id="view_email" readonly>
          </div>

          <div class="col-md-6 mb-3">
            <label class="form-label">Mobile No</label>
            <input type="text" class="form-control" id="view_mobile_no" readonly>
          </div>

          <div class="col-md-6 mb-3">
            <label class="form-label">TIN No</label>
            <input type="text" class="form-control" id="view_tin_no" readonly>
          </div>

          <div class="col-md-6 mb-3">
            <label class="form-label">NIDA No</label>
            <input type="text" class="form-control" id="view_nida_no" readonly>
          </div>

          <div class="col-md-6 mb-3">
            <label class="form-label">KURA ID</label>
            <input type="text" class="form-control" id="view_kura_id" readonly>
          </div>

          <div class="col-md-6 mb-3">
            <label class="form-label">Driving License No</label>
            <input type="text" class="form-control" id="view_license" readonly>
          </div>

          <div class="col-md-6 mb-3">
            <label class="form-label">Address</label>
            <input type="text" class="form-control" id="view_address" readonly>
          </div>

          <div class="col-md-6 mb-3">
            <label class="form-label">City</label>
            <input type="text" class="form-control" id="view_city" readonly>
          </div>

          <div class="col-md-6 mb-3">
            <label class="form-label">State</label>
            <input type="text" class="form-control" id="view_state" readonly>
          </div>

          <div class="col-md-6 mb-3">
            <label class="form-label">Country</label>
            <input type="text" class="form-control" id="view_country" readonly>
          </div>
            <div class="col-md-6 mb-3">
            <label class="form-label">Remarks</label>
            <input type="text" class="form-control" id="view_remarks" readonly>
          </div>
          <div class="documentListContainer" id="documentListContainer"></div>
          </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Delete Tenant Modal -->
 
<div class="modal fade" id="deleteTenantModal" tabindex="-1" aria-labelledby="deleteTenantLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form method="POST" action="{{ route('tenant.delete') }}">
      @csrf
      @method('DELETE')
      <input type="hidden" name="tenant_id" id="delete_tenant_id">

      <div class="modal-content">
        <div class="modal-header bg-danger text-white">
          <h5 class="modal-title" id="deleteTenantLabel">Confirm Tenant Deletion</h5>
          <button type="button" class="btn-close text-white" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body text-center">
          <p>Are you sure you want to delete <strong id="delete_tenant_name">Tenant XYZ</strong> from the system?</p>
          <p>This action cannot be undone.</p>
        </div>
        <div class="modal-footer justify-content-center">
          <button type="submit" class="btn btn-danger">Yes, Delete</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        </div>
      </div>
    </form>
  </div>
</div>

<!--Documents Agreement Mapping Modal -->
<div class="modal fade" id="documentModal" tabindex="-1" aria-labelledby="documentModal" aria-hidden="true">
    <div class="modal-dialog modal-lg custom-modal-width">
            <div class="modal-content">
                <div class="modal-header">
        <h5 class="modal-title" id="documentModal">Documents Upload</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
                <div class="modal-body">  
        <form method="POST" action="{{ route('tenant.document.save') }}" enctype="multipart/form-data">

    @csrf
    <div class="row">
      
    <div class="col-md-6 mb-3">
        <label class="form-label">Tenant</label>
        <select class="form-select" name="tenant_id" id="view_tenant_id_for_document" required>
            <option value=""> Select Tenant </option>
            @foreach ($tenants as $tenant)
                <option value="{{ $tenant->TENANT_ID }}">{{ $tenant->TENANT_NAME }}</option>
            @endforeach
        </select>
    </div>

        <div class="col-md-6 mb-3">
            <label class="form-label">Document Name</label>
            <input type="text" class="form-control" name="document_name" id="document_name" required>
    </div>

     <div class="col-md-6 mb-3">
        <label class="form-label">Document Upload</label>
        <input type="file" class="form-control" name="FILE" id="FILE">
    </div>

    <!-- Remarks -->
    <div class="col-md-6 mb-3">
        <label class="form-label">Remarks</label>
        <input type="text" class="form-control" name="remarks" maxlength="256">
    </div>

    <!-- Status -->
 <div class="col-md-6 col-md-6 mb-3">
                            <label for="edit_status_master" class="form-label">Status</label>
                            <select class="form-select" id="edit_status_master" name="status_master">
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                            </select>
                        </div>

    <div class="modal-footer mt-4">
        <button type="submit" class="btn btn-primary">Save Document</button>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
    </div>
</form>
                </div>
            </div>
    </div>
</div>





@include ('layout.footer')


<!-- your modals and other content -->

@if ($errors->any() && old('modal') === 'editTenantModal')
<script>
  document.addEventListener('DOMContentLoaded', function () {
    const editModal = new bootstrap.Modal(document.getElementById('editTenantModal'));
    editModal.show();
  });
</script>
@endif


<script>
document.addEventListener('DOMContentLoaded', function () {
    const modal = document.getElementById('documentModal');
    const tenantSelect = document.getElementById('view_tenant_id_for_document');
    //const agreementSelect = document.getElementById('agreement_id');

    document.querySelectorAll('.add-document-btn').forEach(button => {
        button.addEventListener('click', function () {
            //const agreementId = this.getAttribute('data-id');
            const tenantId = this.getAttribute('data-tenant');

           // console.log("📄 Agreement IDleo:", agreementId);
            console.log("Tenant ID:", tenantId);

            // Ensure the <option> exists in the dropdown before selecting
            function ensureOption(selectEl, value) {
                if (!selectEl.querySelector(`option[value="${value}"]`)) {
                    const option = document.createElement('option');
                    option.value = value;
                   // option.textContent = `Agreement ID:${value}`;
                    selectEl.appendChild(option);
                }
                selectEl.value = value;
            }

            ensureOption(tenantSelect, tenantId);
          //  ensureOption(agreementSelect, agreementId);
        });
    });
});
</script>
<script>

document.addEventListener('DOMContentLoaded', function () {
    const editButtons = document.querySelectorAll('.edit-tenant-btn');

    editButtons.forEach(button => {
        button.addEventListener('click', function () {
            // Populate modal form fields with data from button
            document.getElementById('edit_tenant_id').value = this.dataset.id || '';
            document.getElementById('edit_tenant_name').value = this.dataset.name || '';
            document.getElementById('edit_login_name').value = this.dataset.login || '';
            document.getElementById('edit_password').value = this.dataset.password || '';
            document.getElementById('edit_email').value = this.dataset.email || '';
            document.getElementById('edit_mobile_no').value = this.dataset.mobile || '';
            document.getElementById('edit_tin_no').value = this.dataset.tin || '';
            document.getElementById('edit_nida_no').value = this.dataset.nida || '';
            document.getElementById('edit_kura_id').value = this.dataset.kura || '';
            document.getElementById('edit_license').value = this.dataset.license || '';
            document.getElementById('edit_address').value = this.dataset.address || '';
            document.getElementById('edit_city').value = this.dataset.city || '';
            document.getElementById('edit_state').value = this.dataset.state || '';
            document.getElementById('edit_country').value = this.dataset.country || '';
            document.getElementById('edit_remarks').value = this.dataset.remarks || '';
            document.getElementById('edit_status_master').value = this.dataset.status;
        });
    });
});





  document.addEventListener('DOMContentLoaded', function () {
    const deleteButtons = document.querySelectorAll('.delete-tenant-btn');

    deleteButtons.forEach(button => {
      button.addEventListener('click', function () {
        const tenantId = this.dataset.id;
        const tenantName = this.dataset.name;
        document.getElementById('delete_tenant_id').value = tenantId;
        document.getElementById('delete_tenant_name').textContent = tenantName || 'this tenant';
      });
    });
  });




//VIEW JAVASCRIPT
document.addEventListener('DOMContentLoaded', function () {
    const viewButtons = document.querySelectorAll('[data-bs-target="#viewbuldingModal"]');

    viewButtons.forEach(button => {
        button.addEventListener('click', function () {
            // Extract dataset attributes
            const data = this.dataset;
                LoadDocumentPath(data.id)
                console.log('tenant id is ',data.id)
            // Set values in modal
            document.getElementById('view_tenant_id').value = data.id || 'N/A';
            document.getElementById('view_tenant_name').value = data.name || 'N/A';
            document.getElementById('view_login_name').value = data.login || 'N/A';
            document.getElementById('view_password').value = data.password || 'N/A';
            document.getElementById('view_email').value = data.email || 'N/A';
            document.getElementById('view_mobile_no').value = data.mobile || 'N/A';
            document.getElementById('view_tin_no').value = data.tin || 'N/A';
            document.getElementById('view_nida_no').value = data.nida || 'N/A';
            document.getElementById('view_kura_id').value = data.kura || 'N/A';
            document.getElementById('view_license').value = data.license || 'N/A';
            document.getElementById('view_address').value = data.address || 'N/A';
            document.getElementById('view_city').value = data.city || 'N/A';
            document.getElementById('view_state').value = data.state || 'N/A';
            document.getElementById('view_country').value = data.country || 'N/A';
            document.getElementById('view_remarks').value = data.remarks || 'N/A';
        });
    });
});



 function LoadDocumentPath(data) {
    fetch(`/LoadDocumentPathTenant/${data}`)
        .then(response => response.json())
        .then(data => {
            console.log('Parsed document data:', data);

            const documentListContainer = document.getElementById('documentListContainer');
            documentListContainer.innerHTML = ''; // Clear previous content

          if (Array.isArray(data) && data.length > 0) {
    documentListContainer.innerHTML = `<h3 class="mb-3">Uploaded Tenants Document Lists</h3>`;

    data.forEach(doc => {
        const filePath = doc.FILE_PATH;  // Assuming this holds the document URL
        const docName = doc.DOCUMENT_NAME || 'Untitled Document'; // Display name fallback

        const docHTML = `
            <div class="d-flex justify-content-between align-items-center bg-light border p-2 mb-2 rounded">
                <span class="text-muted small fw-bold">${docName}</span>
                <a href="${filePath}" target="_blank" class="btn btn-outline-primary btn-sm">
                    <i class="fas fa-eye me-1"></i> View Document
                </a>
            </div>
        `;

        documentListContainer.innerHTML += docHTML;
    });
} else {
    documentListContainer.innerHTML = `<span class="text-muted fst-italic">No Details available</span>`;
}

        })
        .catch(err => console.error('Error loading documents:', err));
}


    document.addEventListener('DOMContentLoaded', function () {
        const branchSelect = document.getElementById('branch_id');
        const companySelect = document.getElementById('company_id');
        branchSelect.addEventListener('change', function () {
            const selectedOption = this.options[this.selectedIndex];
            const companyId = selectedOption.getAttribute('data-company');

            if (companyId) {
                companySelect.value = companyId;
            }
        });
    });



</script>



</body>
</html>