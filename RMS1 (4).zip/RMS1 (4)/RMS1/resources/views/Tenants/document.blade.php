

@section('content')
<div class="container">
    <h4 class="mb-4">Tenant Agreement Documents</h4>

    @forelse ($documents as $doc)
        <div class="card mb-4">
            <div class="card-header">
                <strong>Document:</strong> {{ $doc->DOCUMENT_NAME ?? 'N/A' }}
            </div>
            <div class="card-body">
                @php
                    $filePath = asset($doc->FILE_PATH);
                    $extension = strtolower(pathinfo($doc->FILE_PATH, PATHINFO_EXTENSION));
                @endphp

                @if ($extension === 'pdf')
                    <iframe src="{{ $filePath }}" width="100%" height="500px" class="border"></iframe>
                @elseif (in_array($extension, ['jpg', 'jpeg', 'png', 'gif', 'webp']))
                    <img src="{{ $filePath }}" alt="Document Image" class="img-fluid" style="max-width: 100%; height: auto;">
                @else
                    <p class="text-muted">Unsupported file type: {{ $extension }}</p>
                @endif

                <hr>
                <p><strong>Remarks:</strong> {{ $doc->REMARKS ?? 'N/A' }}</p>
                <p><strong>Status:</strong> {{ $doc->STATUS_MASTER ?? 'N/A' }}</p>
                <p><strong>Uploaded By:</strong> {{ $doc->CREATED_BY ?? 'N/A' }}</p>
                <p><strong>Upload Date:</strong> {{ \Carbon\Carbon::parse($doc->CREATED_DATE)->format('d M Y, H:i') }}</p>
            </div>
        </div>
    @empty
        <div class="alert alert-warning">No documents found for this agreement.</div>
    @endforelse
</div>
@endsection
