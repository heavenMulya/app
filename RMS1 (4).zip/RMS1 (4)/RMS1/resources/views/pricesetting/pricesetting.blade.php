@include ('layout.header')
@include ('layout.navbar')
@include ('layout.sidebar')

<div class="page-wrapper">
    <div class="content">
        <!-- Price List View -->
        <div id="priceListView" class="view-section">
            <div class="page-header">
                <div class="page-title">
                    <h4>Price Settings List</h4>
                    <h6>Manage Rental Prices</h6>
                </div>
                
            @if(isset($message))
    <div id="session-alert" class="alert alert-{{ $status === 'Error' ? 'danger' : 'success' }} alert-dismissible fade show"
         role="alert"
         style="position: fixed; top: 90px; right: 230px; z-index: 1055; min-width: 550px;">
        {{ $message }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>

    @if($status !== 'Error')
        <script>
            // Auto dismiss success messages after 5 seconds
            setTimeout(function () {
                const alert = document.getElementById('session-alert');
                if (alert) {
                    alert.classList.remove('show');
                    alert.classList.add('fade');
                    setTimeout(() => alert.remove(), 1000);
                }
            }, 5000);
        </script>
    @endif
@endif


                <div class="page-btn">
                    <button class="btn btn-primary" onclick="showAddPriceView()">Add New Price</button>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="table-top">
                        <div class="search-set">
                            <div class="search-path">
                                <a class="btn btn-filter" id="filter_search">
                                    <img src="assets/img/icons/filter.svg" alt="Filter">
                                    <span><img src="assets/img/icons/closes.svg" alt="Close"></span>
                                </a>
                            </div>
                            <div class="search-input">
                                <a class="btn btn-searchset"><img src="assets/img/icons/search-white.svg" alt="Search"></a>
                            </div>
                        </div>
                        <div class="wordset">
                            <ul>
                                <li><a title="PDF"><img src="assets/img/icons/pdf.svg" alt="PDF"></a></li>
                                <li><a title="Excel"><img src="assets/img/icons/excel.svg" alt="Excel"></a></li>
                                <li><a title="Print"><img src="assets/img/icons/printer.svg" alt="Print"></a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table datanew">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Company</th>
                                    <th>Branch</th>
                                    <th>Building</th>
                                    <th>Floor</th>
                                    <th>Currency</th>
                                    <th>Rental Amount</th>
                                    <th>VAT %</th>
                                    <th>VAT Rent</th>
                                    <th>Total w/o VAT</th>
                                    <th>Total w/ VAT</th>
                                    <th>Deposit</th>
                                    <th>VAT Deposit</th>
                                    <th>Final Deposit</th>
                                    <th>Remarks</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($price as $item)
                                    <tr>
                                        <td>{{ $item->PRICE_ID }}</td>
                                        <td>{{ $item->COMPANY_NAME }}</td>
                                        <td>{{ $item->BRANCH_NAME }}</td>
                                        <td>{{ $item->BUILDING_NAME }}</td>
                                        <td>{{ $item->FLOOR_NAME }}</td>
                                        <td>{{ $item->CURRENCY_NAME }}</td>
                                        <td>{{ $item->RENTAL_AMOUNT }}</td>
                                        <td>{{ $item->VAT_PERCENTAGE}}%</td>
                                        <td>{{ $item->VAT_RENT_AMOUNT }}</td>
                                        <td>{{ $item->TOTAL_RENT_AMOUNT_WITHOUT_VAT }}</td>
                                        <td>{{ $item->FINAL_RENT_AMOUNT_WITH_VAT }}</td>
                                        <td>{{ $item->DEPOSIT_AMOUNT }}</td>
                                        <td>{{ $item->VAT_DEPOSIT_AMOUNT ?? '-' }}</td>
                                        <td>{{ $item->FINAL_DEPOSIT_AMOUNT ?? '-' }}</td>
                                        <td>{{ $item->REMARKS ?? '-' }}</td>
                                        <td>
                                            <!-- <a href="javascript:void(0);" class="me-2 edit-price-btn"
                                               onclick="showEditPriceView('{{ $item->PRICE_ID }}', '{{ $item->COMPANY_ID ?? '' }}', '{{ $item->BRANCH_ID ?? '' }}', '{{ $item->BUILDING_ID ?? '' }}', '{{ $item->FLOOR_ID ?? '' }}', '{{ $item->PROPERTY_ID ?? '' }}', '{{ $item->RENTAL_TYPE_ID ?? '' }}', '{{ $item->CURRENCY_ID ?? '' }}', '{{ $item->RENTAL_AMOUNT ?? '' }}', '{{ $item->COMMON_MAINTENANCE_AMOUNT ?? '' }}', '{{ $item->TOTAL_RENT_AMOUNT_WITHOUT_VAT ?? '' }}', '{{ $item->VAT_PERCENTAGE ?? '' }}', '{{ $item->VAT_RENT_AMOUNT ?? '' }}', '{{ $item->FINAL_RENT_AMOUNT_WITH_VAT ?? '' }}', '{{ $item->WITH_HOLDING_PERCENTAGE ?? '' }}', '{{ $item->TOTAL_INCOME_AFTER_WITH_HOLDING_TAX ?? '' }}', '{{ $item->DEPOSIT_AMOUNT ?? '' }}', '{{ $item->VAT_DEPOSIT_AMOUNT ?? '' }}', '{{ $item->FINAL_DEPOSIT_AMOUNT ?? '' }}', '{{ $item->STATUS_MASTER ?? '' }}', '{{ $item->REMARKS ?? '' }}')"
                                               data-id="{{ $item->PRICE_ID }}">
                                                <img src="assets/img/icons/edit.svg" alt="Edit">
                                            </a> -->
                                            
                                            <a href="javascript:void(0);" class="me-2 edit-price-btn"
                                            data-price-id="{{ $item->PRICE_ID }}"
                                            data-company-id="{{ $item->COMPANY_ID ?? '' }}"
                                            data-branch-id="{{ $item->BRANCH_ID ?? '' }}"
                                            data-building-id="{{ $item->BUILDING_ID ?? '' }}"
                                            data-floor-id="{{ $item->FLOOR_ID ?? '' }}"
                                            data-property-id="{{ $item->PROPERTY_ID ?? '' }}"
                                            data-rental-type-id="{{ $item->RENTAL_TYPE_ID ?? '' }}"
                                            data-currency-id="{{ $item->CURRENCY_ID ?? '' }}"
                                            data-rental-amount="{{ $item->RENTAL_AMOUNT ??'' }}"
                                            data-common-maintenance="{{ $item->COMMON_MAINTENANCE_AMOUNT ?? '' }}"
                                            data-total-rent-without-vat="{{ $item->TOTAL_RENT_AMOUNT_WITHOUT_VAT ?? '' }}"
                                            data-vat-percentage="{{ $item->VAT_PERCENTAGE ?? '' }}"
                                            data-vat-rent-amount="{{ $item->VAT_RENT_AMOUNT ?? '' }}"
                                            data-final-rent-with-vat="{{ $item->FINAL_RENT_AMOUNT_WITH_VAT ?? '' }}"
                                            data-withholding-percentage="{{ $item->WITH_HOLDING_PERCENTAGE ?? '' }}"
                                            data-income-after-withholding="{{ $item->TOTAL_INCOME_AFTER_WITH_HOLDING_TAX ?? '' }}"
                                            data-deposit-amount="{{ $item->DEPOSIT_AMOUNT ?? '' }}"
                                            data-vat-deposit-amount="{{ $item->VAT_DEPOSIT_AMOUNT ?? '' }}"
                                            data-final-deposit-amount="{{ $item->FINAL_DEPOSIT_AMOUNT ?? '' }}"
                                            data-status-master="{{ $item->STATUS_MASTER ?? '' }}"
                                            data-remarks="{{ $item->REMARKS ?? '' }}"
                                            onclick="showEditPriceView(this)">
                                              <img src="assets/img/icons/edit.svg" alt="Edit">
                                          </a>

  <a href="javascript:void(0);" class="me-2 view-price-btn"
   data-price-id="{{ $item->PRICE_ID }}"
   data-company-id="{{ $item->COMPANY_ID ?? '' }}"
   data-branch-id="{{ $item->BRANCH_ID ?? '' }}"
   data-building-id="{{ $item->BUILDING_ID ?? '' }}"
   data-floor-id="{{ $item->FLOOR_ID ?? '' }}"
   data-property-id="{{ $item->PROPERTY_ID ?? '' }}"
   data-rental-type-id="{{ $item->RENTAL_TYPE_ID ?? '' }}"
   data-currency-id="{{ $item->CURRENCY_ID ?? '' }}"
   data-rental-amount="{{ $item->RENTAL_AMOUNT ?? '' }}"
   data-common-maintenance="{{ $item->COMMON_MAINTENANCE_AMOUNT ?? '' }}"
   data-total-rent-without-vat="{{ $item->TOTAL_RENT_AMOUNT_WITHOUT_VAT ?? '' }}"
   data-vat-percentage="{{ $item->VAT_PERCENTAGE ?? '' }}"
   data-vat-rent-amount="{{ $item->VAT_RENT_AMOUNT ?? '' }}"
   data-final-rent-with-vat="{{ $item->FINAL_RENT_AMOUNT_WITH_VAT ?? '' }}"
   data-withholding-percentage="{{ $item->WITH_HOLDING_PERCENTAGE ?? '' }}"
   data-income-after-withholding="{{ $item->TOTAL_INCOME_AFTER_WITH_HOLDING_TAX ?? '' }}"
   data-deposit-amount="{{ $item->DEPOSIT_AMOUNT ?? '' }}"
   data-vat-deposit-amount="{{ $item->VAT_DEPOSIT_AMOUNT ?? '' }}"
   data-final-deposit-amount="{{ $item->FINAL_DEPOSIT_AMOUNT ?? '' }}"
   data-status-master="{{ $item->STATUS_MASTER ?? '' }}"
   data-remarks="{{ $item->REMARKS ?? '' }}"
   onclick="showViewPrice(this)">
    <img src="assets/img/icons/eye.svg" alt="View">
</a>



                                          
                                          




                                            <a href="javascript:void(0);" data-bs-toggle="modal"
                                               data-bs-target="#deletePriceModal" data-id="{{ $item->PRICE_ID }}">
                                                <img src="assets/img/icons/delete.svg" alt="Delete">
                                            </a>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="16" class="text-center text-muted">No price settings available.</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Add Price  -->
        <div id="addPriceView" class="view-section" style="display: none;">
            <div class="page-header">
                <div class="page-title">
                    <h4>Add New Price Setting</h4>
                    <h6>Create a new price setting</h6>
                </div>
                <div class="page-btn">
                    <button type="button" class="btn btn-secondary" onclick="showPriceListView()">
                        <i class="fas fa-arrow-left me-1"></i>Back to List
                    </button>
                </div>
            </div>

            @if($errors->any())
                <div id="add-error-alert" class="alert alert-danger alert-dismissible fade show mb-3" role="alert">
                    <ul class="mb-0">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <script>
                    setTimeout(function () {
                        const alert = document.getElementById('add-error-alert');
                        if (alert) {
                            alert.classList.remove('show');
                            alert.classList.add('fade');
                            setTimeout(() => alert.remove(), 500);
                        }
                    }, 8000);
                </script>
            @endif

            <div class="card">
                <div class="card-body">
                    <form method="POST" action="{{ route('pricesetting.save') }}">
                        @csrf
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Company *</label>
                                <select class="form-select" name="COMPANY_ID" id="add_company_id" required>
                                    <option value="">-- Select Company --</option>
                                    @foreach ($companies as $company)
                                        <option value="{{ $company->COMPANY_ID }}">{{ $company->COMPANY_NAME }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Branch *</label>
                                <select class="form-select" name="BRANCH_ID" id="add_branch_id" required>
                                    <option value="">-- Select Branch --</option>
                                    @foreach ($branches as $branch)
                                        <option value="{{ $branch->BRANCH_ID }}">{{ $branch->BRANCH_NAME }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Building *</label>
                                <select class="form-select" name="BUILDING_ID" id="add_building_id" required>
                                    <option value="">-- Select Building --</option>
                                    @foreach ($buildings as $building)
                                        <option value="{{ $building->BUILDING_ID }}">{{ $building->BUILDING_NAME }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Floor *</label>
                                <select class="form-select" name="FLOOR_ID" id="add_floor_id" required>
                                    <option value="">-- Select Floor --</option>
                                    @if(!empty($floors))
                                        @foreach ($floors as $floor)
                                        
                                            <option value="{{ $floor->id }}">{{ $floor->FLOOR_NAME }}</option>

                                        @endforeach
                                    @endif
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Property *</label>
                                <select class="form-select" name="PROPERTY_ID" id="add_property_id" required>
                                    <option value="">-- Select Property --</option>
                                    @foreach ($properties as $property)
                                        <option value="{{ $property->PROPERTY_ID }}">{{ $property->PROPERTY_NAME }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Rental Type *</label>
                                <select class="form-select" name="RENTAL_TYPE_ID" id="add_rental_type_id" required>
                                    <option value="">-- Select Rental Type --</option>
                                    @foreach ($rental_types as $rental_type)
                                        <option value="{{ $rental_type->RENTAL_TYPE_ID }}">{{ $rental_type->RENTAL_TYPE_NAME }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Currency *</label>
                                <select class="form-select" name="CURRENCY_ID" id="add_currency_id" required>
                                    <option value="">-- Select Currency --</option>
                                    @foreach ($currencies as $currency)
                                        <option value="{{ $currency->CURRENCY_ID }}">{{ $currency->CURRENCY_NAME }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Rental Amount *</label>
                                <input type="number" name="RENTAL_AMOUNT" class="form-control" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Common Maintenance *</label>
                                <input type="number" name="COMMON_MAINTENANCE_AMOUNT" class="form-control" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Total Rent (No VAT) *</label>
                                <input type="number" name="TOTAL_RENT_AMOUNT_WITHOUT_VAT" class="form-control" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">VAT % *</label>
                                <input type="number" name="VAT_PERCENTAGE" class="form-control" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">VAT Amount *</label>
                                <input type="number" name="VAT_RENT_AMOUNT" class="form-control" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Final Rent With VAT *</label>
                                <input type="number" name="FINAL_RENT_AMOUNT_WITH_VAT" class="form-control" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Withholding % *</label>
                                <input type="number" name="WITH_HOLDING_PERCENTAGE" class="form-control" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Income After Withholding *</label>
                                <input type="number" name="TOTAL_INCOME_AFTER_WITH_HOLDING_TAX" class="form-control" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Deposit Amount *</label>
                                <input type="number" name="DEPOSIT_AMOUNT" class="form-control" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">VAT on Deposit *</label>
                                <input type="number" name="VAT_DEPOSIT_AMOUNT" class="form-control" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Final Deposit *</label>
                                <input type="number" name="FINAL_DEPOSIT_AMOUNT" class="form-control" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Remarks</label>
                                <input type="text" name="REMARKS" class="form-control">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Status *</label>
                                <select class="form-select" name="STATUS_MASTER" id="add_status_master" required>
                                    <option value="">-- Select Status --</option>
                                    <option value="ACTIVE">Active</option>
                                    <option value="INACTIVE">Inactive</option>
                                </select>
                            </div>
                            <!-- <div class="col-md-8 mb-3">
                                <label class="form-label">Remarks</label>
                                <input type="text" name="REMARKS" class="form-control">
                            </div> -->
                        </div>
                        <input type="hidden" name="PRICE_ID" value="0">
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary me-2">Save Price</button>
                            <button type="button" class="btn btn-secondary" onclick="showPriceListView()">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Edit Price View -->


        <div id="editPriceView" class="view-section" style="display: none;">
            <div class="page-header">
                <div class="page-title">
                    <h4>Edit Price Setting</h4>
                    <h6>Update price setting information</h6>
                </div>
                <div class="page-btn">
                    <button type="button" class="btn btn-secondary" onclick="showPriceListView()">
                        <i class="fas fa-arrow-left me-1"></i>Back to List
                    </button>
                </div>
            </div>

            @if(isset($message) && session('show_edit_view'))
                <div id="edit-success-alert" class="alert alert-{{ $status === 'Error' ? 'danger' : 'success' }} alert-dismissible fade show mb-3"
                     role="alert">
                    <i class="fas fa-check-circle me-2"></i>{{ $message }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <script>
                    setTimeout(function () {
                        const alert = document.getElementById('edit-success-alert');
                        if (alert) {
                            alert.classList.remove('show');
                            alert.classList.add('fade');
                            setTimeout(() => alert.remove(), 500);
                        }
                    }, 8000);
                </script>
            @endif

            <div class="card">
                <div class="card-body">
                    <form method="POST" action="{{ route('pricesetting.update') }}">
                        @csrf
                        @method('PUT')
                        <input type="hidden" name="PRICE_ID" id="edit_price_id">
                        <!-- <input type="hidden" name="stay_on_edit" value="1"> -->
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Company *</label>
                                <select class="form-select" name="COMPANY_ID" id="edit_company_id" required>
                                    <option value="">-- Select Company --</option>
                                    @foreach ($companies as $company)
                                        <option value="{{ $company->COMPANY_ID }}">{{ $company->COMPANY_NAME }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Branch *</label>
                                <select class="form-select" name="BRANCH_ID" id="edit_branch_id" required>
                                    <option value="">-- Select Branch --</option>
                                    @foreach ($branches as $branch)
                                        <option value="{{ $branch->BRANCH_ID }}">{{ $branch->BRANCH_NAME }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Building *</label>
                                <select class="form-select" name="BUILDING_ID" id="edit_building_id" required>
                                    <option value="">-- Select Building --</option>
                                    @foreach ($buildings as $building)
                                        <option value="{{ $building->BUILDING_ID }}">{{ $building->BUILDING_NAME }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Floor *</label>
                                <select class="form-select" name="FLOOR_ID" id="edit_floor_id" required>
                                    <option value="">-- Select Floor --</option>
                                    @if(!empty($floors))
                                        @foreach ($floors as $floor)
                                            <option value="{{ $floor->id }}">{{ $floor->FLOOR_NAME }}</option>
                                        @endforeach
                                    @endif
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Property *</label>
                                <select class="form-select" name="PROPERTY_ID" id="edit_property_id" required>
                                    <option value="">-- Select Property --</option>
                                    @foreach ($properties as $property)
                                        <option value="{{ $property->PROPERTY_ID }}">{{ $property->PROPERTY_NAME }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Rental Type *</label>
                                <select class="form-select" name="RENTAL_TYPE_ID" id="edit_rental_type_id" required>
                                    <option value="">-- Select Rental Type --</option>
                                    @foreach ($rental_types as $rental_type)
                                        <option value="{{ $rental_type->RENTAL_TYPE_ID }}">{{ $rental_type->RENTAL_TYPE_NAME }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Currency *</label>
                                <select class="form-select" name="CURRENCY_ID" id="edit_currency_id" required>
                                    <option value="">-- Select Currency --</option>
                                    @foreach ($currencies as $currency)
                                        <option value="{{ $currency->CURRENCY_ID }}">{{ $currency->CURRENCY_NAME }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Rental Amount *</label>
                                <input type="number" name="RENTAL_AMOUNT" id="edit_rental_amount" class="form-control" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Common Maintenance *</label>
                                <input type="number" name="COMMON_MAINTENANCE_AMOUNT" id="edit_common_maintenance_amount" class="form-control" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Total Rent (No VAT) *</label>
                                <input type="number" name="TOTAL_RENT_AMOUNT_WITHOUT_VAT" id="edit_total_rent_without_vat" class="form-control" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">VAT % *</label>
                                <input type="number" name="VAT_PERCENTAGE" id="edit_vat_percentage" class="form-control" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">VAT Amount *</label>
                                <input type="number" name="VAT_RENT_AMOUNT" id="edit_vat_rent_amount" class="form-control" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Final Rent With VAT *</label>
                                <input type="number" name="FINAL_RENT_AMOUNT_WITH_VAT" id="edit_final_rent_with_vat" class="form-control" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Withholding % *</label>
                                <input type="number" name="WITH_HOLDING_PERCENTAGE" id="edit_withholding_percentage" class="form-control" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Income After Withholding *</label>
                                <input type="number" name="TOTAL_INCOME_AFTER_WITH_HOLDING_TAX" id="edit_income_after_withholding" class="form-control" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Deposit Amount *</label>
                                <input type="number" name="DEPOSIT_AMOUNT" id="edit_deposit_amount" class="form-control" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">VAT on Deposit *</label>
                                <input type="number" name="VAT_DEPOSIT_AMOUNT" id="edit_vat_deposit_amount" class="form-control" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Final Deposit *</label>
                                <input type="number" name="FINAL_DEPOSIT_AMOUNT" id="edit_final_deposit_amount" class="form-control" required>
                            </div>
                            <div class="col-md-8 mb-3">
                                <label class="form-label">Remarks</label>
                                <input type="text" name="REMARKS" id="edit_remarks" class="form-control">
                            </div>

                            <div class="col-md-4 mb-3">
                                <label class="form-label">Status *</label>
                                <select class="form-select" name="STATUS_MASTER" id="edit_status_master" required>
                                    <option value="">-- Select Status --</option>
                                    <option value="ACTIVE">Active</option>
                                    <option value="INACTIVE">Inactive</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary me-2">
                                <i class="fas fa-save me-1"></i>Update Price
                            </button>
                            <button type="button" class="btn btn-secondary" onclick="showPriceListView()">
                                <i class="fas fa-arrow-left me-1"></i>Back to List
                            </button>
                            <button type="button" class="btn btn-secondary" onclick="resetEditForm()">
                                <i class="fas fa-undo me-1"></i>Reset Form
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

<!-- view -->
 <div class="modal fade" id="viewPriceModal" tabindex="-1" aria-labelledby="viewPriceModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="viewPriceModalLabel">View Price Setting</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body">
        <form id="viewPriceForm">
          <input type="hidden" id="view_price_id">

          <div class="row">
            <!-- Company -->
            <div class="col-md-4 mb-3">
              <label class="form-label">Company *</label>
              <select class="form-select" id="view_company_id" disabled>
                <option value="">-- Select Company --</option>
                @foreach ($companies as $company)
                  <option value="{{ $company->COMPANY_ID }}">{{ $company->COMPANY_NAME }}</option>
                @endforeach
              </select>
            </div>

            <!-- Branch -->
            <div class="col-md-4 mb-3">
              <label class="form-label">Branch *</label>
              <select class="form-select" id="view_branch_id" disabled>
                <option value="">-- Select Branch --</option>
                @foreach ($branches as $branch)
                  <option value="{{ $branch->BRANCH_ID }}">{{ $branch->BRANCH_NAME }}</option>
                @endforeach
              </select>
            </div>

            <!-- Building -->
            <div class="col-md-4 mb-3">
              <label class="form-label">Building *</label>
              <select class="form-select" id="view_building_id" disabled>
                <option value="">-- Select Building --</option>
                @foreach ($buildings as $building)
                  <option value="{{ $building->BUILDING_ID }}">{{ $building->BUILDING_NAME }}</option>
                @endforeach
              </select>
            </div>

            <!-- Floor -->
            <div class="col-md-4 mb-3">
              <label class="form-label">Floor *</label>
              <select class="form-select" id="view_floor_id" disabled>
                <option value="">-- Select Floor --</option>
                @foreach ($floors as $floor)
                  <option value="{{ $floor->id }}">{{ $floor->FLOOR_NAME }}</option>
                @endforeach
              </select>
            </div>

            <!-- Property -->
            <div class="col-md-4 mb-3">
              <label class="form-label">Property *</label>
              <select class="form-select" id="view_property_id" disabled>
                <option value="">-- Select Property --</option>
                @foreach ($properties as $property)
                  <option value="{{ $property->PROPERTY_ID }}">{{ $property->PROPERTY_NAME }}</option>
                @endforeach
              </select>
            </div>

            <!-- Rental Type -->
            <div class="col-md-4 mb-3">
              <label class="form-label">Rental Type *</label>
              <select class="form-select" id="view_rental_type_id" disabled>
                <option value="">-- Select Rental Type --</option>
                @foreach ($rental_types as $rental_type)
                  <option value="{{ $rental_type->RENTAL_TYPE_ID }}">{{ $rental_type->RENTAL_TYPE_NAME }}</option>
                @endforeach
              </select>
            </div>

            <!-- Currency -->
            <div class="col-md-4 mb-3">
              <label class="form-label">Currency *</label>
              <select class="form-select" id="view_currency_id" disabled>
                <option value="">-- Select Currency --</option>
                @foreach ($currencies as $currency)
                  <option value="{{ $currency->CURRENCY_ID }}">{{ $currency->CURRENCY_NAME }}</option>
                @endforeach
              </select>
            </div>

            <!-- Amounts -->
            <div class="col-md-4 mb-3">
              <label class="form-label">Rental Amount *</label>
              <input type="number" id="view_rental_amount" class="form-control" disabled>
            </div>
            <div class="col-md-4 mb-3">
              <label class="form-label">Common Maintenance *</label>
              <input type="number" id="view_common_maintenance_amount" class="form-control" disabled>
            </div>
            <div class="col-md-4 mb-3">
              <label class="form-label">Total Rent (No VAT) *</label>
              <input type="number" id="view_total_rent_without_vat" class="form-control" disabled>
            </div>
            <div class="col-md-4 mb-3">
              <label class="form-label">VAT % *</label>
              <input type="number" id="view_vat_percentage" class="form-control" disabled>
            </div>
            <div class="col-md-4 mb-3">
              <label class="form-label">VAT Amount *</label>
              <input type="number" id="view_vat_rent_amount" class="form-control" disabled>
            </div>
            <div class="col-md-4 mb-3">
              <label class="form-label">Final Rent With VAT *</label>
              <input type="number" id="view_final_rent_with_vat" class="form-control" disabled>
            </div>
            <div class="col-md-4 mb-3">
              <label class="form-label">Withholding % *</label>
              <input type="number" id="view_withholding_percentage" class="form-control" disabled>
            </div>
            <div class="col-md-4 mb-3">
              <label class="form-label">Income After Withholding *</label>
              <input type="number" id="view_income_after_withholding" class="form-control" disabled>
            </div>
            <div class="col-md-4 mb-3">
              <label class="form-label">Deposit Amount *</label>
              <input type="number" id="view_deposit_amount" class="form-control" disabled>
            </div>
            <div class="col-md-4 mb-3">
              <label class="form-label">VAT on Deposit *</label>
              <input type="number" id="view_vat_deposit_amount" class="form-control" disabled>
            </div>
            <div class="col-md-4 mb-3">
              <label class="form-label">Final Deposit *</label>
              <input type="number" id="view_final_deposit_amount" class="form-control" disabled>
            </div>

            <!-- Remarks -->
            <div class="col-md-8 mb-3">
              <label class="form-label">Remarks</label>
              <input type="text" id="view_remarks" class="form-control" disabled>
            </div>

            <!-- Status -->
            <div class="col-md-4 mb-3">
              <label class="form-label">Status *</label>
              <select class="form-select" id="view_status_master" disabled>
                <option value="">-- Select Status --</option>
                <option value="ACTIVE">Active</option>
                <option value="INACTIVE">Inactive</option>
              </select>
            </div>
          </div>

          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
              <i class="fas fa-times me-1"></i> Close
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

        <!-- Delete Price Modal -->
        <div class="modal fade" id="deletePriceModal" tabindex="-1" aria-labelledby="deletePriceModal" aria-hidden="true">
            <div class="modal-dialog">
                <form method="POST" action="{{ route('pricesetting.delete') }}">
                    @csrf
                    <!-- @method('DELETE') -->
                    <input type="hidden" name="PRICE_ID" id="PRICE_ID">
                    <div class="modal-content">
                        <div class="modal-header bg-danger text-red">
                            <h5 class="modal-title" id="deletePriceLabel">Confirm Price Deletion</h5>
                            <button type="button" class="btn-close text-white" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body text-center">
                            <p>Are you sure you want to delete <strong id="PRICE_ID">Price ID</strong> from the system?</p>
                            <p>This action cannot be undone.</p>
                        </div>
                        <div class="modal-footer justify-content-center">
                            <button type="submit" class="btn btn-danger">Yes, Delete</button>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@include ('layout.footer')

<script >
  document.addEventListener('DOMContentLoaded', function () {
    // Debug: Check if script is running
    console.log('DOMContentLoaded triggered');

    // Make functions globally accessible
    window.showPriceListView = showPriceListView;
    window.showAddPriceView = showAddPriceView;
    window.showEditPriceView = showEditPriceView;
    window.resetEditForm = resetEditForm;

    // View switching functions
    function showPriceListView() {
        console.log('Showing Price List View');
        hideAllViews();
        showViewWithAnimation('priceListView');
    }

    function showAddPriceView() {
        console.log('Showing Add Price View');
        hideAllViews();
        showViewWithAnimation('addPriceView');
        // Initialize cascading dropdowns for add view
        initializeCascadingDropdowns('add');
    }


    function showEditPriceView(element) {
    console.log('Showing Edit Price View');
    hideAllViews();
    showViewWithAnimation('editPriceView');
    
    // Retrieve data from data attributes
    const priceId = element.dataset.priceId || '';
    const companyId = element.dataset.companyId || '';
    const branchId = element.dataset.branchId || '';
    const buildingId = element.dataset.buildingId || '';
    const floorId = element.dataset.floorId || '';
    const propertyId = element.dataset.propertyId || '';
    const rentalTypeId = element.dataset.rentalTypeId || '';
    const currencyId = element.dataset.currencyId || '';
    const rentalAmount = element.dataset.rentalAmount || '';
    const commonMaintenance = element.dataset.commonMaintenance || '';
    const totalRentWithoutVat = element.dataset.totalRentWithoutVat || '';
    const vatPercentage = element.dataset.vatPercentage || '';
    const vatRentAmount = element.dataset.vatRentAmount || '';
    const finalRentWithVat = element.dataset.finalRentWithVat || '';
    const withholdingPercentage = element.dataset.withholdingPercentage || '';
    const incomeAfterWithholding = element.dataset.incomeAfterWithholding || '';
    const depositAmount = element.dataset.depositAmount || '';
    const vatDepositAmount = element.dataset.vatDepositAmount || '';
    const finalDepositAmount = element.dataset.finalDepositAmount || '';
    const statusMaster = element.dataset.statusMaster || '';
    const remarks = element.dataset.remarks || '';
    
    // Populate form fields
    document.getElementById('edit_price_id').value = priceId;
    document.getElementById('edit_company_id').value = companyId;
    document.getElementById('edit_branch_id').value = branchId;
    document.getElementById('edit_building_id').value = buildingId;
    document.getElementById('edit_floor_id').value = floorId;
    document.getElementById('edit_property_id').value = propertyId;
    document.getElementById('edit_rental_type_id').value = rentalTypeId;
    document.getElementById('edit_currency_id').value = currencyId;
    document.getElementById('edit_rental_amount').value = rentalAmount;
    document.getElementById('edit_common_maintenance_amount').value = commonMaintenance;
    document.getElementById('edit_total_rent_without_vat').value = totalRentWithoutVat;
    document.getElementById('edit_vat_percentage').value = vatPercentage;
    document.getElementById('edit_vat_rent_amount').value = vatRentAmount;
    document.getElementById('edit_final_rent_with_vat').value = finalRentWithVat;
    document.getElementById('edit_withholding_percentage').value = withholdingPercentage;
    document.getElementById('edit_income_after_withholding').value = incomeAfterWithholding;
    document.getElementById('edit_deposit_amount').value = depositAmount;
    document.getElementById('edit_vat_deposit_amount').value = vatDepositAmount;
    document.getElementById('edit_final_deposit_amount').value = finalDepositAmount;
    document.getElementById('edit_status_master').value = statusMaster;
    document.getElementById('edit_remarks').value = remarks;
    
    // Initialize cascading dropdowns for edit view
    initializeCascadingDropdowns('edit');
}

    function resetEditForm() {
        console.log('Resetting edit form');
        const editForm = document.querySelector('#editPriceView form');
        if (editForm) {
            editForm.reset();
            // Reset dropdowns to first option
            const selects = editForm.querySelectorAll('select');
            selects.forEach(select => {
                select.selectedIndex = 0;
            });
        }
    }

    // Helper functions for view management
    function hideAllViews() {
        const views = document.querySelectorAll('.view-section');
        views.forEach(view => {
            view.style.display = 'none';
        });
    }

    function showViewWithAnimation(viewId) {
        const view = document.getElementById(viewId);
        if (view) {
            view.style.display = 'block';
            // Add fade-in animation
            view.style.opacity = '0';
            setTimeout(() => {
                view.style.transition = 'opacity 0.3s ease-in-out';
                view.style.opacity = '1';
            }, 10);
        }
    }

    // Initialize cascading dropdowns
    function initializeCascadingDropdowns(prefix) {
        const companySelect = document.getElementById(`${prefix}_company_id`);
        const branchSelect = document.getElementById(`${prefix}_branch_id`);
        const buildingSelect = document.getElementById(`${prefix}_building_id`);
        const floorSelect = document.getElementById(`${prefix}_floor_id`);
        const propertySelect = document.getElementById(`${prefix}_property_id`);

        // Company change handler
        if (companySelect) {
            companySelect.addEventListener('change', function() {
                const companyId = this.value;
                
                console.log('Company changed:', companyId);
                
                // Reset dependent dropdowns
                resetDropdown(branchSelect, '-- Select Branch --');
                resetDropdown(buildingSelect, '-- Select Building --');
                resetDropdown(floorSelect, '-- Select Floor --');
                resetDropdown(propertySelect, '-- Select Property --');
                
                if (companyId) {
                    // Filter branches based on company
                    filterBranches(branchSelect, companyId);
                }
            });
        }

        // Branch change handler
        if (branchSelect) {
            branchSelect.addEventListener('change', function() {
                const branchId = this.value;
                console.log('Branch changed:', branchId);
                
                // Reset dependent dropdowns
                resetDropdown(buildingSelect, '-- Select Building --');
                resetDropdown(floorSelect, '-- Select Floor --');
                resetDropdown(propertySelect, '-- Select Property --');
                
                if (branchId) {
                    // Filter buildings based on branch
                    filterBuildings(buildingSelect, branchId);
                }
            });
        }

        // Building change handler
        if (buildingSelect) {
            buildingSelect.addEventListener('change', function() {
                const buildingId = this.value;
                console.log('Building changed:', buildingId);
                
                // Reset dependent dropdowns
                resetDropdown(floorSelect, '-- Select Floor --');
                resetDropdown(propertySelect, '-- Select Property --');
                
                if (buildingId) {
                    // Filter floors based on building
                    filterFloors(floorSelect, buildingId);
                }
            });
        }

        // Floor change handler
        if (floorSelect) {
            floorSelect.addEventListener('change', function() {
                const floorId = this.value;
                console.log('Floor changed:', floorId);
                
                // Reset dependent dropdowns
                resetDropdown(propertySelect, '-- Select Property --');
                
                if (floorId) {
                    // Filter properties based on floor
                    filterProperties(propertySelect, floorId);
                }
            });
        }
    }

    // Helper function to reset dropdown
    function resetDropdown(dropdown, defaultText) {
        if (dropdown) {
            dropdown.innerHTML = `<option value="">${defaultText}</option>`;
        }
    }

    // Filter functions (these would typically make AJAX calls to get filtered data)
    function filterBranches(branchSelect, companyId) {
    fetch(`/branches/${companyId}`)
        .then(res => res.json())
        .then(data => {
            data.forEach(item => {
                const option = new Option(item.BRANCH_NAME, item.BRANCH_ID);
                branchSelect.appendChild(option);
            });
        });
}

 
function filterBuildings(buildingSelect, branchId) {
    const companyId = document.getElementById('add_company_id').value || document.getElementById('edit_company_id').value;
    fetch(`/buildings?company_id=${companyId}&branch_id=${branchId}`)
        .then(res => res.json())
        .then(data => {
            data.forEach(item => {
                const option = new Option(item.BUILDING_NAME, item.BUILDING_ID);
                buildingSelect.appendChild(option);
            });
        });
}
   function filterFloors(floorSelect, buildingId) {
    const companyId = document.getElementById('add_company_id').value || document.getElementById('edit_company_id').value;
    const branchId = document.getElementById('add_branch_id').value || document.getElementById('edit_branch_id').value;
    fetch(`/floors?company_id=${companyId}&branch_id=${branchId}&building_id=${buildingId}`)
        .then(res => res.json())
        .then(data => {
            data.forEach(item => {
                const option = new Option(item.FLOOR_NAME, item.id);
                floorSelect.appendChild(option);
            });
        });
}
  function filterProperties(propertySelect, floorId) {
    const companyId = document.getElementById('add_company_id').value || document.getElementById('edit_company_id').value;
    const branchId = document.getElementById('add_branch_id').value || document.getElementById('edit_branch_id').value;
    const buildingId = document.getElementById('add_building_id').value || document.getElementById('edit_building_id').value;
    console.log(companyId, branchId, buildingId, floorId);
    fetch(`/properties?company_id=${companyId}&branch_id=${branchId}&building_id=${buildingId}&floor_id=${floorId}`)
    
        .then(res => res.json())
        .then(data => {
            data.forEach(item => {
                const option = new Option(item.PROPERTY_NAME, item.PROPERTY_ID);
                propertySelect.appendChild(option);
            });
        });
}

    // Delete modal functionality
    
    const deletePriceModal = document.getElementById('deletePriceModal');
    if (deletePriceModal) {
        deletePriceModal.addEventListener('show.bs.modal', function (event) {
            const button = event.relatedTarget;
            const priceId = button.getAttribute('data-id');
            const priceName = button.getAttribute('data-name');
            
            // Update modal content
            document.getElementById('PRICE_ID').value = priceId;
            document.getElementById('PRICE_ID').textContent = priceName;
        });
    }

    // Auto-calculation functionality
    function setupAutoCalculations(prefix) {
        const rentalAmount = document.getElementById(`${prefix}_rental_amount`);
        const commonMaintenance = document.getElementById(`${prefix}_common_maintenance_amount`);
        const totalRentWithoutVat = document.getElementById(`${prefix}_total_rent_without_vat`);
        const vatPercentage = document.getElementById(`${prefix}_vat_percentage`);
        const vatRentAmount = document.getElementById(`${prefix}_vat_rent_amount`);
        const finalRentWithVat = document.getElementById(`${prefix}_final_rent_with_vat`);
        const withholdingPercentage = document.getElementById(`${prefix}_withholding_percentage`);
        const incomeAfterWithholding = document.getElementById(`${prefix}_income_after_withholding`);
        const depositAmount = document.getElementById(`${prefix}_deposit_amount`);
        const vatDepositAmount = document.getElementById(`${prefix}_vat_deposit_amount`);
        const finalDepositAmount = document.getElementById(`${prefix}_final_deposit_amount`);

        // Function to calculate total rent without VAT
        function calculateTotalRentWithoutVat() {
            const rental = parseFloat(rentalAmount.value) || 0;
            const maintenance = parseFloat(commonMaintenance.value) || 0;
            const total = rental + maintenance;
            totalRentWithoutVat.value = total.toFixed(2);
            calculateVatAmount();
        }

        // Function to calculate VAT amount
        function calculateVatAmount() {
            const total = parseFloat(totalRentWithoutVat.value) || 0;
            const vatPercent = parseFloat(vatPercentage.value) || 0;
            const vatAmount = (total * vatPercent) / 100;
            vatRentAmount.value = vatAmount.toFixed(2);
            calculateFinalRentWithVat();
        }

        // Function to calculate final rent with VAT
        function calculateFinalRentWithVat() {
            const total = parseFloat(totalRentWithoutVat.value) || 0;
            const vat = parseFloat(vatRentAmount.value) || 0;
            const finalRent = total + vat;
            finalRentWithVat.value = finalRent.toFixed(2);
            calculateIncomeAfterWithholding();
        }

        // Function to calculate income after withholding
        function calculateIncomeAfterWithholding() {
            const finalRent = parseFloat(finalRentWithVat.value) || 0;
            const withholdingPercent = parseFloat(withholdingPercentage.value) || 0;
            const withholdingAmount = (finalRent * withholdingPercent) / 100;
            const incomeAfter = finalRent - withholdingAmount;
            incomeAfterWithholding.value = incomeAfter.toFixed(2);
        }

        // Function to calculate VAT on deposit
        function calculateVatOnDeposit() {
            const deposit = parseFloat(depositAmount.value) || 0;
            const vatPercent = parseFloat(vatPercentage.value) || 0;
            const vatDeposit = (deposit * vatPercent) / 100;
            vatDepositAmount.value = vatDeposit.toFixed(2);
            calculateFinalDeposit();
        }

        // Function to calculate final deposit
        function calculateFinalDeposit() {
            const deposit = parseFloat(depositAmount.value) || 0;
            const vatDeposit = parseFloat(vatDepositAmount.value) || 0;
            const finalDeposit = deposit + vatDeposit;
            finalDepositAmount.value = finalDeposit.toFixed(2);
        }

        // Add event listeners
        if (rentalAmount) rentalAmount.addEventListener('input', calculateTotalRentWithoutVat);
        if (commonMaintenance) commonMaintenance.addEventListener('input', calculateTotalRentWithoutVat);
        if (vatPercentage) {
            vatPercentage.addEventListener('input', function() {
                calculateVatAmount();
                calculateVatOnDeposit();
            });
        }
        if (withholdingPercentage) withholdingPercentage.addEventListener('input', calculateIncomeAfterWithholding);
        if (depositAmount) depositAmount.addEventListener('input', calculateVatOnDeposit);
    }

    // Initialize auto-calculations for both add and edit forms
    setupAutoCalculations('add');
    setupAutoCalculations('edit');

    // Initialize the page
    showPriceListView();

    // Handle form submissions with loading states
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const submitButton = form.querySelector('button[type="submit"]');
            if (submitButton) {
                submitButton.disabled = true;
                submitButton.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Processing...';
                
                // Re-enable button after 5 seconds as fallback
                setTimeout(() => {
                    submitButton.disabled = false;
                    submitButton.innerHTML = submitButton.getAttribute('data-original-text') || 'Submit';
                }, 5000);
            }
        });
    });

    // Store original button text
    document.querySelectorAll('button[type="submit"]').forEach(button => {
        button.setAttribute('data-original-text', button.innerHTML);
    });
    // Handle search functionality
    const searchInput = document.querySelector('.search-input input');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const tableRows = document.querySelectorAll('.table tbody tr');
            
            tableRows.forEach(row => {
                const text = row.textContent.toLowerCase();
                if (text.includes(searchTerm)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    }

    // Handle export functionality
    const exportButtons = document.querySelectorAll('.wordset a');
    exportButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const title = this.getAttribute('title');
            console.log(`Exporting to ${title}`);
            // You would implement actual export functionality here
            alert(`Export to ${title} functionality would be implemented here`);
        });
    });

    console.log('Price Settings JavaScript initialized successfully');
});



    function showEditPriceView(el) {
        // Show the edit form
        document.getElementById('editPriceView').style.display = 'block';

        // Map dataset to form fields
        const map = {
            'priceId': 'edit_price_id',
            'companyId': 'edit_company_id',
            'branchId': 'edit_branch_id',
            'buildingId': 'edit_building_id',
            'floorId': 'edit_floor_id',
            'propertyId': 'edit_property_id',
            'rentalTypeId': 'edit_rental_type_id',
            'currencyId': 'edit_currency_id',
            'rentalAmount': 'edit_rental_amount',
            'commonMaintenance': 'edit_common_maintenance_amount',
            'totalRentWithoutVat': 'edit_total_rent_without_vat',
            'vatPercentage': 'edit_vat_percentage',
            'vatRentAmount': 'edit_vat_rent_amount',
            'finalRentWithVat': 'edit_final_rent_with_vat',
            'withholdingPercentage': 'edit_withholding_percentage',
            'incomeAfterWithholding': 'edit_income_after_withholding',
            'depositAmount': 'edit_deposit_amount',
            'vatDepositAmount': 'edit_vat_deposit_amount',
            'finalDepositAmount': 'edit_final_deposit_amount',
            'statusMaster': 'edit_status_master',
            'remarks': 'edit_remarks'
        };

        for (const [dataKey, inputId] of Object.entries(map)) {
            const value = el.dataset[dataKey.replace(/([A-Z])/g, '-$1').toLowerCase()];
            const inputElement = document.getElementById(inputId);

            if (inputElement) {
                if (inputElement.tagName === 'SELECT' || inputElement.tagName === 'INPUT') {
                    inputElement.value = value ?? '';
                }
            }
        }
    }


function showViewPrice(element) {
  // Read data attributes from clicked element
  const data = element.dataset;
  const viewModal = new bootstrap.Modal(document.getElementById('viewPriceModal'));
  viewModal.show();
  // Set the values into the view modal inputs
  document.getElementById('view_price_id').value = data.priceId || '';
  document.getElementById('view_company_id').value = data.companyId || '';
  document.getElementById('view_branch_id').value = data.branchId || '';
  document.getElementById('view_building_id').value = data.buildingId || '';
  document.getElementById('view_floor_id').value = data.floorId || '';
  document.getElementById('view_property_id').value = data.propertyId || '';
  document.getElementById('view_rental_type_id').value = data.rentalTypeId || '';
  document.getElementById('view_currency_id').value = data.currencyId || '';

  document.getElementById('view_rental_amount').value = data.rentalAmount || '';
  document.getElementById('view_common_maintenance_amount').value = data.commonMaintenance || '';
  document.getElementById('view_total_rent_without_vat').value = data.totalRentWithoutVat || '';
  document.getElementById('view_vat_percentage').value = data.vatPercentage || '';
  document.getElementById('view_vat_rent_amount').value = data.vatRentAmount || '';
  document.getElementById('view_final_rent_with_vat').value = data.finalRentWithVat || '';
  document.getElementById('view_withholding_percentage').value = data.withholdingPercentage || '';
  document.getElementById('view_income_after_withholding').value = data.incomeAfterWithholding || '';
  document.getElementById('view_deposit_amount').value = data.depositAmount || '';
  document.getElementById('view_vat_deposit_amount').value = data.vatDepositAmount || '';
  document.getElementById('view_final_deposit_amount').value = data.finalDepositAmount || '';

  document.getElementById('view_status_master').value = data.statusMaster || '';
  document.getElementById('view_remarks').value = data.remarks || '';

  // Finally, show your modal (Bootstrap 5 example)

}




</script>

<style>
.view-section {
    opacity: 0;
    transform: translateX(30px);
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    display: none;
}

.view-section.view-active {
    opacity: 1;
    transform: translateX(0);
}

.form-actions {
    margin-top: 2rem;
    padding-top: 1rem;
    border-top: 1px solid #dee2e6;
}

.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
}

.btn-sm {
    padding: 0.25rem 0.5rem;
    border-radius: 0.25rem;
    transition: all 0.3s ease;
}

.btn-sm:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.alert i {
    display: block;
    margin-bottom: 1rem;
}

#edit-success-alert {
    border-left: 4px solid #28a745;
    background-color: #d4edda;
    border-color: #c3e6cb;
}

#edit-success-alert .fas {
    color: #28a745;
}

.form-actions .btn {
    min-width: 120px;
    transition: all 0.3s ease;
}

.form-actions .btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}

.card {
    transition: all 0.3s ease;
    border: none;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.card:hover {
    box-shadow: 0 4px 20px rgba(0,0,0,0.15);
}

.table-responsive {
    animation: fadeInUp 0.5s ease-out;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.modal-content {
    border: none;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
}

.modal-header {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-radius: 15px 15px 0 0;
}

.modal-body {
    padding: 2rem;
}

.modal-footer {
    background: #f8f9fa;
    border-radius: 0 0 15px 15px;
}

.modal .btn {
    transition: all 0.3s ease;
    border-radius: 8px;
    padding: 0.5rem 1.5rem;
}

.modal .btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}

.form-control, .form-select {
    transition: all 0.3s ease;
    border-radius: 8px;
}

.form-control:focus, .form-select:focus {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,123,255,0.2);
}

.page-wrapper {
    animation: fadeIn 0.5s ease-out;
}

@keyframes fadeIn {
    from {
        opacity: 0;
    }
    to {
        opacity: 1;
    }
}

.btn-added:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,123,255,0.3);
}

@media (max-width: 768px) {
    .page-header {
        flex-direction: column;
        gap: 1rem;
    }
    
    .page-btn {
        width: 100%;
    }
    
    .form-actions .btn {
        width: 100%;
        margin-bottom: 0.5rem;
    }
    
    .view-section {
        transform: translateY(20px);
    }
    
    .view-section.view-active {
        transform: translateY(0);
    }
}

@keyframes inputFocus {
    0% {
        box-shadow: 0 0 0 0 rgba(0,123,255,0.5);
    }
    100% {
        box-shadow: 0 0 0 3px rgba(0,123,255,0.2);
    }
}

.status-badge {
    padding: 0.25rem 0.75rem;
    border-radius: 50px;
    font-size: 0.875rem;
    font-weight: 500;
}

.status-active {
    background-color: #d4edda;
    color: #155724;
}

.status-inactive {
    background-color: #f8d7da;
    color: #721c24;
}
</style>