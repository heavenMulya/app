@include ('layout.header')
@include ('layout.navbar')
@include ('layout.sidebar')

<div class="page-wrapper">
    <div class="content">
        <div class="page-header">
            <div class="page-title">
                <h4>Price Settings List</h4>
                <h6>Manage Rental Prices</h6>
            </div>
            @if(isset($message))
                <div id="session-alert" class="alert alert-{{ $status === 'Error' ? 'danger' : 'success' }} alert-dismissible fade show"
                     role="alert"
                     style="position: fixed; top: 90px; right: 230px; z-index: 1055; min-width: 550px;">
                    {{ $message }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>

                @if($status !== 'Error')
                    <script>
                        setTimeout(function () {
                            const alert = document.getElementById('session-alert');
                            if (alert) {
                                alert.classList.remove('show');
                                alert.classList.add('fade');
                                setTimeout(() => alert.remove(), 1000);
                            }
                        }, 5000);
                    </script>
                @endif
            @endif
<button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addPriceModal">
    Add New Price
</button>
        </div>
        <div class="card">
            <div class="card-body">
                <div class="table-top">
                    <div class="search-set">
                        <div class="search-path">
                            <a class="btn btn-filter" id="filter_search">
                                <img src="assets/img/icons/filter.svg" alt="Filter">
                                <span><img src="assets/img/icons/closes.svg" alt="Close"></span>
                            </a>
                        </div>
                        <div class="search-input">
                            <a class="btn btn-searchset"><img src="assets/img/icons/search-white.svg" alt="Search"></a>
                        </div>
                    </div>
                    <div class="wordset">
                        <ul>
                            <li><a title="PDF"><img src="assets/img/icons/pdf.svg" alt="PDF"></a></li>
                            <li><a title="Excel"><img src="assets/img/icons/excel.svg" alt="Excel"></a></li>
                            <li><a title="Print"><img src="assets/img/icons/printer.svg" alt="Print"></a></li>
                        </ul>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table datanew">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Company</th>
                                <th>Branch</th>
                                <th>Building</th>
                                <th>Floor</th>
                                <th>Currency</th>
                                <th>Rental Amount</th>
                                <th>VAT %</th>
                                <th>VAT Rent</th>
                                <th>Total w/o VAT</th>
                                <th>Total w/ VAT</th>
                                <th>Deposit</th>
                                <th>VAT Deposit</th>
                                <th>Final Deposit</th>
                                <th>Remarks</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($price as $item)
                                <tr>
                                    <td>{{ $item->PRICE_ID }}</td>
                                    <td>{{ $item->COMPANY_NAME }}</td>
                                    <td>{{ $item->BRANCH_NAME }}</td>
                                    <td>{{ $item->BUILDING_NAME }}</td>
                                    <td>{{ $item->FLOOR_NAME }}</td>
                                    <td>{{ $item->CURRENCY_NAME }}</td>
                                    <td>{{ $item->RENTAL_AMOUNT }}</td>
                                    <td>{{ $item->VAT_PERCENTAGE}}%</td>
                                    <td>{{ $item->VAT_RENT_AMOUNT }}</td>
                                    <td>{{ $item->TOTAL_RENT_AMOUNT_WITHOUT_VAT }}</td>
                                    <td>{{ $item->FINAL_RENT_AMOUNT_WITH_VAT }}</td>
                                    <td>{{ $item->DEPOSIT_AMOUNT }}</td>
                                    <td>{{ $item->VAT_DESPOSIT_AMOUNT}}</td>
                                    <td>{{ $item->FINAL_DEPOSIT_AMOUNT}}</td>
                                    <td>{{ $item->REMARKS ?? '-' }}</td>
                                    <td>
                                        <!-- Actions (e.g., Edit/Delete) -->
                                        <a href="javascript:void(0);" class="me-2 edit-price-btn" data-bs-toggle="modal"
                                           data-bs-target="#editPriceModal" data-id="{{ $item->PRICE_ID }}">
                                            <img src="assets/img/icons/edit.svg" alt="Edit">
                                        </a>
                                        <a href="javascript:void(0);" class="delete-price-btn" data-bs-toggle="modal"
                                           data-bs-target="#deletePriceModal" data-id="{{ $item->PRICE_ID }}">
                                            <img src="assets/img/icons/delete.svg" alt="Delete">
                                        </a>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="16" class="text-center text-muted">No price settings available.</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div> <!-- .table-responsive -->
            </div> <!-- .card-body -->
        </div> <!-- .card -->
    </div> <!-- .content -->
</div> <!-- .page-wrapper -->


<!-- Add Price Setting Modal -->
<div class="modal fade" id="addPriceModal" tabindex="-1" aria-labelledby="addPriceLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addPriceLabel">Add New Price Setting</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body">
        <form method="POST" action="{{ route('pricesetting.save') }}">
          @csrf
          <div class="row">
            {{-- Dropdowns --}}
            <div class="col-md-4 mb-3">
              <label class="form-label">Company</label>
              <select class="form-select" name="COMPANY_ID" required>
                <option value="">-- Select Company --</option>
                @foreach ($companies as $company)
                  <option value="{{ $company->COMPANY_ID }}">{{ $company->COMPANY_NAME }}</option>
                @endforeach
              </select>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Branch</label>
              <select class="form-select" name="BRANCH_ID" required>
                <option value="">-- Select Branch --</option>
                @foreach ($branches as $branch)
                  <option value="{{ $branch->BRANCH_ID }}">{{ $branch->BRANCH_NAME }}</option>
                @endforeach
              </select>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Building</label>
              <select class="form-select" name="BUILDING_ID" required>
                <option value="">-- Select Building --</option>
                @foreach ($buildings as $building)
                  <option value="{{ $building->BUILDING_ID }}">{{ $building->BUILDING_NAME }}</option>
                @endforeach
              </select>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Floor</label>
              <select class="form-select" name="FLOOR_ID" required>
                <option value="">-- Select Floor --</option>
                @if(!empty($floors))
                  @foreach ($floors as $floor)
                    <option value="{{ $floor->FLOOR_ID }}">{{ $floor->FLOOR_NAME }}</option>
                  @endforeach
                @endif
              </select>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Property</label>
              <select class="form-select" name="PROPERTY_ID" required>
                <option value="">-- Select Property --</option>
                 @foreach ($Properties as $Property)
                    <option value="{{ $Property->PROPERTY_ID }}">{{ $Property->PROPERTY_NAME }}</option>
                  @endforeach
              </select>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Rental Type</label>
              <select class="form-select" name="RENTAL_TYPE_ID" required>
                <option value="">-- Select Rental Type --</option>
                {{-- Load from common dropdown or controller --}}
              </select>
            </div>

            {{-- Amounts --}}
            <div class="col-md-4 mb-3">
              <label class="form-label">Currency</label>
              <select class="form-select" name="CURRENCY_ID" required>
                <option value="">-- Select Currency --</option>
                {{-- Load currency list dynamically --}}
              </select>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Rental Amount</label>
              <input type="number" name="RENTAL_AMOUNT" class="form-control" required>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Common Maintenance</label>
              <input type="number" name="COMMON_MAINTENANCE_AMOUNT" class="form-control" required>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Total Rent (No VAT)</label>
              <input type="number" name="TOTAL_RENT_AMOUNT_WITHOUT_VAT" class="form-control" required>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">VAT %</label>
              <input type="number" name="VAT_PERCENTAGE" class="form-control" required>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">VAT Amount</label>
              <input type="number" name="VAT_RENT_AMOUNT" class="form-control" required>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Final Rent With VAT</label>
              <input type="number" name="FINAL_RENT_AMOUNT_WITH_VAT" class="form-control" required>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Withholding %</label>
              <input type="number" name="WITH_HOLDING_PERCENTAGE" class="form-control" required>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Income After Withholding</label>
              <input type="number" name="TOTAL_INCOME_AFTER_WITH_HOLDING_TAX" class="form-control" required>
            </div>

            {{-- Deposits --}}
            <div class="col-md-4 mb-3">
              <label class="form-label">Deposit Amount</label>
              <input type="number" name="DEPOSIT_AMOUNT" class="form-control" required>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">VAT on Deposit</label>
              <input type="number" name="VAT_DESPOSIT_AMOUNT" class="form-control" required>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Final Deposit</label>
              <input type="number" name="FINAL_DEPOSIT_AMOUNT" class="form-control" required>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Status</label>
              <select class="form-select" name="STATUS_MASTER" required>
                <option value="ACTIVE">Active</option>
                <option value="INACTIVE">Inactive</option>
              </select>
            </div>

            <div class="col-md-8 mb-3">
              <label class="form-label">Remarks</label>
              <input type="text" name="REMARKS" class="form-control">
            </div>
          </div>

          {{-- Hidden values --}}

          <input type="hidden" name="PRICE_ID" value="0"> {{-- For creation, PRICE_ID is null or 0 --}}

          <div class="modal-footer">
            <button type="submit" class="btn btn-success">Save</button>
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          </div>

        </form>
      </div>
    </div>
  </div>
</div>


<!-- Add Price Setting Modal -->

<div class="modal fade" id="editPriceModal" tabindex="-1" aria-labelledby="editPriceLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editPriceLabel">Add New Price Setting</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body">
        <form method="POST" action="{{ route('pricesetting.save') }}">
          @csrf
          <div class="row">
            {{-- Dropdowns --}}
            <div class="col-md-4 mb-3">
              <label class="form-label">Company</label>
              <select class="form-select" name="COMPANY_ID" required>
                <option value="">-- Select Company --</option>
                @foreach ($companies as $company)
                  <option value="{{ $company->COMPANY_ID }}">{{ $company->COMPANY_NAME }}</option>
                @endforeach
              </select>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Branch</label>
              <select class="form-select" name="BRANCH_ID" required>
                <option value="">-- Select Branch --</option>
                @foreach ($branches as $branch)
                  <option value="{{ $branch->BRANCH_ID }}">{{ $branch->BRANCH_NAME }}</option>
                @endforeach
              </select>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Building</label>
              <select class="form-select" name="BUILDING_ID" required>
                <option value="">-- Select Building --</option>
                @foreach ($buildings as $building)
                  <option value="{{ $building->BUILDING_ID }}">{{ $building->BUILDING_NAME }}</option>
                @endforeach
              </select>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Floor</label>
              <select class="form-select" name="FLOOR_ID" required>
                <option value="">-- Select Floor --</option>
                @if(!empty($floors))
                  @foreach ($floors as $floor)
                    <option value="{{ $floor->FLOOR_ID }}">{{ $floor->FLOOR_NAME }}</option>
                  @endforeach
                @endif
              </select>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Property</label>
              <select class="form-select" name="PROPERTY_ID" required>
                <option value="">-- Select Property --</option>
                {{-- You should load properties via controller or JS --}}
              </select>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Rental Type</label>
              <select class="form-select" name="RENTAL_TYPE_ID" required>
                <option value="">-- Select Rental Type --</option>
                {{-- Load from common dropdown or controller --}}
              </select>
            </div>

            {{-- Amounts --}}
            <div class="col-md-4 mb-3">
              <label class="form-label">Currency</label>
              <select class="form-select" name="CURRENCY_ID" required>
                <option value="">-- Select Currency --</option>
                {{-- Load currency list dynamically --}}
              </select>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Rental Amount</label>
              <input type="number" name="RENTAL_AMOUNT" class="form-control" required>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Common Maintenance</label>
              <input type="number" name="COMMON_MAINTENANCE_AMOUNT" class="form-control" required>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Total Rent (No VAT)</label>
              <input type="number" name="TOTAL_RENT_AMOUNT_WITHOUT_VAT" class="form-control" required>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">VAT %</label>
              <input type="number" name="VAT_PERCENTAGE" class="form-control" required>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">VAT Amount</label>
              <input type="number" name="VAT_RENT_AMOUNT" class="form-control" required>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Final Rent With VAT</label>
              <input type="number" name="FINAL_RENT_AMOUNT_WITH_VAT" class="form-control" required>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Withholding %</label>
              <input type="number" name="WITH_HOLDING_PERCENTAGE" class="form-control" required>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Income After Withholding</label>
              <input type="number" name="TOTAL_INCOME_AFTER_WITH_HOLDING_TAX" class="form-control" required>
            </div>

            {{-- Deposits --}}
            <div class="col-md-4 mb-3">
              <label class="form-label">Deposit Amount</label>
              <input type="number" name="DEPOSIT_AMOUNT" class="form-control" required>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">VAT on Deposit</label>
              <input type="number" name="VAT_DESPOSIT_AMOUNT" class="form-control" required>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Final Deposit</label>
              <input type="number" name="FINAL_DEPOSIT_AMOUNT" class="form-control" required>
            </div>

            <div class="col-md-4 mb-3">
              <label class="form-label">Status</label>
              <select class="form-select" name="STATUS_MASTER" required>
                <option value="ACTIVE">Active</option>
                <option value="INACTIVE">Inactive</option>
              </select>
            </div>

            <div class="col-md-8 mb-3">
              <label class="form-label">Remarks</label>
              <input type="text" name="REMARKS" class="form-control">
            </div>
          </div>

          {{-- Hidden values --}}

          <input type="hidden" name="PRICE_ID" value="0"> {{-- For creation, PRICE_ID is null or 0 --}}

          <div class="modal-footer">
            <button type="submit" class="btn btn-success">Save</button>
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>




 <div class="modal fade" id="deletePriceModal" tabindex="-1" aria-labelledby="deletePriceModal" aria-hidden="true">
  <div class="modal-dialog">
    <form method="POST" action="{{ route('pricesetting.delete') }}">
      @csrf
      @method('DELETE')
      <input type="hidden" name="property_id" id="delete_property_id">

      <div class="modal-content">
        <div class="modal-header bg-danger text-white">
          <h5 class="modal-title" id="deletePropertyLabel">Confirm Property Deletion</h5>
          <button type="button" class="btn-close text-white" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body text-center">
          <p>Are you sure you want to delete <strong id="delete_property_name">Property XYZ</strong> from the system?</p>
          <p>This action cannot be undone.</p>
        </div>
        <div class="modal-footer justify-content-center">
          <button type="submit" class="btn btn-danger">Yes, Delete</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        </div>
      </div>
    </form>
  </div>
</div>

<script>

document.addEventListener('DOMContentLoaded', function () {
  const deleteButtons = document.querySelectorAll('.delete-price-btn');
  deleteButtons.forEach(button => {
    button.addEventListener('click', function () {
      const priceId = this.dataset.id || '';
      const priceName = this.dataset.name || '';
      document.getElementById('delete_property_id').value = priceId;
      document.getElementById('delete_property_name').textContent = priceName;
    });
  });
});

document.addEventListener('DOMContentLoaded', function () {
    const branchSelect   = document.getElementById('branch_id');
    const buildingSelect = document.getElementById('building_id');
    const floorSelect    = document.getElementById('floor_id');
    const propertySelect = document.getElementById('property_id');

    const selectedBuilding = buildingSelect?.dataset.selected;
    const selectedFloor    = floorSelect?.dataset.selected;
    const selectedProperty = propertySelect?.dataset.selected;

    function loadBuildings(branchId, selectedId = '') {
        fetch(`/load-buildings-by-branch?branch_id=${branchId}`)
            .then(res => res.json())
            .then(data => {
                buildingSelect.innerHTML = '<option value="">-- Select Building --</option>';
                (data.data || []).forEach(b => {
                    const opt = document.createElement('option');
                    opt.value = b.BUILDING_ID;
                    opt.textContent = b.BUILDING_NAME;
                    if (b.BUILDING_ID == selectedId) opt.selected = true;
                    buildingSelect.appendChild(opt);
                });

                // Auto-trigger next
                if (selectedId) loadFloors(branchId, selectedId, selectedFloor);
            });
    }

    function loadFloors(branchId, buildingId, selectedId = '') {
        fetch(`/load-floors?branch_id=${branchId}&building_id=${buildingId}`)
            .then(res => res.json())
            .then(data => {
                floorSelect.innerHTML = '<option value="">-- Select Floor --</option>';
                (data.data || []).forEach(f => {
                    const opt = document.createElement('option');
                    opt.value = f.FLOOR_ID;
                    opt.textContent = f.FLOOR_NAME;
                    if (f.FLOOR_ID == selectedId) opt.selected = true;
                    floorSelect.appendChild(opt);
                });

                // Auto-trigger next
                if (selectedId) loadProperties(branchId, buildingId, selectedId, selectedProperty);
            });
    }

    function loadProperties(branchId, buildingId, floorId, selectedId = '') {
        fetch(`/load-property?branch_id=${branchId}&building_id=${buildingId}&floor_id=${floorId}`)
            .then(res => res.json())
            .then(data => {
                propertySelect.innerHTML = '<option value="">-- Select Property --</option>';
                (data.data || []).forEach(p => {
                    const opt = document.createElement('option');
                    opt.value = p.PROPERTY_ID;
                    opt.textContent = p.PROPERTY_NAME;
                    if (p.PROPERTY_ID == selectedId) opt.selected = true;
                    propertySelect.appendChild(opt);
                });
            });
    }

    // Initial load if values exist (edit mode)
    const currentBranch = branchSelect?.value;
    if (currentBranch && selectedBuilding) {
        loadBuildings(currentBranch, selectedBuilding);
    }

    // Cascading triggers on change
    branchSelect?.addEventListener('change', function () {
        buildingSelect.innerHTML = floorSelect.innerHTML = propertySelect.innerHTML = '<option value="">-- Select --</option>';
        if (this.value) loadBuildings(this.value);
    });

    buildingSelect?.addEventListener('change', function () {
        floorSelect.innerHTML = propertySelect.innerHTML = '<option value="">-- Select --</option>';
        if (this.value) loadFloors(branchSelect.value, this.value);
    });

    floorSelect?.addEventListener('change', function () {
        propertySelect.innerHTML = '<option value="">-- Select --</option>';
        if (this.value) loadProperties(branchSelect.value, buildingSelect.value, this.value);
    });
});

</script>

@include ('layout.footer')
