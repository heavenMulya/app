<?php

namespace App\Http\Controllers\Bulding;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BuldingManagementController extends Controller
{
    /**
     * Display a listing of the buldinges.
     */
  public function index(Request $request)
{
    $branchId = $request->get('branch_id');

    $bulding = DB::select('EXEC [RMASTER].[SHOW_BUILDING_MASTER]');
    $companies = DB::select('SELECT COMPANY_ID, COMPANY_NAME FROM [RENTAL].[RMASTER].[COMPANY_MASTER]');
   // $branches = DB::select('SELECT BRANCH_ID, BRANCH_NAME, COMPANY_ID FROM [RENTAL].[RMASTER].[BRANCH_MASTER]');
   $branches = DB::select('SELECT BRANCH_ID, BRANCH_NAME, COMPANY_ID FROM [RENTAL].[RMASTER].[BRANCH_MASTER]');

    $companyId = null;

    if ($branchId) {
        $company = collect($branches)->firstWhere('BRANCH_ID', $branchId);
        $companyId = $company->COMPANY_ID ?? null;
    }

    return view('bulding.bulding', [
        'bulding'     => $bulding,
        'companies'   => $companies,
        'branches'    => $branches,
        'createdBy'   => auth()->user()->name ?? 'Admin',
        'macAddress'  => $request->ip(),
        'selectedBranchId' => $branchId,
        'selectedCompanyId' => $companyId,
        'message'     => session('message'),
        'status'      => session('status')
    ]);
}


    /**
     * Store a newly created bulding in the database.
     */
    public function create(Request $request)
    {
        $request->validate([
             'branch_id'      => 'required|integer',
            'company_id'      => 'required|integer',
            'bulding_name'     => 'required|string|max:255',
            'bulding_address'  => 'required|string|max:255',
            'remarks'         => 'nullable|string|max:255',
            'status_master'   => 'required|string|in:ACTIVE,INACTIVE',
        ]);

        $createdBy   = auth()->user()->name ?? 'admin';
        $macAddress  = $request->ip();

        $result = DB::select(
            'EXEC [RMASTER].[SAVE_BUILDING_MASTER] 
                @BUILDING_ID = ?, 
                @COMPANY_ID = ?, 
                @BRANCH_ID = ?, 
                @BUILDING_NAME = ?, 
                @BUILDING_ADDRESS=?,
                @REMARKS = ?, 
                @STATUS_MASTER = ?, 
                @CREATED_BY = ?, 
                @CREATED_MAC_ADDRESS = ?',
            [
                null,
                $request->company_id,
                $request->branch_id,
                $request->bulding_name,
                $request->bulding_address,
                $request->remarks,
                $request->status_master,
                $createdBy,
                $macAddress
            ]
        );

        $response    = $result[0] ?? null;
        $statusType  = $response->Column1 ?? '';
        $message     = $response->Column2 ?? '';

        return redirect()->route('bulding')->with([
            'message' => $message,
            'status'  => $statusType ?: 'Success'
        ]);
    }

    /**
     * Update the specified bulding.
     */
    public function update(Request $request)
    {
        $request->validate([
            'id'              => 'required|integer',
              'branch_id'      => 'required|integer',
            'company_id'      => 'required|integer',
            'bulding_name'     => 'required|string|max:255',
            'bulding_address'  => 'nullable|string|max:255',
            'remarks'         => 'nullable|string|max:255',
            'status_master'   => 'required|string|in:ACTIVE,INACTIVE',
        ]);

        try {
            $result = DB::select(
                'EXEC [RMASTER].[UPDATE_BUILDING_MASTER]
                @BUILDING_ID = ?, 
                @COMPANY_ID = ?, 
                @BRANCH_ID = ?, 
                @BUILDING_NAME = ?, 
                @BUILDING_ADDRESS=?,
                    @REMARKS = ?, 
                    @STATUS_MASTER = ?, 
                    @USER = ?, 
                    @UPDATED_MAC_ADDRESS = ?',
                [
                    $request->id,
                    $request->company_id,
                     $request->branch_id,
                    $request->bulding_name,
                    $request->bulding_address,
                    $request->remarks,
                    $request->status_master,
                    auth()->user()->name ?? 'admin',
                    $request->ip()
                ]
            );

            $response   = $result[0] ?? null;
            $statusType = $response->Column1 ?? '';
            $message    = $response->Column2 ?? '';

            return redirect()->route('bulding')->with([
                'message' => $message,
                'status'  => $statusType ?: 'Success'
            ]);

        } catch (\Exception $e) {
            return redirect()->route('bulding')->with([
                'message' => 'Update failed: ' . $e->getMessage(),
                'status'  => 'Error'
            ]);
        }
    }

    /**
     * Remove the specified bulding.
     */
    public function destroy(Request $request)
    {
        try {
            $result = DB::select(
                'EXEC [RMASTER].[DELETE_BUILDING_MASTER]
                    @BUILDING_ID = ?, 
                    @USER = ?, 
                    @MAC_ADDRESS = ?',
                [
                    $request->input('id'),
                    auth()->user()->name ?? 'admin',
                    $request->ip()
                ]
            );

            $response   = $result[0] ?? null;
            $statusType = $response->Column1 ?? '';
            $message    = $response->Column2 ?? '';

            return redirect()->route('bulding')->with([
                'message' => $message,
                'status'  => $statusType ?: 'Success'
            ]);

        } catch (\Exception $e) {
            return redirect()->route('bulding')->with([
                'message' => 'Error: ' . $e->getMessage(),
                'status'  => 'Error'
            ]);
        }
    }
}

