<?php

namespace App\Http\Controllers\Branch;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BranchManagementController extends Controller
{
    /**
     * Display a listing of the branches.
     */
    public function index()
    {
        $branch = DB::select('EXEC [RMASTER].[SHOW_BRANCH_MASTER]');
        $companies = DB::select('SELECT COMPANY_ID, COMPANY_NAME FROM [RENTAL].[RMASTER].[COMPANY_MASTER]');
        $createdBy = auth()->user()->name ?? 'Admin';
        $macAddress = request()->ip();

        return view('branch.branch', [
            'branch'     => $branch,
            'companies'  => $companies,
            'createdBy'  => $createdBy,
            'macAddress' => $macAddress,
            'message'    => session('message'),
            'status'     => session('status')
        ]);
    }

    /**
     * Store a newly created branch in the database.
     */
    public function create(Request $request)
    {
        $request->validate([
            'company_id'      => 'required|integer',
            'branch_name'     => 'required|string|max:255',
            'branch_address'  => 'required|string|max:255',
            'remarks'         => 'nullable|string|max:255',
            'status_master'   => 'required|string|in:ACTIVE,INACTIVE',
        ]);

        $createdBy   = auth()->user()->name ?? 'admin';
        $macAddress  = $request->ip();

        $result = DB::select(
            'EXEC [RMASTER].[SAVE_BRANCH_MASTER] 
                @BRANCH_ID = ?, 
                @COMPANY_ID = ?, 
                @BRANCH_NAME = ?, 
                @BRANCH_ADDRESS = ?, 
                @REMARKS = ?, 
                @STATUS_MASTER = ?, 
                @CREATED_BY = ?, 
                @CREATED_MAC_ADDRESS = ?',
            [
                null,
                $request->company_id,
                $request->branch_name,
                $request->branch_address,
                $request->remarks,
                $request->status_master,
                $createdBy,
                $macAddress
            ]
        );

        $response    = $result[0] ?? null;
        $statusType  = $response->Column1 ?? '';
        $message     = $response->Column2 ?? '';

        return redirect()->route('branch')->with([
            'message' => $message,
            'status'  => $statusType ?: 'Success'
        ]);
    }

    /**
     * Update the specified branch.
     */
    public function update(Request $request)
    {
        //   dd($request->all());
        $request->validate([
            'id'              => 'required|integer',
            'company_id'      => 'required|integer',
            'branch_name'     => 'required|string|max:255',
            'branch_address'  => 'nullable|string|max:255',
            'remarks'         => 'nullable|string|max:255',
            'status_master'   => 'required|string|in:ACTIVE,INACTIVE',
        ]);

        try {
            $result = DB::select(
                'EXEC [RMASTER].[UPDATE_BRANCH_MASTER] 
                    @BRANCH_ID = ?, 
                    @COMPANY_ID = ?, 
                    @BRANCH_NAME = ?, 
                    @BRANCH_ADDRESS = ?, 
                    @REMARKS = ?, 
                    @STATUS_MASTER = ?, 
                    @USER = ?, 
                    @UPDATED_MAC_ADDRESS = ?',
                [
                    $request->id,
                    $request->company_id,
                    $request->branch_name,
                    $request->branch_address,
                    $request->remarks,
                    $request->status_master,
                    auth()->user()->name ?? 'admin',
                    $request->ip()
                ]
            );

            $response   = $result[0] ?? null;
            $statusType = $response->Column1 ?? '';
            $message    = $response->Column2 ?? '';

            return redirect()->route('branch')->with([
                'message' => $message,
                'status'  => $statusType ?: 'Success'
            ]);

        } catch (\Exception $e) {
            return redirect()->route('branch')->with([
                'message' => 'Update failed: ' . $e->getMessage(),
                'status'  => 'Error'
            ]);
        }
    }

    /**
     * Remove the specified branch.
     */
    public function destroy(Request $request)
    {
        try {
            $result = DB::select(
                'EXEC [RMASTER].[DELETE_BRANCH_MASTER] 
                    @BRANCH_ID = ?, 
                    @USER = ?, 
                    @MAC_ADDRESS = ?',
                [
                    $request->input('id'),
                    auth()->user()->name ?? 'admin',
                    $request->ip()
                ]
            );

            $response   = $result[0] ?? null;
            $statusType = $response->Column1 ?? '';
            $message    = $response->Column2 ?? '';

            return redirect()->route('branch')->with([
                'message' => $message,
                'status'  => $statusType ?: 'Success'
            ]);

        } catch (\Exception $e) {
            return redirect()->route('branch')->with([
                'message' => 'Error: ' . $e->getMessage(),
                'status'  => 'Error'
            ]);
        }
    }
}
