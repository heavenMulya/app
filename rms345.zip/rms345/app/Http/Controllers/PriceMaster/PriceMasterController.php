<?php

namespace App\Http\Controllers\PriceMaster;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PriceMasterController extends Controller
{
     
 public function index(Request $request)
{
    $branchId  = $request->get('branch_id');
    $companyId = $request->get('company_id');
    $buildingId = $request->get('building_id');
    
    $FLOOR_ID = null;$CURRENCY_ID=null;$PROPERTY_ID=null;$RENTAL_TYPE_ID =null;$floors=null;$floor=null;

    $COMPANY_ID=NULL; $BRANCH_ID=NULL; $BUILDING_ID=NULL;

    $price  = DB::select('EXEC [RMASTER].[SHOW_PRICE_SETTINGS] @COMPANY_ID=?,@BRANCH_ID=?,@BUILDING_ID=?,@FLOOR_ID=?,@CURRENCY_ID=?,@PROPERTY_ID=?,@RENTAL_TYPE_ID=?', [$COMPANY_ID,$BRANCH_ID,$BUILDING_ID,$FLOOR_ID,$CURRENCY_ID,$PROPERTY_ID,$RENTAL_TYPE_ID]);
    $Properties = DB:: select ('select PROPERTY_ID,PROPERTY_NAME from RMASTER.PROPERTY_MASTER');
    $Rental_types = DB:: select ('EXEC [RMASTER].[LOAD_RENTAL_TYPE_NAME_RENTAL_TYPE]');
    $Currencies = DB:: select ('[RMASTER].[LOAD_CURRENCY_NAME_CURRENCY_MASTER]');
    $companies = DB::select('SELECT COMPANY_ID, COMPANY_NAME FROM [RENTAL].[RMASTER].[COMPANY_MASTER]');
    $floors = DB::select('select FLOOR_ID as id,FLOOR_NAME FROM RMASTER.FLOOR_MASTER');
    $createdBy = auth()->user()->name ?? 'Admin';
    $macAddress = $request->ip();

   // Load all branches, or filter by company ID if provided
    if ($companyId) {
        $branches = DB::select('EXEC [RMASTER].[LOAD_BRANCH_NAME_USING_MASTER] @COMPANY_ID = ?', [$companyId]);
    } else {
        $branches = DB::select('SELECT BRANCH_ID, BRANCH_NAME, COMPANY_ID 
                                FROM [RENTAL].[RMASTER].[BRANCH_MASTER] 
                                WHERE  STATUS_MASTER = ?', ['ACTIVE']);
      
    }

       // Load all buildings, or filter by branches ID if provided
    if ($buildingId) {
        $buildings = DB::select('SELECT BRANCH_ID,BUILDING_ID,BUILDING_NAME
                                  FROM [RENTAL].[RMASTER].[BUILDING_MASTER] 
                                WHERE BRANCH_ID = ?', [$buildingId]);
    } else {
           $buildings = DB::select('SELECT BRANCH_ID,BUILDING_ID,BUILDING_NAME
                                  FROM [RENTAL].[RMASTER].[BUILDING_MASTER]');
    }

    // Auto-detect company ID if only branch is passed
    if ($branchId && !$companyId) {
        $company = collect($branches)->firstWhere('BRANCH_ID', $branchId);
        $companyId = $company->COMPANY_ID ?? null;
    }

      // Auto-detect branches ID if only buildingId is passed
    if ($buildingId && !$branchId) {
        $branch = collect($buildings)->firstWhere('BUILDING_ID', $buildingId);
        $branchId = $buildings->BRANCH_ID ?? null;
    }

    return view('pricesetting.pricesetting', [
               'properties'=>$Properties,
              'buildings'=>$buildings,
             'price'             => $price,
           'companies'           => $companies,
           'currencies'           => $Currencies,
           'rental_types'           => $Rental_types,
           'branches'            => $branches,
           'floors'             => $floors,
            'createdBy'  => $createdBy,
            'macAddress' => $macAddress,
        // 'selectedBranchId'    => $branchId,
        // 'selectedCompanyId'   => $companyId,
        'message'             => session('message'),
        'status'              => session('status')
    ]);
}



    /**
     * Store a newly created bulding in the database.
     */
    public function create(Request $request)
    {
        // dd($request->all());
        $request->validate([
            'PRICE_ID'=> 'required|integer',
            'COMPANY_ID'=> 'required|integer',
            'BRANCH_ID'=> 'required|integer',
            'BUILDING_ID'=> 'required|integer',
            'FLOOR_ID'=> 'required|integer',
            'PROPERTY_ID'=> 'required|integer',
            'RENTAL_TYPE_ID'=> 'required|integer',
            'VAT_PERCENTAGE'=> 'required|integer',
            'CURRENCY_ID'=> 'required|integer',
            'RENTAL_AMOUNT'=> 'required|integer',
            'COMMON_MAINTENANCE_AMOUNT'=> 'required|integer',
            'TOTAL_RENT_AMOUNT_WITHOUT_VAT'=> 'required|integer',
            'VAT_RENT_AMOUNT'=> 'required|integer',
            'FINAL_RENT_AMOUNT_WITH_VAT'=> 'required|integer',
            'WITH_HOLDING_PERCENTAGE'=> 'required|integer',
            'TOTAL_INCOME_AFTER_WITH_HOLDING_TAX'=> 'required|integer',
            'DEPOSIT_AMOUNT'=> 'required|integer',
            'VAT_DEPOSIT_AMOUNT'=> 'required|integer',
            'FINAL_DEPOSIT_AMOUNT'=> 'required|integer',
            'REMARKS' => 'nullable|string|max:255',
            'STATUS_MASTER'=> 'required|string'
	
        ]);
        
        // $building_id=4;
        $createdBy   = auth()->user()->name ?? 'admin';
        $macAddress  = $request->ip();

        $result = DB::select(
            'EXEC [RMASTER].[SAVE_PRICE_SETTINGS] 
                @PRICE_ID= ?,
                @COMPANY_ID= ?,
                @BRANCH_ID= ?,
                @BUILDING_ID= ?,
                @FLOOR_ID= ?,
                @PROPERTY_ID= ?,
                @RENTAL_TYPE_ID= ?,
                @VAT_PERCENTAGE= ?,
                @CURRENCY_ID= ?,
                @RENTAL_AMOUNT= ?,
                @COMMON_MAINTENANCE_AMOUNT= ?,
                @TOTAL_RENT_AMOUNT_WITHOUT_VAT= ?,
                @VAT_RENT_AMOUNT= ?,
                @FINAL_RENT_AMOUNT_WITH_VAT= ?,
                @WITH_HOLDING_PERCENTAGE= ?,
                @TOTAL_INCOME_AFTER_WITH_HOLDING_TAX= ?,
                @DEPOSIT_AMOUNT= ?,
                @VAT_DESPOSIT_AMOUNT= ?,
                @FINAL_DEPOSIT_AMOUNT= ?,
                @REMARKS= ?,
                @STATUS_MASTER= ?,
                @CREATED_BY= ?,
                @CREATED_MAC_ADDRESS= ?',
             [
                null, 
                $request->COMPANY_ID,
                $request->BRANCH_ID,
                $request->BUILDING_ID,
                $request->FLOOR_ID,
                $request->PROPERTY_ID,
                $request->RENTAL_TYPE_ID,
                $request->VAT_PERCENTAGE,
                $request->CURRENCY_ID,
                $request->RENTAL_AMOUNT,
                $request->COMMON_MAINTENANCE_AMOUNT,
                $request->TOTAL_RENT_AMOUNT_WITHOUT_VAT,
                $request->VAT_RENT_AMOUNT,
                $request->FINAL_RENT_AMOUNT_WITH_VAT,
                $request->WITH_HOLDING_PERCENTAGE,
                $request->TOTAL_INCOME_AFTER_WITH_HOLDING_TAX,
                $request->DEPOSIT_AMOUNT,
                $request->VAT_DESPOSIT_AMOUNT,
                $request->FINAL_DEPOSIT_AMOUNT,
                $request->REMARKS,
                $request->STATUS_MASTER,
                $createdBy,
                $macAddress
            ]
        );
        // dd($result);
        $response    = $result[0] ?? null;
        $statusType  = $response->Column1 ?? '';
        $message     = $response->Column2 ?? '';

        return redirect()->route('pricesetting')->with([
            'message' => $message,
            'status'  => $statusType ?: 'Success'
        ]);
    }

    /**
     * Update the specified bulding.
     */

    public function update(Request $request)
    {
        // dd($request->all());
        $request->validate([
            'PRICE_ID'=> 'required|integer',
            'COMPANY_ID'=> 'required|integer',
            'BRANCH_ID'=> 'required|integer',
            'BUILDING_ID'=> 'required|integer',
            'FLOOR_ID'=> 'required|integer',
            'PROPERTY_ID'=> 'required|integer',
            'RENTAL_TYPE_ID'=> 'required|integer',
            'VAT_PERCENTAGE'=> 'required|numeric',
            'CURRENCY_ID'=> 'required|integer',
            'RENTAL_AMOUNT'=> 'required|numeric',
            'COMMON_MAINTENANCE_AMOUNT'=> 'required|numeric',
            'TOTAL_RENT_AMOUNT_WITHOUT_VAT'=> 'required|numeric',
            'VAT_RENT_AMOUNT'=> 'required|numeric',
            'FINAL_RENT_AMOUNT_WITH_VAT'=> 'required|numeric',
            'WITH_HOLDING_PERCENTAGE'=> 'required|numeric',
            'TOTAL_INCOME_AFTER_WITH_HOLDING_TAX'=> 'required|numeric',
            'DEPOSIT_AMOUNT'=> 'required|numeric',
            'VAT_DEPOSIT_AMOUNT'=> 'required|numeric',
            'FINAL_DEPOSIT_AMOUNT'=> 'required|numeric',
            'REMARKS' => 'nullable|string|max:255',
            'STATUS_MASTER'=> 'required|string'
           
        ]);

        try {
            $result = DB::select(
                'EXEC [RMASTER].[UPDATE_PRICE_SETTINGS]
                @PRICE_ID= ?,
                @COMPANY_ID= ?,
                @BRANCH_ID= ?,
                @BUILDING_ID= ?,
                @FLOOR_ID= ?,
                @PROPERTY_ID= ?,
                @RENTAL_TYPE_ID= ?,
                @VAT_PERCENTAGE= ?,
                @CURRENCY_ID= ?,
                @RENTAL_AMOUNT= ?,
                @COMMON_MAINTENANCE_AMOUNT= ?,
                @TOTAL_RENT_AMOUNT_WITHOUT_VAT= ?,
                @VAT_RENT_AMOUNT= ?,
                @FINAL_RENT_AMOUNT_WITH_VAT= ?,
                @WITH_HOLDING_PERCENTAGE= ?,
                @TOTAL_INCOME_AFTER_WITH_HOLDING_TAX= ?,
                @DEPOSIT_AMOUNT= ?,
                @VAT_DEPOSIT_AMOUNT= ?,
                @FINAL_DEPOSIT_AMOUNT= ?,
                @REMARKS= ?,
                @STATUS_MASTER= ?,
                @MODIFIED_BY= ?,
                @UPDATED_MAC_ADDRESS= ?',
                [
                $request->PRICE_ID,
                $request->COMPANY_ID,
                $request->BRANCH_ID,
                $request->BUILDING_ID,
                $request->FLOOR_ID,
                $request->PROPERTY_ID,
                $request->RENTAL_TYPE_ID,
                $request->VAT_PERCENTAGE,
                $request->CURRENCY_ID,
                $request->RENTAL_AMOUNT,
                $request->COMMON_MAINTENANCE_AMOUNT,
                $request->TOTAL_RENT_AMOUNT_WITHOUT_VAT,
                $request->VAT_RENT_AMOUNT,
                $request->FINAL_RENT_AMOUNT_WITH_VAT,
                $request->WITH_HOLDING_PERCENTAGE,
                $request->TOTAL_INCOME_AFTER_WITH_HOLDING_TAX,
                $request->DEPOSIT_AMOUNT,
                $request->VAT_DEPOSIT_AMOUNT,
                $request->FINAL_DEPOSIT_AMOUNT,
                $request->REMARKS,
                $request->STATUS_MASTER,
                auth()->user()->name ?? 'admin',
                $request->ip()
                ]
            );

            $response   = $result[0] ?? null;
            $statusType = $response->Column1 ?? '';
            $message    = $response->Column2 ?? '';

            return redirect()->route('pricesetting')->with([
                'message' => $message,
                'status'  => $statusType ?: 'Success'
            ]);

        } catch (\Exception $e) {
            return redirect()->route('pricesetting')->with([
                'message' => 'Update failed: ' . $e->getMessage(),
                'status'  => 'Error'
            ]);
        }
    }

    /**
     * Remove the specified bulding.
     */
    public function destroy(Request $request)

    { 
        // dd($request->all());

        $request->PRICE_ID;
       
        try {
            $result = DB::select(
                '[RMASTER].[DELETE_PRICE_SETTINGS]
                    @PRICE_ID = ?, 
                    @MODIFIED_BY = ?, 
                    @UPDATED_MAC_ADDRESS = ?',
                [
                    $request->input('PRICE_ID'),
                    auth()->user()->name ?? 'admin',
                    $request->ip()
                ]
            );
            // dd($result);

            $response   = $result[0] ?? null;
            $statusType = $response->Column1 ?? '';
            $message    = $response->Column2 ?? '';

            return redirect()->route('pricesetting')->with([
                'message' => $message,
                'status'  => $statusType ?: 'Success'
            ]);

        } catch (\Exception $e) {
            return redirect()->route('pricesetting')->with([
                'message' => 'Error: ' . $e->getMessage(),
                'status'  => 'Error'
            ]);
        }
    }

    public function loadBuildingsByBranch(Request $request)
    {
        $branchId = $request->input('branch_id');

        try {
            $buildings = DB::select(
                'EXEC [RMASTER].[LOAD_BUILDING_NAME_USING_BRANCH_ID] @BRANCH_ID = ?',
                [$branchId]
            );

            return response()->json([
                'success' => true,
                'data' => $buildings
            ]);
        } catch (\Exception $e) {
            Log::error('Error executing LOAD_BUILDING_NAME_USING_BRANCH_ID: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'error' => 'Unable to load buildings',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function loadBranchByCompany(Request $request)
    {
        $COMPANY_ID = $request->input('company_id');

        try {
            $branches = DB::select(
                'EXEC [RMASTER].[LOAD_BRANCH_NAME_USING_MASTER] @COMPANY_ID = ?',
                [$COMPANY_ID]
            );

            return response()->json([
                'success' => true,
                'data' => $branches
            ]);
        } catch (\Exception $e) {
            Log::error('Error executing LOAD_BULOAD_BRANCH_NAME_USING_MASTER: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'error' => 'Unable to load branches',
                'message' => $e->getMessage()
            ], 500);
        }
    }

public function loadFloorByBranch(Request $request)
    {
        $COMPANY_ID = $request->input('company_id');
        $BRANCH_ID = $request->input('branch_id');
        $BUILDING_ID = $request->input('building_id');
        try {
            $branches = DB::select(
                'EXEC [RMASTER].[LOAD_FLOOR_NAME_USING_BRANCH_ID_AND_BUILDING_ID_company] @COMPANY_ID = ?, @BRANCH_ID = ?, @BUILDING_ID = ?',
                [$COMPANY_ID],$BRANCH_ID,$BUILDING_ID
            );

            return response()->json([
                'success' => true,
                'data' => $branches
            ]);
        } catch (\Exception $e) {
            Log::error('Error executing LOAD_floor_NAME_USING_MASTER: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'error' => 'Unable to load FLOORS',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function getCommonDropdownDetails($id)
{
    try {
        // Call the stored procedure with the provided COMMON_ID
        $result = DB::select('EXEC [RMASTER].[LOAD_COMMON_DROPDOWN_DTL] @cOMMON_ID = ?', [$id]);

        // Return success response
        return response()->json($result);
    } catch (\Exception $e) {
        // Log the error for backend tracing
        Log::error('Error loading common dropdown details: ' . $e->getMessage());

        // Return error to frontend
        return response()->json([
            'error' => 'Failed to load dropdown details',
            'message' => $e->getMessage()
        ], 500);
    }
}
// Load branches for selected company
public function loadBranches($companyId)
{
    $branches = DB::select('EXEC [RMASTER].[LOAD_BRANCH_NAME_USING_MASTER] @COMPANY_ID = ?', [$companyId]);
    return response()->json($branches);
}

// Load buildings for selected company and branch
public function loadBuildings(Request $request)
{
    $companyId = $request->get('company_id');
    $branchId = $request->get('branch_id');

    $buildings = DB::select('EXEC [RMASTER].[LOAD_BUILDING_NAME_BUILDING_MASTER_USING_COMPANY_BRANCH] @COMPANY_ID = ?, @BRANCH_ID = ?', [$companyId, $branchId]);
    return response()->json($buildings);
}

// Load floors for selected building, branch, and company
public function loadFloors(Request $request)
{
    $companyId = $request->get('company_id');
    $branchId = $request->get('branch_id');
    $buildingId = $request->get('building_id');


    $floors = DB::select('EXEC [RMASTER].[SHOW_FLOOR_MASTER] @COMPANY_ID = ?, @BRANCH_ID = ?, @BUILDING_ID = ?', [$companyId, $branchId, $buildingId]);
    // dd($floors);
    return response()->json($floors);
}

// Load properties for selected floor, building, branch, and company
public function loadProperties(Request $request)
{
    $companyId = $request->get('company_id');
    $branchId = $request->get('branch_id');
    $buildingId = $request->get('building_id');
    $floorId = $request->get('floor_id');

    $properties = DB::select('EXEC [RMASTER].[SHOW_PROPERTY_MASTER] @COMPANY_ID = ?, @BRANCH_ID = ?, @BUILDING_ID = ?, @FLOOR_ID = ?, @PROPERTY_TYPE_IDD = ?', [$companyId, $branchId, $buildingId, $floorId, $PropertId='']);
    return response()->json($properties);
}

}


