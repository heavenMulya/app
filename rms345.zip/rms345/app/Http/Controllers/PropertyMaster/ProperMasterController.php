<?php

namespace App\Http\Controllers\PropertyMaster;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class ProperMasterController extends Controller
{

    public function showpropertyForm(Request $request)
    {  
    $branchId  = $request->get('branch_id');
    $companyId = $request->get('company_id');
    $buildingId = $request->get('building_id');     

    $propertyTypes = DB::select('select PROPERTY_TYPE_ID,PROPERTY_TYPE_NAME from RMASTER.PROPERTY_TYPE_MASTER');
    $properties = DB::select('EXEC [RMASTER].[SHOW_PROPERTY_MASTER]');
    $companies = DB::select('SELECT COMPANY_ID, COMPANY_NAME FROM [RENTAL].[RMASTER].[COMPANY_MASTER]');
    $countries = DB::select('SELECT COUNTRY_ID, COUNTRY_NAME FROM RMASTER.COUNTRY_MASTER');
    $branches = DB::select('SELECT BRANCH_ID, BRANCH_NAME, COMPANY_ID FROM [RENTAL].[RMASTER].[BRANCH_MASTER]');
    $buildings = DB::select(' select BUILDING_ID,BUILDING_NAME from RMASTER.BUILDING_MASTER');
     $floors = DB::select ('select FLOOR_ID,FLOOR_NAME from RMASTER.FLOOR_MASTER');
        $createdBy = auth()->user()->name ?? 'Admin';
        $macAddress = request()->ip();
        

    
    $FLOOR_ID = null;$CURRENCY_ID=null;$PROPERTY_ID=null;$RENTAL_TYPE_ID =null;$floor=null;

    $COMPANY_ID=NULL; $BRANCH_ID=NULL; $BUILDING_ID=NULL;


   // Load all branches, or filter by company ID if provided
    if ($companyId) {
        $branches = DB::select('EXEC [RMASTER].[LOAD_BRANCH_NAME_USING_MASTER] @COMPANY_ID = ?', [$companyId]);
    } else {
        $branches = DB::select('SELECT BRANCH_ID, BRANCH_NAME, COMPANY_ID 
                                FROM [RENTAL].[RMASTER].[BRANCH_MASTER] 
                                WHERE  STATUS_MASTER = ?', ['ACTIVE']);
      
    }

       // Load all buildings, or filter by branches ID if provided
    if ($buildingId) {
        $buildings = DB::select('SELECT BRANCH_ID,BUILDING_ID,BUILDING_NAME
                                  FROM [RENTAL].[RMASTER].[BUILDING_MASTER] 
                                WHERE BRANCH_ID = ?', [$buildingId]);
    } else {
           $buildings = DB::select('SELECT BRANCH_ID,BUILDING_ID,BUILDING_NAME
                                  FROM [RENTAL].[RMASTER].[BUILDING_MASTER]');
    }

    // Auto-detect company ID if only branch is passed
    if ($branchId && !$companyId) {
        $company = collect($branches)->firstWhere('BRANCH_ID', $branchId);
        $companyId = $company->COMPANY_ID ?? null;
    }

      // Auto-detect branches ID if only buildingId is passed
    if ($buildingId && !$branchId) {
        $branch = collect($buildings)->firstWhere('BUILDING_ID', $buildingId);
        $branchId = $buildings->BRANCH_ID ?? null;
    }
    // dd($floors);

        return view('property.property', [
            'propertyTypes'=>$propertyTypes,
             'floors'=> $floors ?? [],
            'buildings'=>$buildings,
            'countries'=>$countries,
            'properties'=>$properties,
            'branches'   => $branches,
            'companies'  => $companies,
            'createdBy'  => $createdBy,
            'macAddress' => $macAddress,
            'message'    => session('message'),
            'status'     => session('status')
        ]);
    }




public function getBranchesByCompany(Request $request)
{
    $companyId = $request->company_id;
    // dd($companyId);

    $branches = DB::select("EXEC RMASTER.LOAD_BRANCH_NAME_USING_MASTER ?", [$companyId]);
    // dd($branches);

    return response()->json($branches);
}



public function saveProperty(Request $request)
{
try{
    // Validate input
    $request->validate([
        'property_type_id'=>'required|integer|not_in:0',
        'company_id'       => 'required|integer|not_in:0',
        'branch_id'        => 'required|integer|not_in:0',
        'building_id'      => 'required|integer|not_in:0',
        'floor_id'         => 'required|integer|not_in:0',
        'property_name'    => 'required|string|max:100',
        'property_size'    => 'nullable|string|max:100',
        'remarks'          => 'nullable|string|max:256',
        'status_master'    => 'required|string|in:ACTIVE,INACTIVE',
    ]);

    $user = auth()->user()->name ?? 'admin';
    $macAddress = $request->ip(); // This could be changed to get real MAC in desktop environments

    // Call stored procedure
    $result = DB::select('EXEC RMASTER.SAVE_PROPERTY_MASTER 
        @PROPERTY_TYPE_ID = ?, 
        @COMPANY_ID = ?, 
        @BRANCH_ID = ?, 
        @BUILDING_ID = ?, 
        @FLOOR_ID = ?, 
        @PROPERTY_NAME = ?, 
        @PROPERTY_SIZE = ?, 
        @REMARKS = ?, 
        @STATUS_MASTER = ?, 
        @USER = ?, 
        @CREATED_MAC_ADDRESS = ?',
        [
            $request->property_type_id,
            $request->company_id,
            $request->branch_id,
            $request->building_id,
            $request->floor_id,
            $request->property_name,
            $request->property_size,
            $request->remarks,
            $request->status_master,
            $user,
            $macAddress
        ]
    );

    // Parse the response
    $response = $result[0] ?? null;
    $statusType = $response->Column1 ?? '';
    $message    = $response->Column2 ?? '';
    $recordId   = $response->Column3 ?? null;

    // Redirect with message
    return redirect()->route('property')->with([
        'status'  => $statusType,
        'message' => $message,
    ]);

    } catch (\Exception $e) {
        return redirect()->route('property')->with([
            'message' => 'Error: ' . $e->getMessage(),
            'status'  => 'Error'
        ]);
    }
}



public function updateProperty(Request $request)
{
   try{
    // Validate the incoming request
    $request->validate([
        'property_id'       => 'required|integer',
        'company_id'        => 'required|integer|not_in:0',
        'branch_id'         => 'required|integer|not_in:0',
        'building_id'       => 'required|integer|not_in:0',
        'floor_id'          => 'required|integer|not_in:0',
        'property_type_id'  => 'required|integer',
        'property_name'     => 'required|string|max:100',
        'property_size'     => 'nullable|string|max:100',
        'remarks'           => 'nullable|string|max:256',
        'status_master'     => 'required|string|in:ACTIVE,INACTIVE',
    ]);

    $user       = auth()->user()->name ?? 'admin';
    $macAddress = $request->ip(); // This is a placeholder for MAC

    // Execute the stored procedure
    $result = DB::select('EXEC RMASTER.UPDATE_PROPERTY_MASTER 
        @PROPERTY_ID = ?, 
        @COMPANY_ID = ?, 
        @BRANCH_ID = ?, 
        @BUILDING_ID = ?, 
        @FLOOR_ID = ?, 
        @PROPERTY_TYPE_ID = ?, 
        @PROPERTY_NAME = ?, 
        @PROPERTY_SIZE = ?, 
        @REMARKS = ?, 
        @STATUS_MASTER = ?, 
        @USER = ?, 
        @UPDATED_MAC_ADDRESS = ?', [
            $request->property_id,
            $request->company_id,
            $request->branch_id,
            $request->building_id,
            $request->floor_id,
            $request->property_type_id,
            $request->property_name,
            $request->property_size,
            $request->remarks,
            $request->status_master,
            $user,
            $macAddress
        ]
    );
    // Parse result
        $response   = $result[0] ?? null;
        $statusType = $response->Column1 ?? 'Success';
        $message    = $response->Column2 ?? 'Tenant deleted successfully.';
    //$response   = $result[0] ?? null;
    //$status     = $response->Column1 ?? '';
   // $message    = $response->Column2 ?? '';
   // $recordId   = $response->Column3 ?? null;

    return redirect()->route('property')->with([
        'status'     => $statusType,
        'message'    => $message,
    ]);

     } catch (\Exception $e) {
        return redirect()->route('property')->with([
            'message' => 'Error: ' . $e->getMessage(),
            'status'  => 'Error'
        ]);
    }
}


public function deleteProperty(Request $request)
{
    try {
        $request->validate([
            'property_id' => 'required|integer',
        ]);

        $user       = auth()->user()->name ?? 'admin';
        $macAddress = $request->ip();

        $result = DB::select('EXEC [RMASTER].[DELETE_PROPERTY_MASTER] 
            @PROPERTY_ID = ?, 
            @USER = ?, 
            @MAC_ADDRESS = ?', [
                $request->property_id,
                $user,
                $macAddress
        ]);

        $response   = $result[0] ?? null;
        $status     = $response->Column1 ?? 'Error';
        $message    = $response->Column2 ?? 'Unknown response from DB.';

        return redirect()->route('property')->with([
            'status'  => $status,
            'message' => $message,
        ]);

    } catch (\Exception $e) {
        return redirect()->route('property')->with([
            'status'  => 'Error',
            'message' => 'Exception: ' . $e->getMessage(),
        ]);
    }
}


///loading data


    public function loadBuildingsByBranch(Request $request)
    {
        $branchId = $request->input('branch_id');

        try {
            $buildings = DB::select(
                'EXEC [RMASTER].[LOAD_BUILDING_NAME_USING_BRANCH_ID] @BRANCH_ID = ?',
                [$branchId]
            );

            return response()->json([
                'success' => true,
                'data' => $buildings
            ]);
        } catch (\Exception $e) {
            Log::error('Error executing LOAD_BUILDING_NAME_USING_BRANCH_ID: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'error' => 'Unable to load buildings',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function loadBranchByCompany(Request $request)
    {
        $COMPANY_ID = $request->input('company_id');

        try {
            $branches = DB::select(
                'EXEC [RMASTER].[LOAD_BRANCH_NAME_USING_MASTER] @COMPANY_ID = ?',
                [$COMPANY_ID]
            );

            return response()->json([
                'success' => true,
                'data' => $branches
            ]);
        } catch (\Exception $e) {
            Log::error('Error executing LOAD_BULOAD_BRANCH_NAME_USING_MASTER: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'error' => 'Unable to load branches',
                'message' => $e->getMessage()
            ], 500);
        }
    }

public function loadFloorByBranch(Request $request)
    {
        $COMPANY_ID = $request->input('company_id');
        $BRANCH_ID = $request->input('branch_id');
        $BUILDING_ID = $request->input('building_id');
        try {
            $branches = DB::select(
                'EXEC [RMASTER].[LOAD_FLOOR_NAME_USING_BRANCH_ID_AND_BUILDING_ID_company] @COMPANY_ID = ?, @BRANCH_ID = ?, @BUILDING_ID = ?',
                [$COMPANY_ID],$BRANCH_ID,$BUILDING_ID
            );

            return response()->json([
                'success' => true,
                'data' => $branches
            ]);
        } catch (\Exception $e) {
            Log::error('Error executing LOAD_floor_NAME_USING_MASTER: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'error' => 'Unable to load FLOORS',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function getCommonDropdownDetails($id)
{
    try {
        // Call the stored procedure with the provided COMMON_ID
        $result = DB::select('EXEC [RMASTER].[LOAD_COMMON_DROPDOWN_DTL] @cOMMON_ID = ?', [$id]);

        // Return success response
        return response()->json($result);
    } catch (\Exception $e) {
        // Log the error for backend tracing
        Log::error('Error loading common dropdown details: ' . $e->getMessage());

        // Return error to frontend
        return response()->json([
            'error' => 'Failed to load dropdown details',
            'message' => $e->getMessage()
        ], 500);
    }
}
// Load branches for selected company
public function loadBranches($companyId)
{
    // dd($companyId);
    $branches = DB::select('EXEC [RMASTER].[LOAD_BRANCH_NAME_USING_MASTER] @COMPANY_ID = ?', [$companyId]);
    return response()->json($branches);
}

// Load buildings for selected company and branch
public function loadBuildings(Request $request)
{
    $companyId = $request->get('company_id');
    $branchId = $request->get('branch_id');

    $buildings = DB::select('EXEC [RMASTER].[LOAD_BUILDING_NAME_BUILDING_MASTER_USING_COMPANY_BRANCH] @COMPANY_ID = ?, @BRANCH_ID = ?', [$companyId, $branchId]);
    return response()->json($buildings);
}

// Load floors for selected building, branch, and company
public function loadFloors(Request $request)
{
    $companyId = $request->get('company_id');
    $branchId = $request->get('branch_id');
    $buildingId = $request->get('building_id');


    $floors = DB::select('EXEC [RMASTER].[SHOW_FLOOR_MASTER] @COMPANY_ID = ?, @BRANCH_ID = ?, @BUILDING_ID = ?', [$companyId, $branchId, $buildingId]);
    // dd($floors);
    return response()->json($floors);
}

// Load properties for selected floor, building, branch, and company
public function loadProperties(Request $request)
{
    $companyId = $request->get('company_id');
    $branchId = $request->get('branch_id');
    $buildingId = $request->get('building_id');
    $floorId = $request->get('floor_id');

    $properties = DB::select('EXEC [RMASTER].[SHOW_PROPERTY_MASTER] @COMPANY_ID = ?, @BRANCH_ID = ?, @BUILDING_ID = ?, @FLOOR_ID = ?, @PROPERTY_TYPE_ID = ?', [
        $companyId, $branchId, $buildingId, $floorId, ''
    ]);

    return response()->json($properties);
}




























/*
public function getBranches(Request $req)
{
    $companyId = $req->company_id;
    $rows = DB::select('EXEC [RMASTER].[LOAD_BRANCH_NAME_USING_MASTER] ?', [$companyId]);
    return response()->json($rows);
}

public function getBuildings(Request $req)
{
    $branchId = $req->branch_id;
    $rows = DB::select('EXEC [RMASTER].LOAD_BUILDINGS_BY_BRANCH ?', [$branchId]);
    return response()->json($rows);
}

public function getFloors(Request $req)
{
    $buildingId = $req->building_id;
    $rows = DB::select('EXEC [RMASTER].LOAD_FLOORS_BY_BUILDING ?', [$buildingId]);
    return response()->json($rows);
}

public function getProperties(Request $req)
{
    $floorId = $req->floor_id;
    $rows = DB::select('EXEC [RMASTER].SHOW_PROPERTY_MASTER ?,?,?,?,?', [
        '', '', '', $floorId, ''
    ]);
    return response()->json($rows);
}



    public function loadBuildingsByBranch(Request $request)
    {
        $branchId = $request->input('branch_id');

        try {
            $buildings = DB::select(
                'EXEC [RMASTER].[LOAD_BUILDING_NAME_USING_BRANCH_ID] @BRANCH_ID = ?',
                [$branchId]
            );

            return response()->json([
                'success' => true,
                'data' => $buildings
            ]);
        } catch (\Exception $e) {
            Log::error('Error executing LOAD_BUILDING_NAME_USING_BRANCH_ID: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'error' => 'Unable to load buildings',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function loadBranchByCompany(Request $request)
    {
        $COMPANY_ID = $request->input('company_id');

        try {
            $branches = DB::select(
                'EXEC [RMASTER].[LOAD_BRANCH_NAME_USING_MASTER] @COMPANY_ID = ?',
                [$COMPANY_ID]
            );

            return response()->json([
                'success' => true,
                'data' => $branches
            ]);
        } catch (\Exception $e) {
            Log::error('Error executing LOAD_BULOAD_BRANCH_NAME_USING_MASTER: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'error' => 'Unable to load branches',
                'message' => $e->getMessage()
            ], 500);
        }
    }

public function loadFloorByBranch(Request $request)
    {
        $COMPANY_ID = $request->input('company_id');
        $BRANCH_ID = $request->input('branch_id');
        $BUILDING_ID = $request->input('building_id');
        try {
            $branches = DB::select(
                'EXEC [RMASTER].[LOAD_FLOOR_NAME_USING_BRANCH_ID_AND_BUILDING_ID_company] @COMPANY_ID = ?, @BRANCH_ID = ?, @BUILDING_ID = ?',
                [$COMPANY_ID],$BRANCH_ID,$BUILDING_ID
            );

            return response()->json([
                'success' => true,
                'data' => $branches
            ]);
        } catch (\Exception $e) {
            Log::error('Error executing LOAD_floor_NAME_USING_MASTER: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'error' => 'Unable to load FLOORS',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    public function getCommonDropdownDetails($id)
{
    try {
        // Call the stored procedure with the provided COMMON_ID
        $result = DB::select('EXEC [RMASTER].[LOAD_COMMON_DROPDOWN_DTL] @cOMMON_ID = ?', [$id]);

        // Return success response
        return response()->json($result);
    } catch (\Exception $e) {
        // Log the error for backend tracing
        Log::error('Error loading common dropdown details: ' . $e->getMessage());

        // Return error to frontend
        return response()->json([
            'error' => 'Failed to load dropdown details',
            'message' => $e->getMessage()
        ], 500);
    }
}*/











}
