<?php


namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\DynamicStoredProcedureService;

class DynamicStoredProcedureController extends Controller
{
    protected $spService;

    public function __construct(DynamicStoredProcedureService $spService)
    {
        $this->spService = $spService;
    }

    public function handle(Request $request)
    {
        // Validate incoming request
        $validated = $request->validate([
            'sp_name' => 'required|string',
            'input_fields' => 'required|array'  // e.g., ["BRANCH_ID", "BUILDING_ID"]
        ]);

        $spName = $validated['sp_name'];
        $inputFields = $validated['input_fields'];

        // Dynamically map input fields to actual data values
        $parameters = [];
        foreach ($inputFields as $field) {
            $value = $request->input(strtolower($field)); // assuming lowercase keys in request
            $parameters[$field] = $value;
        }

        try {
            $results = $this->spService->execute($spName, $parameters);

            return response()->json([
                'success' => true,
                'data' => $results
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => 'Execution failed',
                'message' => $e->getMessage()
            ], 500);
        }
    }
}
