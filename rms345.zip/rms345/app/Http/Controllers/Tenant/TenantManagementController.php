<?php

namespace App\Http\Controllers\Tenant;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TenantManagementController extends Controller
{
    /**
     * Display a listing of the buldinges.
     */
  public function index(Request $request)
{


    $tenants = DB::select('EXEC [RMASTER].[SHOW_TENANT]');
    $status = DB::select('EXEC [RMASTER].[LOAD_COMMON_DROPDOWN_DTL] ?', [9]);
    $companies = DB::select('SELECT COMPANY_ID, COMPANY_NAME FROM [RENTAL].[RMASTER].[COMPANY_MASTER]');
    $countries = DB::select('SELECT COUNTRY_ID, COUNTRY_NAME FROM RMASTER.COUNTRY_MASTER');
    $branches = DB::select('SELECT BRANCH_ID, BRANCH_NAME, COMPANY_ID FROM [RENTAL].[RMASTER].[BRANCH_MASTER]');


    return view('Tenants.tenant', [
        'status'        =>$status,
        'tenants'     => $tenants,
        'companies'   => $companies,
        'countries'   => $countries,
        'branches'    => $branches,
        'createdBy'   => auth()->user()->name ?? 'Admin',
        'macAddress'  => $request->ip(),
        'message'     => session('message'),
        'status'      => session('status')
    ]);
}



public function createDocumentsTenant(Request $request)
{
    $request->validate([
        'tenant_id'        => 'required|integer',
        'document_name'    => 'required|string',
        'FILE'             => 'required|file',
        'remarks'          => 'nullable|string|max:256',
        'status_master'    => 'required|string',
    ]);

    $file = $request->file('FILE');
    $fileName = time() . '_' . preg_replace('/\s+/', '_', strtolower($request->input('document_name'))) . '.' . $file->getClientOriginalExtension();
    $filePath = $file->storeAs('documents', $fileName, 'public');

    $createdBy  = auth()->user()->username ?? 'admin';
    $createdMac = $request->ip();

    $DOC_ID = null;

    $result = DB::select(
        'EXEC [RENTRIES].[SAVE_TENANT_DOCUMENTS]
            @DOC_ID = ?, 
            @TENANT_ID = ?, 
            @DOCUMENT_NAME = ?, 
            @FILE_PATH = ?,  
            @REMARKS = ?, 
            @CREATED_BY = ?, 
            @CREATED_MAC_ADDRESS = ?, 
            @STATUS_MASTER = ?',
        [
            $DOC_ID,
            $request->tenant_id,
            $request->document_name,
            '/storage/' . $filePath,
            $request->remarks,
            $createdBy,
            $createdMac,
            $request->status_master
        ]
    );

    $response   = $result[0] ?? null;
    $status     = $response->Column1 ?? '';
    $message    = $response->Column2 ?? '';
    $savedId    = $response->Column3 ?? null;

    return redirect()->route('tenant')->with([
        'message'  => $message,
        'status'   => $status,
        'saved_id' => $savedId
    ]);
}


public function LoadDocumentPath($id)
{
    try {
        // Execute stored procedure with the provided PRICE_ID
        $details = DB::select('EXEC [RENTRIES].[GET_DOCUMENTS_USING_TENANT_ID]  @TENANT_ID = ?', [$id]);

        return response()->json($details);
    } catch (\Exception $e) {
        \Log::error('Error fetching price details: ' . $e->getMessage());

        return response()->json([
            'error' => 'Server error',
            'message' => $e->getMessage()
        ], 500);
    }
}

    /**
     * Store a newly created bulding in the database.
     */
    public function create(Request $request)
{
    //dd($request->all());
    $request->validate([
        'tenant_name'         => 'required|string|max:100',
        'login_name'          => 'required|string|max:50',
        'password'            => 'required|string|max:50',
        'email'               => 'nullable|email|max:255',
        'mobile_no'           => 'nullable|string|max:15',
        'tin_no'              => 'nullable|string|max:15',
        'nida_no'             => 'nullable|string|max:30',
        'kura_id'             => 'nullable|string|max:50',
        'driving_license_no'  => 'nullable|string|max:50',
        'address'             => 'nullable|string|max:256',
        'city'                => 'nullable|string|max:50',
        'state'               => 'nullable|string|max:50',
        'country_id'          => 'nullable|integer',
        'remarks'             => 'nullable|string|max:256',
        'status_master'       => 'required|string|in:ACTIVE,INACTIVE',
    ]);

    $createdBy  = auth()->user()->name ?? 'admin';
    $macAddress = $request->ip();

    $result = DB::select('EXEC [RMASTER].[SAVE_TENANT] 
        @TENANT_ID = NULL,
        @TENANT_NAME = ?, 
        @LOGIN_NAME = ?, 
        @PASSWORD = ?, 
        @EMAIL = ?, 
        @MOBILE_NO = ?, 
        @TIN_NO = ?, 
        @NIDA_NO = ?, 
        @KURA_ID = ?, 
        @DRIVING_LICENSE_NO = ?, 
        @ADDRESS = ?, 
        @CITY = ?, 
        @STATE = ?, 
        @COUNTRY_ID = ?, 
        @REMARKS = ?, 
        @STATUS_MASTER = ?, 
        @CREATED_BY = ?, 
        @CREATED_MAC_ADDRESS = ?', [
            $request->tenant_name,
            $request->login_name,
            $request->password,
            $request->email,
            $request->mobile_no,
            $request->tin_no,
            $request->nida_no,
            $request->kura_id,
            $request->driving_license_no,
            $request->address,
            $request->city,
            $request->state,
            $request->country_id,
            $request->remarks,
            $request->status_master,
            $createdBy,
            $macAddress
    ]);

    $response = $result[0] ?? null;
    $statusType = $response->Column1 ?? '';
    $message = $response->Column2 ?? '';

    return redirect()->route('tenant')->with([
        'message' => $message,
        'status' => $statusType,
    ]);
}

    /**
     * Update the specified bulding.
     */
    public function update(Request $request)
{
      try {
 
    $request->validate([
        'tenant_id'           => 'required|integer',
        'tenant_name'         => 'required|string|max:100',
        'login_name'          => 'required|string|max:50',
        'password'            => 'required|string|max:50',
        'email'               => 'nullable|email|max:255',
        'mobile_no'           => 'nullable|string|max:15',
        'tin_no'              => 'nullable|string|max:15',
        'nida_no'             => 'nullable|string|max:30',
        'kura_id'             => 'nullable|string|max:50',
        'driving_license_no'  => 'nullable|string|max:50',
        'address'             => 'nullable|string|max:256',
        'city'                => 'nullable|string|max:50',
        'state'               => 'nullable|string|max:50',
        'country_id'          => 'nullable|integer',
        'remarks'             => 'nullable|string|max:256',
        'status_master'       => 'required|string|in:ACTIVE,INACTIVE',
    ]);

    $modifiedBy  = auth()->user()->name ?? 'admin';
    $macAddress  = $request->ip();

    $result = DB::select('EXEC [RMASTER].[UPDATE_TENANT] 
        @TENANT_ID = ?, 
        @TENANT_NAME = ?, 
        @LOGIN_NAME = ?, 
        @PASSWORD = ?, 
        @EMAIL = ?, 
        @MOBILE_NO = ?, 
        @TIN_NO = ?, 
        @NIDA_NO = ?, 
        @KURA_ID = ?, 
        @DRIVING_LICENSE_NO = ?, 
        @ADDRESS = ?, 
        @CITY = ?, 
        @STATE = ?, 
        @COUNTRY_ID = ?, 
        @REMARKS = ?, 
        @STATUS_MASTER = ?, 
        @MODIFIED_BY = ?, 
        @UPDATED_MAC_ADDRESS = ?', [
            $request->tenant_id,
            $request->tenant_name,
            $request->login_name,
            $request->password,
            $request->email,
            $request->mobile_no,
            $request->tin_no,
            $request->nida_no,
            $request->kura_id,
            $request->driving_license_no,
            $request->address,
            $request->city,
            $request->state,
            $request->country_id,
            $request->remarks,
            $request->status_master,
            $modifiedBy,
            $macAddress
    ]);

    $response = $result[0] ?? null;
    $statusType = $response->Column1 ?? '';
    $message    = $response->Column2 ?? 'Something went wrong.';

    return redirect()->route('tenant')->with([
        'message' => $message,
        'status'  => $statusType ?: 'Success',
    ]);
    } catch (\Exception $e) {
        return redirect()->route('tenant')->with([
            'message' => 'Error: ' . $e->getMessage(),
            'status'  => 'Error'
        ]);
    }
}

    /**
     * Remove the specified bulding.
     */
    public function destroy(Request $request)
{
    try {
        $result = DB::select(
            'EXEC [RMASTER].[DELETE_TENANT]
                @TENANT_ID = ?, 
                @MODIFIED_BY = ?, 
                @UPDATED_MAC_ADDRESS = ?',
            [
                $request->input('tenant_id'),
                auth()->user()->name ?? 'admin',
                $request->ip()
            ]
        );

        $response   = $result[0] ?? null;
        $statusType = $response->Column1 ?? 'Success';
        $message    = $response->Column2 ?? 'Tenant deleted successfully.';

        return redirect()->route('tenant')->with([
            'message' => $message,
            'status'  => $statusType
        ]);

    } catch (\Exception $e) {
    return redirect()->route('tenant')->with([
    'message' => 'Error: ' . $e->getMessage(),
    'status'  => 'Error',
    'modal'   => 'deleteTenantModal' // or any name you assign
]);}

}


}


