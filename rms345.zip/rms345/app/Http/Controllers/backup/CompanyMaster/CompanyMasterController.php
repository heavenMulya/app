<?php

namespace App\Http\Controllers\CompanyMaster;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class CompanyMasterController extends Controller
{
public function showCompanyForm(Request $request)
{
    $currencies = DB::select('[RMASTER].[LOAD_CURRENCY_NAME_CURRENCY_MASTER]');
    $companies = DB::select('[RMASTER].[SHOW_COMPANY_MASTER]');
    $statusies = DB::select('[RMASTER].[LOAD_COMMON_DROPDOWN_DTL] 9');
    
    // dd($statusies);
    return view('CompanyMaster.company',[
        'currencies'        =>$currencies,
        'companies'         =>$companies,
        'statusies'         =>$statusies,
        'createdBy'         => auth()->user()->name ?? 'Admin',
        'macAddress'        => $request->ip(),
        'message'              => session('message'),
        'status'               => session('status'),
    ]);
}


public function createCompany(Request $request)
{
    // Validate input
    $request->validate([
        'company_name'              => 'required|string|max:50',
        'shortcode'                 => 'required|string|max:20',
        'currency_id'               => 'required|integer',
        'f_year_start'              => 'required|integer|min:1|max:12',
        'f_year_end'                => 'required|integer|min:1|max:12',
        'contact_person'            => 'required|string|max:50',
        'email'                     => 'required|email|max:100',
        'mobile_no'                 => 'required|string|max:20',
        'remarks'                   => 'nullable|string|max:256',
        'status_master'             => 'required|string|in:ACTIVE,INACTIVE'
    ]);

    $user       = auth()->user()->name ?? 'admin';
    $macAddress = $request->ip();

    // Execute stored procedure
    $result = DB::select(
        'EXEC RMASTER.SAVE_COMPANY_MASTER 
            @COMPANY_ID = ?, 
            @COMPANY_NAME = ?, 
            @SHORT_CODE = ?, 
            @CURRENCY_ID = ?, 
            @FINANCIAL_YEAR_START_MONTH = ?, 
            @FINANCIAL_YEAR_END_MONTH = ?, 
            @CONTACT_PERSON_NAME = ?, 
            @EMAIL = ?, 
            @MOBILE_NO = ?, 
            @REMARKS = ?, 
            @STATUS_MASTER = ?, 
            @CREATED_BY = ?, 
            @CREATED_MAC_ADDRESS = ?',
        [
            null, // OUTPUT param placeholder
            $request->company_name,
            $request->shortcode,
            $request->currency_id,
            $request->f_year_start,
            $request->f_year_end,
            $request->contact_person,
            $request->email,
            $request->mobile_no,
            $request->remarks,
            $request->status_master,
            $user,
            $macAddress
        ]
    );

    // Extract procedure response
    // $response = $result[0] ?? null;
    // $status   = $response->Column1 ?? 'Error';
    // $message  = $response->Column2 ?? 'Unknown response';
    // $companyId = $response->Column3 ?? null;

        $response    = $result[0] ?? null;
        $status  = $response->Column1 ?? '';
        $message     = $response->Column2 ?? '';
        $companyId = $response->Column3 ?? null;
        
       return redirect()->route('company')->with([
                'message' => $message,
                'status'  => $status ?: 'Success'
        ]);

}

public function updateCompany(Request $request)
{
    // Validate update input
    // dd($request->all());
    $request->validate([
        'id'                        => 'required|integer',
        'company_name'              => 'required|string|max:50',
        'shortcode'                 => 'required|string|max:20',
        'currency_id'               => 'required|integer',
        'f_year_start'              => 'required|integer|min:1|max:12',
        'f_year_end'                => 'required|integer|min:1|max:12',
        'contact_person'            => 'required|string|max:50',
        'email'                     => 'required|email|max:100',
        'mobile_no'                 => 'required|string|max:20',
        'remarks'                   => 'nullable|string|max:256',
        'status_master'             => 'required|string|in:ACTIVE,INACTIVE'
    ]);

    $user       = auth()->user()->name ?? 'admin';
    $macAddress = $request->ip();

    // Call the update stored procedure
    $result = DB::select(
        'EXEC RMASTER.UPDATE_COMPANY_MASTER 
            @COMPANY_ID = ?, 
            @COMPANY_NAME = ?, 
            @SHORT_CODE = ?, 
            @CURRENCY_ID = ?, 
            @FINANCIAL_YEAR_START_MONTH = ?, 
            @FINANCIAL_YEAR_END_MONTH = ?, 
            @CONTACT_PERSON_NAME = ?, 
            @EMAIL = ?, 
            @MOBILE_NO = ?, 
            @REMARKS = ?, 
            @STATUS_MASTER = ?, 
            @USER = ?, 
            @UPDATED_MAC_ADDRESS = ?',
        [
            $request->id,
            $request->company_name,
            $request->shortcode,
            $request->currency_id,
            $request->f_year_start,
            $request->f_year_end,
            $request->contact_person,
            $request->email,
            $request->mobile_no,
            $request->remarks,
            $request->status_master,
            $user,
            $macAddress
        ]
    );

    // Extract response from stored procedure
     $response    = $result[0] ?? null;
        $status  = $response->Column1 ?? '';
        $message     = $response->Column2 ?? '';
        $companyId = $response->Column3 ?? null;
        // dd($message);
       return redirect()->route('company')->with([
                'message' => $message,
                'status'  => $status ?: 'Success'
        ]);
}


public function destroy(Request $request)
{
     
    try {
         $request->validate([
        'id'                        => 'required|integer',
        ]);

            $user       = auth()->user()->name ?? 'admin';
            $macAddress = $request->ip();

        $result = DB::select(
            'EXEC [RMASTER].[DELETE_COMPANY_MASTER]
                @COMPANY_ID = ?, 
                @USER = ?, 
                @MAC_ADDRESS = ?',
            [
                $request->id,
                $user,
                $macAddress
               
            ]
        );

        $response    = $result[0] ?? null;
        $status  = $response->Column1 ?? '';
        $message     = $response->Column2 ?? '';
        $companyId = $response->Column3 ?? null;
        //  dd($response);
       return redirect()->route('company')->with([
                'message' => $message,
                'status'  => $status ?: 'Success'
        ]);

    } catch (\Exception $e) {
        return redirect()->route('company.form')->with([
            'message' => 'Error: ' . $e->getMessage(),
            'status'  => 'Error'
        ]);
     }
    }

}
