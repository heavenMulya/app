<?php

namespace App\Http\Controllers\Floor;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class FloorManagementController extends Controller
{
    public function index(Request $request)
    {
        $branchId  = $request->get('branch_id');
        $companyId = $request->get('company_id');

        $floors = DB::select('EXEC [RMASTER].[SHOW_FLOOR_MASTER]');

        $branches = DB::select('SELECT BRANCH_ID, BRANCH_NAME, COMPANY_ID FROM [RENTAL].[RMASTER].[BRANCH_MASTER]');
        $companies = DB::select('SELECT COMPANY_ID, COMPANY_NAME FROM [RENTAL].[RMASTER].[COMPANY_MASTER]');
        $buildings = DB::select('SELECT BUILDING_ID, BUILDING_NAME FROM [RENTAL].[RMASTER].[BUILDING_MASTER]');

        return view('floor.floor', [
            'floors'               => $floors,
            'branches'             => $branches,
            'companies'            => $companies,
            'buildings'            => $buildings,
            'createdBy'            => auth()->user()->name ?? 'Admin',
            'macAddress'           => $request->ip(),
            'selectedBranchId'     => $branchId,
            'selectedCompanyId'    => $companyId,
            'message'              => session('message'),
            'status'               => session('status'),
        ]);
    }

    public function create(Request $request)
    {
        $request->validate([
            'company_id'    => 'required|integer',
            'branch_id'     => 'required|integer',
            'building_id'   => 'required|integer',
            'floor_name'    => 'required|string|max:255',
            'remarks'       => 'nullable|string|max:256',
            'status_master' => 'required|string|max:50',
        ]);

        $createdBy  = auth()->user()->name ?? 'admin';
        $macAddress = $request->ip();

        $result = DB::select(
            'EXEC [RMASTER].[SAVE_FLOOR_MASTER]
                @FLOOR_ID = ?, 
                @COMPANY_ID = ?, 
                @BRANCH_ID = ?, 
                @BUILDING_ID = ?, 
                @FLOOR_NAME = ?, 
                @REMARKS = ?, 
                @STATUS_MASTER = ?, 
                @USER = ?, 
                @UPDATED_MAC_ADDRESS = ?',
            [
                null,
                $request->company_id,
                $request->branch_id,
                $request->building_id,
                $request->floor_name,
                $request->remarks,
                $request->status_master,
                $createdBy,
                $macAddress
            ]
        );

        $response    = $result[0] ?? null;
        $statusType  = $response->Column1 ?? '';
        $message     = $response->Column2 ?? '';

        return redirect()->route('floor')->with([
            'message' => $message,
            'status'  => $statusType ?: 'Success'
        ]);
    }

    public function update(Request $request)
    {
        $request->validate([
            'floor_id'      => 'required|integer',
            'company_id'    => 'required|integer',
            'branch_id'     => 'required|integer',
            'building_id'   => 'required|integer',
            'floor_name'    => 'required|string|max:255',
            'remarks'       => 'nullable|string|max:256',
            'status_master' => 'required|string|max:50',
        ]);

        $user = auth()->user()->name ?? 'admin';
        $mac  = $request->ip();

        try {
            $result = DB::select(
                'EXEC [RMASTER].[UPDATE_FLOOR_MASTER]
                    @FLOOR_ID = ?, 
                    @COMPANY_ID = ?, 
                    @BRANCH_ID = ?, 
                    @BUILDING_ID = ?, 
                    @FLOOR_NAME = ?, 
                    @REMARKS = ?, 
                    @STATUS_MASTER = ?, 
                    @USER = ?, 
                    @UPDATED_MAC_ADDRESS = ?',
                [
                    $request->floor_id,
                    $request->company_id,
                    $request->branch_id,
                    $request->building_id,
                    $request->floor_name,
                    $request->remarks,
                    $request->status_master,
                    $user,
                    $mac
                ]
            );

            $response   = $result[0] ?? null;
            $statusType = $response->Column1 ?? '';
            $message    = $response->Column2 ?? '';

            return redirect()->route('floor')->with([
                'message' => $message,
                'status'  => $statusType ?: 'Success'
            ]);
        } catch (\Exception $e) {
            return redirect()->route('floor')->with([
                'message' => 'Update failed: ' . $e->getMessage(),
                'status'  => 'Error'
            ]);
        }
    }

    public function destroy(Request $request)
    {
        $request->validate([
            'floor_id' => 'required|integer'
        ]);

        try {
            $result = DB::select(
                'EXEC [RMASTER].[DELETE_FLOOR_MASTER]
                    @FLOOR_ID = ?, 
                    @USER = ?, 
                    @MAC_ADDRESS = ?',
                [
                    $request->input('floor_id'),
                    auth()->user()->name ?? 'admin',
                    $request->ip()
                ]
            );

            $response   = $result[0] ?? null;
            $statusType = $response->Column1 ?? '';
            $message    = $response->Column2 ?? '';

            return redirect()->route('floor')->with([
                'message' => $message,
                'status'  => $statusType ?: 'Success'
            ]);
        } catch (\Exception $e) {
            return redirect()->route('floor')->with([
                'message' => 'Error: ' . $e->getMessage(),
                'status'  => 'Error'
            ]);
        }
    }
}
