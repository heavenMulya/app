<?php
namespace App\Http\Controllers\Floor;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class FloorManagementController extends Controller
{
    public function index(Request $request)
    {
        $branchId  = $request->get('branch_id');
        $companyId = $request->get('company_id');

        $floors = DB::select('EXEC [RMASTER].[SHOW_FLOOR_MASTER]');

        $branches = DB::select('SELECT BRANCH_ID, BRANCH_NAME, COMPANY_ID FROM [RENTAL].[RMASTER].[BRANCH_MASTER]');
        $companies = DB::select('SELECT COMPANY_ID, COMPANY_NAME FROM [RENTAL].[RMASTER].[COMPANY_MASTER]');
        $buildings = DB::select('SELECT BUILDING_ID, BUILDING_NAME FROM [RENTAL].[RMASTER].[BUILDING_MASTER]');

        return view('floor.floor', [
            'floors'               => $floors,
            'branches'             => $branches,
            'companies'            => $companies,
            'buildings'            => $buildings,
            'createdBy'            => auth()->user()->name ?? 'Admin',
            'macAddress'           => $request->ip(),
            'selectedBranchId'     => $branchId,
            'selectedCompanyId'    => $companyId,
            'message'              => session('message'),
            'status'               => session('status'),
            'updated_floor_data'   => session('updated_floor_data'),
            'show_edit_view'       => session('show_edit_view')
        ]);
    }

    public function create(Request $request)
    {
        try {
            $request->validate([
                'company_id'    => 'required|integer',
                'branch_id'     => 'required|integer',
                'building_id'   => 'required|integer',
                'floor_name'    => 'required|string|max:255',
                'remarks'       => 'nullable|string|max:256',
                'status_master' => 'required|string|max:50',
            ]);

            $createdBy  = auth()->user()->name ?? 'admin';
            $macAddress = $request->ip();

            $result = DB::select(
                'EXEC [RMASTER].[SAVE_FLOOR_MASTER]
                    @FLOOR_ID = ?, 
                    @COMPANY_ID = ?, 
                    @BRANCH_ID = ?, 
                    @BUILDING_ID = ?, 
                    @FLOOR_NAME = ?, 
                    @REMARKS = ?, 
                    @STATUS_MASTER = ?, 
                    @USER = ?, 
                    @UPDATED_MAC_ADDRESS = ?',
                [
                    null,
                    $request->company_id,
                    $request->branch_id,
                    $request->building_id,
                    $request->floor_name,
                    $request->remarks,
                    $request->status_master,
                    $createdBy,
                    $macAddress
                ]
            );

            $response    = $result[0] ?? null;
            $statusType  = $response->Column1 ?? '';
            $message     = $response->Column2 ?? '';

            return redirect()->route('floor')->with([
                'message' => $message,
                'status'  => $statusType ?: 'Success'
            ]);
        } catch (\Exception $e) {
            return redirect()->route('floor')->with([
                'message' => 'Exception: ' . $e->getMessage(),
                'status' => 'Error'
            ]);
        }
    }

    public function update(Request $request)
    {
        
        try {
            $request->validate([
                'id'            => 'required|integer',
                'company_id'    => 'required|integer',
                'branch_id'     => 'required|integer',
                'building_id'   => 'required|integer',
                'floor_name'    => 'required|string|max:255',
                'remarks'       => 'nullable|string|max:256',
                'status_master' => 'required|string|max:50',
            ]);

            $user = auth()->user()->name ?? 'admin';
            $mac  = $request->ip();

            $result = DB::select(
                'EXEC [RMASTER].[UPDATE_FLOOR_MASTER]
                    @FLOOR_ID = ?, 
                    @COMPANY_ID = ?, 
                    @BRANCH_ID = ?, 
                    @BUILDING_ID = ?, 
                    @FLOOR_NAME = ?, 
                    @REMARKS = ?, 
                    @STATUS_MASTER = ?, 
                    @USER = ?, 
                    @UPDATED_MAC_ADDRESS = ?',
                [
                    $request->id,
                    $request->company_id,
                    $request->branch_id,
                    $request->building_id,
                    $request->floor_name,
                    $request->remarks,
                    $request->status_master,
                    $user,
                    $mac
                ]
            );

            $response   = $result[0] ?? null;
            $statusType = $response->Column1 ?? '';
            $message    = $response->Column2 ?? '';

            return redirect()->route('floor')->with([
                'message' => $message,
                'status'  => $statusType ?: 'Success'
            ]);
            dd($message, $statusType);
        } catch (\Exception $e) {
            // Store the submitted data to pre-fill the edit form
            $floorData = [
                'id' => $request->id,
                'COMPANY_ID' => $request->company_id,
                'BRANCH_ID' => $request->branch_id,
                'BUILDING_ID' => $request->building_id,
                'FLOOR_NAME' => $request->floor_name,
                'Remarks' => $request->remarks,
                'IS_ACTIVE' => $request->status_master,
                // Fetch names for display purposes
                'COMPANY_NAME' => DB::selectOne('SELECT COMPANY_NAME FROM [RENTAL].[RMASTER].[COMPANY_MASTER] WHERE COMPANY_ID = ?', [$request->company_id])?->COMPANY_NAME ?? '',
                'BRANCH_NAME' => DB::selectOne('SELECT BRANCH_NAME FROM [RENTAL].[RMASTER].[BRANCH_MASTER] WHERE BRANCH_ID = ?', [$request->branch_id])?->BRANCH_NAME ?? '',
                'BUILDING_NAME' => DB::selectOne('SELECT BUILDING_NAME FROM [RENTAL].[RMASTER].[BUILDING_MASTER] WHERE BUILDING_ID = ?', [$request->building_id])?->BUILDING_NAME ?? ''
            ];

            return redirect()->route('floor')->with([
                'message' => 'Update failed: ' . $e->getMessage(),
                'status' => 'Error',
                'updated_floor_data' => $floorData,
                'show_edit_view' => true
            ]);
        }
    }

    public function destroy(Request $request)
    {
        try {
            $request->validate([
                'id' => 'required|integer'
            ]);

            $result = DB::select(
                'EXEC [RMASTER].[DELETE_FLOOR_MASTER]
                    @FLOOR_ID = ?, 
                    @USER = ?, 
                    @MAC_ADDRESS = ?',
                [
                    $request->input('id'),
                    auth()->user()->name ?? 'admin',
                    $request->ip()
                ]
            );

            $response   = $result[0] ?? null;
            $statusType = $response->Column1 ?? '';
            $message    = $response->Column2 ?? '';

            return redirect()->route('floor')->with([
                'message' => $message,
                'status'  => $statusType ?: 'Success'
            ]);
        } catch (\Exception $e) {
            return redirect()->route('floor')->with([
                'message' => 'Error: ' . $e->getMessage(),
                'status' => 'Error'
            ]);
        }
    }
}
?>