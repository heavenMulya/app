<?php

namespace App\Http\Controllers\Company;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CompanyManagementController extends Controller
{
public function showCompanyForm(Request $request)
{
    $currencies = DB::select('[RMASTER].[LOAD_CURRENCY_NAME_CURRENCY_MASTER]');
    $companies = DB::select('[RMASTER].[SHOW_COMPANY_MASTER]');
    

    return view('CompanyMaster.create',[
        'currencies'        =>$currencies,
        'companies'         =>$companies,
        'createdBy'         => auth()->user()->name ?? 'Admin',
        'macAddress'        => $request->ip(),
    ]);
}


public function createCompany(Request $request)
{
    // Validate input
    $request->validate([
        'company_name'               => 'required|string|max:50',
        'short_code'                 => 'required|string|max:20',
        'currency_id'                => 'required|integer',
        'financial_year_start_month'=> 'required|integer|min:1|max:12',
        'financial_year_end_month'  => 'required|integer|min:1|max:12',
        'contact_person_name'       => 'required|string|max:50',
        'email'                     => 'required|email|max:100',
        'mobile_no'                 => 'required|string|max:20',
        'remarks'                   => 'nullable|string|max:256',
        'status_master'             => 'required|string|in:YES,NO'
    ]);

    $user       = auth()->user()->name ?? 'admin';
    $macAddress = $request->ip();

    // Execute stored procedure
    $result = DB::select(
        'EXEC RMASTER.SAVE_COMPANY_MASTER 
            @COMPANY_ID = ?, 
            @COMPANY_NAME = ?, 
            @SHORT_CODE = ?, 
            @CURRENCY_ID = ?, 
            @FINANCIAL_YEAR_START_MONTH = ?, 
            @FINANCIAL_YEAR_END_MONTH = ?, 
            @CONTACT_PERSON_NAME = ?, 
            @EMAIL = ?, 
            @MOBILE_NO = ?, 
            @REMARKS = ?, 
            @STATUS_MASTER = ?, 
            @CREATED_BY = ?, 
            @CREATED_MAC_ADDRESS = ?',
        [
            null, // OUTPUT param placeholder
            $request->company_name,
            $request->short_code,
            $request->currency_id,
            $request->financial_year_start_month,
            $request->financial_year_end_month,
            $request->contact_person_name,
            $request->email,
            $request->mobile_no,
            $request->remarks,
            $request->status_master,
            $user,
            $macAddress
        ]
    );

    // Extract procedure response
    $response = $result[0] ?? null;
    $status   = $response->Column1 ?? 'Error';
    $message  = $response->Column2 ?? 'Unknown response';
    $companyId = $response->Column3 ?? null;

    return response()->json([
        'status'     => $status,
        'message'    => $message,
        'company_id' => $companyId
    ]);
}

public function updateCompany(Request $request)
{
    // Validate update input
    $request->validate([
        'company_name'               => 'required|string|max:50',
        'short_code'                 => 'required|string|max:20',
        'currency_id'                => 'required|integer',
        'financial_year_start_month'=> 'required|integer|min:1|max:12',
        'financial_year_end_month'  => 'required|integer|min:1|max:12',
        'contact_person_name'       => 'required|string|max:50',
        'email'                     => 'required|email|max:100',
        'mobile_no'                 => 'required|string|max:20',
        'remarks'                   => 'nullable|string|max:256',
        'status_master'             => 'required|string|in:YES,NO'
    ]);

    $user       = auth()->user()->name ?? 'admin';
    $macAddress = $request->ip();

    // Call the update stored procedure
    $result = DB::select(
        'EXEC RMASTER.UPDATE_COMPANY_MASTER 
            @COMPANY_ID = ?, 
            @COMPANY_NAME = ?, 
            @SHORT_CODE = ?, 
            @CURRENCY_ID = ?, 
            @FINANCIAL_YEAR_START_MONTH = ?, 
            @FINANCIAL_YEAR_END_MONTH = ?, 
            @CONTACT_PERSON_NAME = ?, 
            @EMAIL = ?, 
            @MOBILE_NO = ?, 
            @REMARKS = ?, 
            @STATUS_MASTER = ?, 
            @UPDATED_BY = ?, 
            @UPDATED_MAC_ADDRESS = ?',
        [
            $request->$id,
            $request->company_name,
            $request->short_code,
            $request->currency_id,
            $request->financial_year_start_month,
            $request->financial_year_end_month,
            $request->contact_person_name,
            $request->email,
            $request->mobile_no,
            $request->remarks,
            $request->status_master,
            $user,
            $macAddress
        ]
    );

    // Extract response from stored procedure
    $response = $result[0] ?? null;
    $status   = $response->Column1 ?? 'Error';
    $message  = $response->Column2 ?? 'Unknown response';

    return response()->json([
        'status'     => $status,
        'message'    => $message,
        'company_id' => $id
    ]);
}











}

