<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserManagementController extends Controller
{
    public function index(Request $request)
    {
        $branchId  = $request->get('branch_id');
        $companyId = $request->get('company_id');

        $users = DB::select('EXEC [RMASTER].[SHOW_USER_MASTER]');
        $roles = DB::select('SELECT ROLE_ID, ROLE_NAME FROM [RENTAL].[RMASTER].[ROLE_MASTER]');

        if ($companyId) {
            $branches = DB::select('SELECT BRANCH_ID, BRANCH_NAME, COMPANY_ID 
                                    FROM [RENTAL].[RMASTER].[BRANCH_MASTER] 
                                    WHERE COMPANY_ID = ?', [$companyId]);
        } else {
            $branches = DB::select('SELECT BRANCH_ID, BRANCH_NAME, COMPANY_ID 
                                    FROM [RENTAL].[RMASTER].[BRANCH_MASTER]');
        }

        if ($branchId && !$companyId) {
            $company = collect($branches)->firstWhere('BRANCH_ID', $branchId);
            $companyId = $company->COMPANY_ID ?? null;
        }

        return view('user.user', [
            'user'                => $users,
            'roles'               => $roles,
            'branches'            => $branches,
            'createdBy'           => auth()->user()->name ?? 'Admin',
            'macAddress'          => $request->ip(),
            'selectedBranchId'    => $branchId,
            'selectedCompanyId'   => $companyId,
            'message'             => session('message'),
            'status'              => session('status')
        ]);
    }

    /**
     * Store a newly created user in the database.
     */
    public function create(Request $request)
    {
        $request->validate([
            'role_name'      => 'required|string|max:255',
            'user_name'      => 'required|string|max:255',
            'user_password'  => 'required|string|max:255',
            'email_address'  => 'required|email|max:255',
            'mobile_number'  => 'required|string|max:20',
            'remarks'        => 'nullable|string|max:255',
            'status_master'  => 'required|string',
        ]);

        $createdBy  = auth()->user()->name ?? 'admin';
        $macAddress = $request->ip();

        $result = DB::select(
            'EXEC [RMASTER].[SAVE_USER_MASTER] 
                @USER_ID = ?, 
                @USER_TYPE = ?, 
                @USERNAME = ?, 
                @PASSWORD = ?, 
                @EMAIL = ?, 
                @MOBILE_NO = ?, 
                @REMARKS = ?, 
                @STATUS_MASTER = ?, 
                @CREATED_BY = ?, 
                @CREATED_MAC_ADDRESS = ?',
            [
                null,
                $request->role_name,
                $request->user_name,
                $request->user_password,
                $request->email_address,
                $request->mobile_number,
                $request->remarks,
                $request->status_master,
                $createdBy,
                $macAddress
            ]
        );

        $response    = $result[0] ?? null;
        $statusType  = $response->Column1 ?? '';
        $message     = $response->Column2 ?? '';

        return redirect()->route('userManagement')->with([
            'message' => $message,
            'status'  => $statusType ?: 'Success'
        ]);
    }

    /**
     * Update the specified user in the database.
     */
    public function update(Request $request)
    {
        $request->validate([
            'id'            => 'required|integer',
            'role_name'     => 'required|string|max:255',
            'user_name'     => 'required|string|max:255',
            // 'user_password' => 'required|string|max:255',
            'email_address' => 'required|email|max:255',
            'mobile_number' => 'required|string|max:20',
            'remarks'       => 'nullable|string|max:255',
            'status_master' => 'required|string',
        ]);

        try {
            $result = DB::select(
                'EXEC [RMASTER].[UPDATE_USER_MASTER]
                    @USER_ID = ?, 
                    @USER_TYPE = ?, 
                    @USERNAME = ?, 
                    @PASSWORD = ?, 
                    @EMAIL = ?, 
                    @MOBILE_NO = ?, 
                    @REMARKS = ?, 
                    @STATUS_MASTER = ?, 
                    @USER = ?, 
                    @UPDATED_MAC_ADDRESS = ?',
                [
                    $request->id,
                    $request->role_name,
                    $request->user_name,
                    $request->user_password,
                    $request->email_address,
                    $request->mobile_number,
                    $request->remarks,
                    $request->status_master,
                    auth()->user()->name ?? 'admin',
                    $request->ip()
                ]
            );

            $response   = $result[0] ?? null;
            $statusType = $response->Column1 ?? '';
            $message    = $response->Column2 ?? '';

            return redirect()->route('userManagement')->with([
                'message' => $message,
                'status'  => $statusType ?: 'Success'
            ]);
        } catch (\Exception $e) {
            return redirect()->route('userManagement')->with([
                'message' => 'Update failed: ' . $e->getMessage(),
                'status'  => 'Error'
            ]);
        }
    }

    /**
     * Remove the specified user from the system.
     */
    public function destroy(Request $request)
    {
        try {
            $result = DB::select(
                'EXEC [RMASTER].[DELETE_USER_MASTER]
                    @USER_ID = ?, 
                    @USER = ?, 
                    @MAC_ADDRESS = ?',
                [
                    $request->input('id'),
                    auth()->user()->name ?? 'admin',
                    $request->ip()
                ]
            );

            $response   = $result[0] ?? null;
            $statusType = $response->Column1 ?? '';
            $message    = $response->Column2 ?? '';

            return redirect()->route('userManagement')->with([
                'message' => $message,
                'status'  => $statusType ?: 'Success'
            ]);
        } catch (\Exception $e) {
            return redirect()->route('userManagement')->with([
                'message' => 'Error: ' . $e->getMessage(),
                'status'  => 'Error'
            ]);
        }
    }
}
