<?php

namespace App\Http\Controllers\CompanyMaster;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CompanyMasterController extends Controller
{
    public function showCompanyForm(Request $request)
    {
        $currencies = DB::select('[RMASTER].[LOAD_CURRENCY_NAME_CURRENCY_MASTER]');
        $companies = DB::select('[RMASTER].[SHOW_COMPANY_MASTER]');
        $statusies = DB::select('[RMASTER].[LOAD_COMMON_DROPDOWN_DTL] 9');
        
        return view('CompanyMaster.company', [
            'currencies' => $currencies,
            'companies' => $companies,
            'statusies' => $statusies,
            'createdBy' => auth()->user()->name ?? 'Admin',
            'macAddress' => $request->ip(),
            'message' => session('message'),
            'status' => session('status'),
        ]);
    }

    public function createCompany(Request $request)
    {
        try {
            $request->validate([
                'company_name' => 'required|string|max:50',
                'shortcode' => 'required|string|max:20',
                'currency_id' => 'required|integer',
                'f_year_start' => 'required|integer|min:1|max:12',
                'f_year_end' => 'required|integer|min:1|max:12',
                'contact_person' => 'required|string|max:50',
                'email' => 'required|email|max:100',
                'mobile_no' => 'required|string|max:20',
                'remarks' => 'nullable|string|max:256',
                'status_master' => 'required|string|in:ACTIVE,INACTIVE'
            ]);

            $user = auth()->user()->name ?? 'admin';
            $macAddress = $request->ip();

            $result = DB::select(
                'EXEC RMASTER.SAVE_COMPANY_MASTER 
                    @COMPANY_ID = ?, 
                    @COMPANY_NAME = ?, 
                    @SHORT_CODE = ?, 
                    @CURRENCY_ID = ?, 
                    @FINANCIAL_YEAR_START_MONTH = ?, 
                    @FINANCIAL_YEAR_END_MONTH = ?, 
                    @CONTACT_PERSON_NAME = ?, 
                    @EMAIL = ?, 
                    @MOBILE_NO = ?, 
                    @REMARKS = ?, 
                    @STATUS_MASTER = ?, 
                    @CREATED_BY = ?, 
                    @CREATED_MAC_ADDRESS = ?',
                [
                    null,
                    $request->company_name,
                    $request->shortcode,
                    $request->currency_id,
                    $request->f_year_start,
                    $request->f_year_end,
                    $request->contact_person,
                    $request->email,
                    $request->mobile_no,
                    $request->remarks,
                    $request->status_master,
                    $user,
                    $macAddress
                ]
            );

            $response = $result[0] ?? null;
            $status = $response->Column1 ?? '';
            $message = $response->Column2 ?? '';
            $companyId = $response->Column3 ?? null;
            
            return redirect()->route('company')->with([
                'message' => $message,
                'status' => $status ?: 'Success'
            ]);
        } catch (\Exception $e) {
            return redirect()->route('company')->with([
                'message' => 'Exception: ' . $e->getMessage(),
                'status' => 'Error'
            ]);
        }
    }

    public function updateCompany(Request $request)
    {
        try {
            $request->validate([
                'id' => 'required|integer',
                'company_name' => 'required|string|max:50',
                'shortcode' => 'required|string|max:20',
                'currency_id' => 'required|integer',
                'f_year_start' => 'required|integer|min:1|max:12',
                'f_year_end' => 'required|integer|min:1|max:12',
                'contact_person' => 'required|string|max:50',
                'email' => 'required|email|max:100',
                'mobile_no' => 'required|string|max:20',
                'remarks' => 'nullable|string|max:256',
                'status_master' => 'required|string|in:ACTIVE,INACTIVE'
            ]);

            $user = auth()->user()->name ?? 'admin';
            $macAddress = $request->ip();

            $result = DB::select(
                'EXEC RMASTER.UPDATE_COMPANY_MASTER 
                    @COMPANY_ID = ?, 
                    @COMPANY_NAME = ?, 
                    @SHORT_CODE = ?, 
                    @CURRENCY_ID = ?, 
                    @FINANCIAL_YEAR_START_MONTH = ?, 
                    @FINANCIAL_YEAR_END_MONTH = ?, 
                    @CONTACT_PERSON_NAME = ?, 
                    @EMAIL = ?, 
                    @MOBILE_NO = ?, 
                    @REMARKS = ?, 
                    @STATUS_MASTER = ?, 
                    @USER = ?, 
                    @UPDATED_MAC_ADDRESS = ?',
                [
                    $request->id,
                    $request->company_name,
                    $request->shortcode,
                    $request->currency_id,
                    $request->f_year_start,
                    $request->f_year_end,
                    $request->contact_person,
                    $request->email,
                    $request->mobile_no,
                    $request->remarks,
                    $request->status_master,
                    $user,
                    $macAddress
                ]
            );

            $response = $result[0] ?? null;
            $status = $response->Column1 ?? '';
            $message = $response->Column2 ?? '';
            $companyId = $response->Column3 ?? null;

            return redirect()->route('company')->with([
                'message' => $message,
                'status' => $status ?: 'Success'
            ]);
        } catch (\Exception $e) {
            // Prepare company data to repopulate the edit form
            $companyData = [
                'id' => $request->id,
                'Company' => $request->company_name,
                'ShortCode' => $request->shortcode,
                'CURRENCY_ID' => $request->currency_id,
                'f_year_start' => $request->f_year_start,
                'f_year_end' => $request->f_year_end,
                'ContactPerson' => $request->contact_person,
                'EMAIL' => $request->email,
                'MOBILE_NO' => $request->mobile_no,
                'REMARKS' => $request->remarks,
                'STATUS_MASTER' => $request->status_master
            ];

            return redirect()->route('company')->with([
                'message' => 'Exception: ' . $e->getMessage(),
                'status' => 'Error',
                'show_edit_view' => true,
                'updated_company_data' => $companyData
            ]);
        }
    }

    public function destroy(Request $request)
    {
        try {
            $request->validate([
                'id' => 'required|integer',
            ]);

            $user = auth()->user()->name ?? 'admin';
            $macAddress = $request->ip();

            $result = DB::select(
                'EXEC [RMASTER].[DELETE_COMPANY_MASTER]
                    @COMPANY_ID = ?, 
                    @USER = ?, 
                    @MAC_ADDRESS = ?',
                [
                    $request->id,
                    $user,
                    $macAddress
                ]
            );

            $response = $result[0] ?? null;
            $status = $response->Column1 ?? '';
            $message = $response->Column2 ?? '';
            $companyId = $response->Column3 ?? null;

            return redirect()->route('company')->with([
                'message' => $message,
                'status' => $status ?: 'Success'
            ]);
        } catch (\Exception $e) {
            return redirect()->route('company')->with([
                'message' => 'Error: ' . $e->getMessage(),
                'status' => 'Error'
            ]);
        }
    }
}
