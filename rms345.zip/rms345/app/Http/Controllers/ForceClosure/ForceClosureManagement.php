<?php

namespace App\Http\Controllers\ForceClosure;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ForceClosureManagement extends Controller
{
    //
}
