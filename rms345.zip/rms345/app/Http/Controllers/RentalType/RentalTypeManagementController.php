<?php

namespace App\Http\Controllers\RentalType;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RentalTypeManagementController extends Controller


{
    public function index(Request $request)
    {
        $rentalTypes = DB::select('EXEC [RMASTER].[SHOW_RENTAL_TYPE]');

        return view('RentalType.RentalType', [
            'rentalTypes' => $rentalTypes,
            'createdBy' => auth()->user()->name ?? 'Admin',
            'macAddress' => $request->ip(),
            'message' => session('message'),
            'status' => session('status'),
        ]);
    }

    public function create(Request $request)
    {
        $request->validate([
            'rental_type_name' => 'required|string|max:100',
            'remarks' => 'nullable|string|max:256',
            'status_master' => 'required|string|max:50',
        ]);

        $createdBy = auth()->user()->name ?? 'admin';
        $macAddress = $request->ip();

        $result = DB::select(
            'EXEC [RMASTER].[SAVE_RENTAL_TYPE]
                @RENTAL_TYPE_ID = ?, 
                @RENTAL_TYPE_NAME = ?, 
                @REMARKS = ?, 
                @STATUS_MASTER = ?, 
                @USER = ?, 
                @CREATED_MAC_ADDRESS = ?',
            [
                null,
                $request->rental_type_name,
                $request->remarks,
                $request->status_master,
                $createdBy,
                $macAddress
            ]
        );

        $response = $result[0] ?? null;
        $statusType = $response->Column1 ?? '';
        $message = $response->Column2 ?? '';

        return redirect()->route('rental-type')->with([
            'message' => $message,
            'status' => $statusType ?: 'Success'
        ]);
    }

    public function update(Request $request)
    {
        $request->validate([
            'rental_type_id' => 'required|integer',
            'rental_type_name' => 'required|string|max:100',
            'remarks' => 'nullable|string|max:256',
            'status_master' => 'required|string|max:50',
        ]);

        $user = auth()->user()->name ?? 'admin';
        $mac = $request->ip();

        try {
            $result = DB::select(
                'EXEC [RMASTER].[UPDATE_RENTAL_TYPE]
                    @RENTAL_TYPE_ID = ?, 
                    @RENTAL_TYPE_NAME = ?, 
                    @REMARKS = ?, 
                    @STATUS_MASTER = ?, 
                    @USER = ?, 
                    @UPDATED_MAC_ADDRESS = ?',
                [
                    $request->rental_type_id,
                    $request->rental_type_name,
                    $request->remarks,
                    $request->status_master,
                    $user,
                    $mac
                ]
            );

            $response = $result[0] ?? null;
            $statusType = $response->Column1 ?? '';
            $message = $response->Column2 ?? '';

            return redirect()->route('rental-type')->with([
                'message' => $message,
                'status' => $statusType ?: 'Success'
            ]);
        } catch (\Exception $e) {
            return redirect()->route('rental-type')->with([
                'message' => 'Update failed: ' . $e->getMessage(),
                'status' => 'Error'
            ]);
        }
    }

    public function destroy(Request $request)
    {
        $request->validate([
            'rental_type_id' => 'required|integer'
        ]);

        try {
            $result = DB::select(
                'EXEC [RMASTER].[DELETE_RENTAL_TYPE]
                    @RENTAL_TYPE_ID = ?, 
                    @USER = ?, 
                    @MAC_ADDRESS = ?',
                [
                    $request->input('rental_type_id'),
                    auth()->user()->name ?? 'admin',
                    $request->ip()
                ]
            );

            $response = $result[0] ?? null;
            $statusType = $response->Column1 ?? '';
            $message = $response->Column2 ?? '';

            return redirect()->route('rental-type')->with([
                'message' => $message,
                'status' => $statusType ?: 'Success'
            ]);
        } catch (\Exception $e) {
            return redirect()->route('rental-type')->with([
                'message' => 'Error: ' . $e->getMessage(),
                'status' => 'Error'
            ]);
        }
    }
}

