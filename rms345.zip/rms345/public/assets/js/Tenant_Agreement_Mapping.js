
document.addEventListener('DOMContentLoaded', function () {

    const modal = document.getElementById('addModal');

    modal.addEventListener('shown.bs.modal', function () {
        const renewalInput = document.getElementById('renewal_percentage');
    console.log(`✅ User finished typing. Renewal % is: ${value}`);
        if (renewalInput) {
            renewalInput.addEventListener('blur', function () {
                const value = parseFloat(this.value) || 0;

                if (value > 0) {
                    console.log(`✅ User finished typing. Renewal % is: ${value}`);
                } else {
                    console.log(`⚠️ Renewal % is empty or zero.`);
                }
            });
        }
    });


    document.querySelectorAll('[data-id][data-tenant]').forEach(button => {
        button.addEventListener('click', function () {
            const docId = this.getAttribute('data-id');
            const filePath = this.getAttribute('data-tenant');

            console.log("🆔 DOC_ID:", docId);
            console.log("📁 FILE_PATH:", filePath);

            // Example: Display inside modal or somewhere on the page
            document.getElementById('docIdDisplay')?.textContent = docId;
            document.getElementById('filePathDisplay')?.textContent = filePath;
        });
    });
});



document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.view-document-btn').forEach(button => {
        button.addEventListener('click', function () {
            const docName = this.getAttribute('data-doc-name');
            const filePath = this.getAttribute('data-file-path');

            // Build the HTML
            const html = `
                <div class="d-flex align-items-center gap-2 mt-1">
                    <button type="button" 
                            class="btn btn-outline-primary btn-sm"
                            title="View Agreement Document"
                            data-bs-toggle="modal"
                            data-bs-target="#documentPreviewModal"
                            data-doc-name="${docName}"
                            data-file-path="${filePath}">
                        <i class="fas fa-eye me-1"></i> View Document
                    </button>
                    <span class="text-muted small">${docName}</span>
                </div>
            `;

            // Inject into your container
            const container = document.getElementById('documentListContainer');
            container.innerHTML = html;
        });
    });
});

 



 
document.addEventListener('DOMContentLoaded', function () {
    const modal = document.getElementById('documentModal');
    const tenantSelect = document.getElementById('view_tenant_id_for_document');
    const agreementSelect = document.getElementById('agreement_id');

    document.querySelectorAll('.add-document-btn').forEach(button => {
        button.addEventListener('click', function () {
            const agreementId = this.getAttribute('data-id');
            const tenantId = this.getAttribute('data-tenant');

            console.log("📄 Agreement IDleo:", agreementId);
            console.log("👤 Tenant ID:", tenantId);

            // Ensure the <option> exists in the dropdown before selecting
            function ensureOption(selectEl, value) {
                if (!selectEl.querySelector(`option[value="${value}"]`)) {
                    const option = document.createElement('option');
                    option.value = value;
                    option.textContent = `Agreement ID:${value}`;
                    selectEl.appendChild(option);
                }
                selectEl.value = value;
            }

            ensureOption(tenantSelect, tenantId);
            ensureOption(agreementSelect, agreementId);
        });
    });
});
 

 
    $(document).ready(function () {
  // Utility to populate any dropdown with data
  


  // Load common dropdown data based on FIELD_ID and fill the select element
  function loadCommonDropdown(fieldId, $select) {
    console.log(`Loading common dropdown for FIELD_ID: ${fieldId}`);

    $.ajax({
      url: '/common-dropdown',   // Your API route to get common dropdown data
      method: 'GET',
      data: { id: fieldId },
      dataType: 'json',
      success: function (response) {
        console.log('Common dropdown response:', response.data);

        if (response.status === 'success') {
          populateDropdown($select, response.data, 'ACTIVITY_NAME', 'ACTIVITY_NAME');
        //  console.log('Dropdown populated successfully');
        } else {
          console.error('Error loading common dropdown:', response.message);
        }
      },
      error: function (xhr, status, error) {
        console.error('AJAX error loading common dropdown:', error);
      }
    });
  }

  function populateDropdown($select, data, idField, nameField, selectedValue = '') {


    $select.empty();
      console.log('these is called1', $select);
    $select.append('<option value="">-- Select --</option>');
      console.log('these is called2', data.length);
    if (data && data.length > 0) {
      data.forEach(item => {
        const isSelected = item[idField] == selectedValue ? 'selected' : '';
        $select.append(`<option value="${item[idField]}" ${isSelected}>${item[nameField]}</option>`);
        // console.log('these is called2', item);

      });
    }
  }


  // Call this on page load, passing FIELD_ID and the select jQuery object
 // loadCommonDropdown(3, $('#currency_id'));
    $('#editAgreementModal').on('shown.bs.modal', function () {
    // Fetch status data and populate
     console.log('these is called2 in model');
    loadCommonDropdown(9, $('#status_master'));
});

    
});














document.addEventListener('DOMContentLoaded', function () {
    const branchSelect   = document.getElementById('branch_id');
    const buildingSelect = document.getElementById('building_id');
    const floorSelect    = document.getElementById('floor_id');
    const propertySelect = document.getElementById('property_id');

    floorSelect?.addEventListener('change', function () {
        const floorId   = floorSelect.value;
        const branchId  = branchSelect?.value;
        const buildingId = buildingSelect?.value;

        if (!branchId || !buildingId || !floorId) {
            console.warn("⚠️ One or more required fields are missing.");
            propertySelect.innerHTML = '<option value="">-- Select Property --</option>';
            return;
        }

        console.log("📤 Requesting property for Branch:", branchId, "Building:", buildingId, "Floor:", floorId);

        fetch(`/load-property?branch_id=${encodeURIComponent(branchId)}&building_id=${encodeURIComponent(buildingId)}&floor_id=${encodeURIComponent(floorId)}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' }
        })
        .then(response => {
            if (!response.ok) throw new Error(`Server error: ${response.status}`);
            return response.json();
        })
        .then(result => {
            const properties = result.data || [];
            console.log("🏠 Properties received:", properties);

            // Populate property dropdown
            propertySelect.innerHTML = '<option value="">-- Select Property --</option>';
            properties.forEach(p => {
                if (p.PROPERTY_ID && p.PROPERTY_NAME) {
                    const option = document.createElement('option');
                    option.value = p.PROPERTY_ID;
                    option.textContent = p.PROPERTY_NAME;
                    propertySelect.appendChild(option);
                }
            });
        })
        .catch(error => {
            console.error("🚨 Failed to load properties:", error);
            propertySelect.innerHTML = '<option value="">-- Select Property --</option>';
        });
    });
});
 

 
document.addEventListener('DOMContentLoaded', function () {
    const branchSelect   = document.getElementById('branch_id');
    const buildingSelect = document.getElementById('building_id');
    const floorSelect    = document.getElementById('floor_id');

    buildingSelect?.addEventListener('change', function () {
        const buildingId = this.value;
        const branchId   = branchSelect?.value;

        if (!branchId || !buildingId) {
            console.warn("⚠️ Missing branch or building ID.");
            floorSelect.innerHTML = '<option value="">-- Select Floor --</option>';
            return;
        }

        console.log("📤 Fetching floors for Branch:", branchId, "and Building:", buildingId);

        fetch(`/load-floors?branch_id=${encodeURIComponent(branchId)}&building_id=${encodeURIComponent(buildingId)}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' }
        })
        .then(response => {
            if (!response.ok) throw new Error(`Server error: ${response.status}`);
            return response.json();
        })
        .then(result => {
            const floors = result.data || [];
            console.log("🏢 Floors received:", floors);

            // Clear and repopulate floor dropdown
            floorSelect.innerHTML = '<option value="">-- Select Floor --</option>';
            floors.forEach(floor => {
                if (floor.FLOOR_ID && floor.FLOOR_NAME) {
                    const option = document.createElement('option');
                    option.value = floor.FLOOR_ID;
                    option.textContent = floor.FLOOR_NAME;
                    floorSelect.appendChild(option);
                }
            });
        })
        .catch(error => {
            console.error("🚨 Failed to load floors:", error);
            floorSelect.innerHTML = '<option value="">-- Select Floor --</option>';
        });
    });
});
 


 
document.addEventListener('DOMContentLoaded', function () {
    const branchSelect = document.getElementById('branch_id');
    const buildingSelect = document.getElementById('building_id');

    branchSelect?.addEventListener('change', function () {
        const branchId = this.value;

        if (!branchId) {
            console.warn("⚠️ No branch selected.");
            buildingSelect.innerHTML = '<option value="">-- Select Building --</option>';
            return;
        }

        console.log("📤 Fetching buildings for Branch ID:", branchId);

        fetch(`/load-buildings-by-branch?branch_id=${encodeURIComponent(branchId)}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' }
        })
        .then(response => {
            if (!response.ok) throw new Error(`Server error: ${response.status}`);
            return response.json();
        })
        .then(result => {
            const buildings = result.data || [];
            console.log("🏢 Buildings received:", buildings);

            // Clear and repopulate building dropdown
            buildingSelect.innerHTML = '<option value="">-- Select Building --</option>';
            buildings.forEach(b => {
                if (b.BUILDING_ID && b.BUILDING_NAME) {
                    const option = document.createElement('option');
                    option.value = b.BUILDING_ID;
                    option.textContent = b.BUILDING_NAME;
                    buildingSelect.appendChild(option);
                }
            });
        })
        .catch(error => {
            console.error("🚨 Could not load buildings:", error);
            buildingSelect.innerHTML = '<option value="">-- Select Building --</option>';
        });
    });
});
 

 
document.addEventListener('DOMContentLoaded', function () {
    const agreementTypeSelect = document.getElementById('agreement_type');
    const tenantSelect = document.getElementById('tenant_id');
    const branchSelect = document.getElementById('branch_id');
    const renewalpercentageSelect = document.getElementById('renewal_percentage');
   //    const renewalpercentageSelect = document.getElementById('renewal_percentage');

    if (agreementTypeSelect) {
        agreementTypeSelect.addEventListener('change', function () {
            const agreementType = this.value;
            const tenantId = tenantSelect?.value;

            console.log("📄 Agreement Type selected:", agreementType);
            console.log("👤 Tenant ID selected:", tenantId);
         //   console.log("👤 renewalpercentageSelectselected:", renewalpercentageSelect.value);

            // Optional: Proceed with API request
            if (agreementType && tenantId) {
                fetch(`/renewal-mapping?agreement_type=${encodeURIComponent(agreementType)}&tenant_id=${tenantId}`, {
                    method: 'GET',
                    headers: { 'Accept': 'application/json' }
                })
                .then(response => {
                    if (!response.ok) throw new Error(`Server responded with ${response.status}`);
                    return response.json();
                })
     .then(result => {
    const mapping = result.data?.[0];
    if (!mapping) {
        console.warn("⚠️ No mapping data available.");
        return;
    }

    console.log("✅ BRANCH_ID:", mapping);
     console.log("✅ Renewal Mapping:", mapping);

    // Dropdowns
    document.getElementById('branch_id').value = mapping.BRANCH_ID || '';

    
    document.getElementById('building_id').value = mapping.BUILDING_ID || '';
    document.getElementById('floor_id').value = mapping.FLOOR_ID || '';
     document.getElementById('property_id').value = mapping.PROPERTY_ID || '';
      document.getElementById('rental_type_id').value = mapping.RENTAL_TYPE_ID || '';
   document.getElementById('notice_period_status').value = mapping.NOTICE_PERIOD_STATUS || '';
  document.getElementById('price_id').value = mapping.PRICE_ID || '';
   document.getElementById('status_master').value = mapping.STATUS_MASTER || '';


    // Input fields
    document.querySelector('input[name="agreement_from_date"]').value = mapping.AGREEMENT_FROM_DATE?.split(' ')[0] || '';

    //document.querySelector('input[name="agreement_to_date"]').value = mapping.AGREEMENT_TO_DATE?.split('T')[0] || '';
    document.querySelector('input[name="agreement_to_date"]').value = mapping.AGREEMENT_TO_DATE?.split(' ')[0] || '';

    document.querySelector('input[name="notice_period_days"]').value = mapping.NOTICE_PERIOD_DAYS || '';
    document.querySelector('input[name="deposit_amount"]').value = mapping.DEPOSIT_AMOUNT || '';
    document.querySelector('input[name="final_deposit_amount_with_vat"]').value = mapping.FINAL_DEPOSIT_AMOUNT_WITH_VAT || '';
    document.querySelector('input[name="vat_deposit_amount"]').value = mapping.VAT_DEPOSIT_AMOUNT || '';
    document.querySelector('input[name="common_maintenance_amount"]').value = mapping.COMMON_MAINTENANCE_AMOUNT || '';
    document.querySelector('input[name="rental_amount"]').value = mapping.RENTAL_AMOUNT || '';
    document.querySelector('input[name="total_rent_amount"]').value = mapping.TOTAL_RENT_AMOUNT || '';
    document.querySelector('input[name="vat_rent_amount"]').value = mapping.VAT_RENT_AMOUNT || '';
    document.querySelector('input[name="final_rent_amount_with_vat"]').value = mapping.FINAL_RENT_AMOUNT_WITH_VAT || '';
    document.querySelector('input[name="remarks"]').value = mapping.REMARKS || '';


   // document.querySelector('input[name="renewal_percentage"]').value = mapping.RENEWAL_PERCENTAGE || '';

       renewalpercentageSelect.addEventListener('change', function () {
            const renAgreementId=mapping.AGREEMENT_ID;
 const ren = document.getElementById('renewal_percentage').value = mapping.RENEWAL_PERCENTAGE || '';
 const updatedRenewal =12;
const type=agreementTypeSelect.value

console.log('renewal name',ren)
console.log('renewal name',renAgreementId)
console.log('renewal name',updatedRenewal)
console.log('renewal name',type)

const payload = {
                agreement_id: renAgreementId,
                renewal_percentage: updatedRenewal,
                agreement_type: agreementTypeSelect.value
            };
const url = `/increase-vat?agreement_id=${encodeURIComponent(renAgreementId)}&renewal_percentage=${encodeURIComponent(updatedRenewal)}&agreement_type=${encodeURIComponent(type)}`;

fetch(url, {
    method: 'GET',
    headers: {
        'Accept': 'application/json'
    }
})
.then(response => response.json())
.then(responseData => {
    const mapping = responseData.data?.[0];
    if (!mapping) {
        console.warn('⚠️ No mapping data found.');
        return;
    }

    document.querySelector('input[name="deposit_amount"]').value = mapping.DEPOSIT_AMOUNT || '';
    document.querySelector('input[name="final_deposit_amount_with_vat"]').value = mapping.FINAL_DEPOSIT_AMOUNT_WITH_VAT || '';
    document.querySelector('input[name="vat_deposit_amount"]').value = mapping.VAT_DEPOSIT_AMOUNT || '';
    document.querySelector('input[name="common_maintenance_amount"]').value = mapping.COMMON_MAINTENANCE_AMOUNT || '';
    document.querySelector('input[name="rental_amount"]').value = mapping.RENTAL_AMOUNT || '';
    document.querySelector('input[name="total_rent_amount"]').value = mapping.TOTAL_RENT_AMOUNT || '';
    document.querySelector('input[name="vat_rent_amount"]').value = mapping.VAT_RENT_AMOUNT || '';
    document.querySelector('input[name="final_rent_amount_with_vat"]').value = mapping.FINAL_RENT_AMOUNT_WITH_VAT || '';

    console.log('✅ Form fields updated with new values.');
})
.catch(error => {
    console.error('❌ AJAX error:', error);
});



       })


       document.addEventListener('DOMContentLoaded', function () {
    const renewalSelect = document.getElementById('renewal_percentage');
    const agreementTypeSelect = document.getElementById('agreement_type');

    if (renewalSelect) {
        renewalSelect.addEventListener('change', function () {
           
            const payload = {
                agreement_id: renAgreementId,
                renewal_percentage: updatedRenewal,
                agreement_type: agreementType
            };

            fetch('/increase-vat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                },
                body: JSON.stringify(payload)
            })
            .then(response => response.json())
            .then(data => {
                console.log('✅ Server response:', data);
                // optionally update UI here
            })
            .catch(error => {
                console.error('❌ AJAX error:', error);
            });
        });
    }
});


  
})
                .catch(error => {
                    console.error("🚨 Error fetching renewal mapping:", error);
                });
            } else {
                console.warn("⚠️ Agreement type or tenant ID missing — request not sent.");
            }
        });
    }
});
 

 
    


        document.addEventListener('DOMContentLoaded', function () {
        //const branchSelect = document.getElementById('branch_id');
        const branchSelect = document.getElementById('branch_id');

        branchSelect.addEventListener('change', function () {
            const selectedOption = this.options[this.selectedIndex];
            const companyId = selectedOption.getAttribute('data-company');

            if (companyId) {
                companySelect.value = companyId;
            }
        });
    });
 
 
document.addEventListener('DOMContentLoaded', function () {
    const modalElement = document.getElementById('addModal');
    const agreementTypeSelect = document.getElementById('agreement_type');
    const noticePeriodStatusSelect = document.getElementById('notice_period_status');
    const statusMasterSelect = document.getElementById('status_master');

    if (modalElement) {
        modalElement.addEventListener('shown.bs.modal', function () {
            console.log("🚀 Add Modal opened — fetching dropdowns...");

            fetchCommonDropdown(3, populateAgreementTypes);         // Agreement Type
            fetchCommonDropdown(8, populateNoticePeriodStatus);     // Notice Period Status
            fetchCommonDropdown(9, populateStatusMaster);           // Status Master
        });
    }

    function fetchCommonDropdown(id, callback = null) {
        fetch(`/common-dropdown/${id}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' }
        })
        .then(response => {
            if (!response.ok) throw new Error(`Server returned ${response.status}`);
            return response.json();
        })
        .then(data => {
            console.log(`✅ Data for Common ID ${id}:`, data);
            if (typeof callback === 'function') {
                callback(data);
            }
        })
        .catch(error => {
            console.error(`🚨 Error fetching Common ID ${id}:`, error);
        });
    }

    function populateAgreementTypes(data) {
        populateDropdown(agreementTypeSelect, data, '-- Select Type --');
    }

    function populateNoticePeriodStatus(data) {
        populateDropdown(noticePeriodStatusSelect, data, '-- Select Status --');
    }

    function populateStatusMaster(data) {
        populateDropdown(statusMasterSelect, data, '-- Select Status --');
    }

    function populateDropdown(selectElement, dataArray, defaultLabel) {
        if (!selectElement || !Array.isArray(dataArray)) return;
        selectElement.innerHTML = `<option value="">${defaultLabel}</option>`;
        dataArray.forEach(item => {
            if (item.ACTIVITY_NAME) {
                const option = document.createElement('option');
                option.value = item.ACTIVITY_NAME;
                option.textContent = item.ACTIVITY_NAME;
                selectElement.appendChild(option);
            }
        });
    }
});
 






 
document.addEventListener('DOMContentLoaded', function () {
    const priceSelect = document.querySelector('select[name="price_id"]');

    if (priceSelect) {
        priceSelect.addEventListener('change', function () {
            const selectedPriceId = this.value;
            console.log("📦 Selected Price ID:", selectedPriceId);

            if (selectedPriceId) {
                fetch(`/price-details/${selectedPriceId}`, {
                    method: 'GET',
                    headers: { 'Accept': 'application/json' }
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`Error ${response.status}: Unable to fetch price details`);
                    }
                    return response.json();
                })
                .then(data => {
                    if (!Array.isArray(data) || !data[0]) {
                        console.warn("⚠️ No price details found.");
                        return;
                    }

                    const priceData = data[0];
                    console.log("✅ Price detail received:", priceData);

                    // Fill in form fields by name
                    document.querySelector('input[name="deposit_amount"]').value = priceData["DEPOSIT_AMOUNT"] || '';
                    document.querySelector('input[name="vat_deposit_amount"]').value = priceData["VAT_DESPOSIT_AMOUNT"] || '';
                    document.querySelector('input[name="final_deposit_amount_with_vat"]').value = priceData["FINAL_DEPOSIT_AMOUNT"] || '';
                    document.querySelector('input[name="common_maintenance_amount"]').value = priceData["COMMON_MAINTENANCE_AMOUNT"] || '';
                    document.querySelector('input[name="rental_amount"]').value = priceData["TOTAL_RENT_AMOUNT_WITHOUT_VAT"] || '';
                    document.querySelector('input[name="total_rent_amount"]').value = priceData["RENTAL_AMOUNT"] || '';
                    document.querySelector('input[name="vat_rent_amount"]').value = priceData["VAT_RENT_AMOUNT"] || '';
                    document.querySelector('input[name="final_rent_amount_with_vat"]').value = priceData["FINAL_RENT_AMOUNT_WITH_VAT"] || '';
                    document.querySelector('input[name="renewal_percentage"]').value = priceData["RENEWAL_PERCENTAGE"] || '';

                    // Optional: Fill in property info if provided
                    if (priceData["PROPERTY_ID"]) {
                        document.getElementById("property_id").value = priceData["PROPERTY_ID"];
                    }
                    if (priceData["PROPERTY_NAME"]) {
                        document.getElementById("property_name").value = priceData["PROPERTY_NAME"];
                    }

                    // Optional visibility logic
                    const renewalContainer = document.getElementById("renewalPercentageContainer");
                    if (priceData["RENEWAL_PERCENTAGE"] && renewalContainer) {
                        renewalContainer.style.display = 'block';
                    }
                })
                .catch(error => {
                    console.error("🚨 Error fetching price details:", error);
                });
            }
        });
    }
});
 




 
document.addEventListener('DOMContentLoaded', function () {
    const agreementTypeSelect = document.getElementById('agreement_type');
    const renewalContainer = document.getElementById('renewalPercentageContainer');

    if (agreementTypeSelect && renewalContainer) {
        // Initial check in case there's a pre-selected value
        toggleRenewalField(agreementTypeSelect.value);

        // Listener for future changes
        agreementTypeSelect.addEventListener('change', function () {
            toggleRenewalField(this.value);
        });
    }

    function toggleRenewalField(selectedType) {
        if (selectedType === 'RENEWAL') {
            renewalContainer.style.display = 'block';
        } else {
            renewalContainer.style.display = 'none';
        }
    }
});
 



 
document.addEventListener('DOMContentLoaded', function () {
    const buttons = document.querySelectorAll('.view-document-btn');
    const modalTitle = document.getElementById('documentPreviewModalLabel');
    const modalContent = document.getElementById('documentPreviewContent');

    buttons.forEach(button => {
        button.addEventListener('click', function () {
            const docName = this.getAttribute('data-doc-name') || 'Document';
            const filePath = this.getAttribute('data-file-path');
            const fileExt = filePath.split('.').pop().toLowerCase();

            modalTitle.textContent = docName;

            if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(fileExt)) {
                modalContent.innerHTML = `<img src="${filePath}" class="img-fluid" alt="${docName}" />`;
            } else if (fileExt === 'pdf') {
                // ✅ Use <embed> to avoid toolbar
                modalContent.innerHTML = `
                    <embed src="${filePath}" type="application/pdf" width="100%" height="600px" />
                `;
            } else {
                modalContent.innerHTML = `<p class="text-danger">Unsupported file type: ${fileExt}</p>`;
            }
        });
    });
});

 


 
document.addEventListener('DOMContentLoaded', function () {
    const editButtons = document.querySelectorAll('.edit-btn');

    editButtons.forEach(button => {
        button.addEventListener('click', function () {
            const agreementType = this.getAttribute('data-agreement-type');
            const tenant = this.getAttribute('data-tenant');
            const branch = this.getAttribute('data-branch');
            //const building = this.getAttribute('data-building');
            const floor = this.getAttribute('data-floor');
            const property = this.getAttribute('data-property');
            const rental = this.getAttribute('data-rental');
            const finalRent = this.getAttribute('data-final-rent');
            const fromDate = this.getAttribute('data-from');
            const toDate = this.getAttribute('data-to');
            const remarks = this.getAttribute('data-remarks');
            const status = this.getAttribute('data-status');
            const priceId = this.getAttribute('data-price');
            const renewal = this.getAttribute('data-renewal');
            const deposit = this.getAttribute('data-deposit');
            const vatDeposit = this.getAttribute('data-vat-deposit');
            const finalDeposit = this.getAttribute('data-final-deposit');
            const maintenance = this.getAttribute('data-maintenance');
            const totalRent = this.getAttribute('data-total-rent');
            const vatRent = this.getAttribute('data-vat-rent');
            const noticeDays = this.getAttribute('data-notice-days');
            const noticeStatus = this.getAttribute('data-notice-status');
            const rentalTypeId = this.getAttribute('data-rental-type');
            const agreementId = this.getAttribute('data-id');


               const fromDateTrimmed = fromDate ? fromDate.substring(0, 10) : '';
            const toDateTrimmed = toDate ? toDate.substring(0, 10) : '';

            // Fill values into form
            document.getElementById('edit_agreement_id').value = agreementId;
            document.getElementById('edit_agreement_type').value = agreementType;
            document.getElementById('edit_tenant_id').value = tenant;
            document.getElementById('edit_branch_id').value = branch;

         const building = this.getAttribute('data-building'); // Gets the building ID from an element's attribute
const selectElement = document.getElementById('edit_building_id');
const selectElement1 = document.getElementById('edit_floor_id');
const selectElement2 =  document.getElementById('edit_property_id');
const selectElement3 =  document.getElementById('edit_rental_type_id');
const selectElement4 =   document.getElementById('edit_price_id');
const selectElement5 =  document.getElementById('edit_status_master');

// Loop through the options and select the matching one
for (let i = 0; i < selectElement.options.length; i++) {
    if (selectElement.options[i].value === building) {
        selectElement.selectedIndex = i;
        break;
    }
}

// Loop through the options and select the matching one
for (let i = 0; i < selectElement1.options.length; i++) {
    if (selectElement1.options[i].value === floor) {
        selectElement1.selectedIndex = i;
        break;
    }
}


// Loop through the options and select the matching one
for (let i = 0; i < selectElement2.options.length; i++) {
    if (selectElement2.options[i].value === property) {
        selectElement2.selectedIndex = i;
        break;
    }
}

// Loop through the options and select the matching one
for (let i = 0; i < selectElement3.options.length; i++) {
    if (selectElement3.options[i].value === rentalTypeId) {
        selectElement3.selectedIndex = i;
        break;
    }
}

// Loop through the options and select the matching one
for (let i = 0; i < selectElement4.options.length; i++) {
    if (selectElement4.options[i].value === priceId) {
        selectElement4.selectedIndex = i;
        break;
    }
}

// Loop through the options and select the matching one
for (let i = 0; i < selectElement5.options.length; i++) {
    if (selectElement5.options[i].value === status) {
        selectElement5.selectedIndex = i;
        break;
    }
}


           document.getElementById('edit_from_date').value = fromDateTrimmed;
            document.getElementById('edit_to_date').value = toDateTrimmed;
            document.getElementById('edit_rental_amount').value = rental;
            document.getElementById('edit_final_rent').value = finalRent;
            document.getElementById('edit_remarks').value = remarks;
 
            document.getElementById('edit_renewal_percentage').value = renewal;
            document.getElementById('edit_deposit_amount').value = deposit;
            document.getElementById('edit_vat_deposit').value = vatDeposit;
            document.getElementById('edit_final_deposit').value = finalDeposit;
            document.getElementById('edit_maintenance').value = maintenance;
            document.getElementById('edit_total_rent').value = totalRent;
            document.getElementById('edit_vat_rent').value = vatRent;
            document.getElementById('edit_notice_days').value = noticeDays;
            document.getElementById('edit_notice_status').value = noticeStatus;
                 

           
            // Optional debugging
            console.log("Edit form filled with:", {
                agreementId, agreementType, tenant, branch, building, floor, property,
                rental, finalRent, fromDate, toDate, remarks, status, priceId,
                renewal, deposit, vatDeposit, finalDeposit, maintenance,
                totalRent, vatRent, noticeDays, noticeStatus, rentalTypeId
            });
        });
    });
});



 



 


   document.addEventListener('DOMContentLoaded', function () {
    const deleteButtons = document.querySelectorAll('.delete-agreement-btn');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function () {
            const AgreementId = this.dataset.id;
            const AgreementName = this.dataset.name;

            document.getElementById('delete_Agreement_Mapping_id').value = AgreementId;
            document.getElementById('delete_Agreement_Mapping_name').textContent = AgreementName;
        });
    });
});





    document.addEventListener('DOMContentLoaded', function () {
        const branchSelect = document.getElementById('branch_id');
        const companySelect = document.getElementById('company_id');

        branchSelect.addEventListener('change', function () {
            const selectedOption = this.options[this.selectedIndex];
            const companyId = selectedOption.getAttribute('data-company');

            if (companyId) {
                companySelect.value = companyId;
            }
        });
    });



 

 
document.addEventListener("DOMContentLoaded", function () {
  console.log("DOM fully loaded"); // <- Ensure this shows!

  document.querySelectorAll('.view-btn').forEach(button => {
    button.addEventListener('click', function () {
      console.log('jd clicked'); // <- Must show in console!

      const data = this.dataset;

      LoadDocumentPath(data.id)

      document.getElementById('view_agreement_id').value = data.id || '';
      document.getElementById('view_agreement_type').value = data.agreementType || '';

      document.getElementById('view_tenant_id').value = data.tenant || '';
      document.getElementById('view_branch_id').value = data.branch || '';
      document.getElementById('view_building_id').value = data.building || '';
      document.getElementById('view_floor_id').value = data.floor || '';
      document.getElementById('view_property_id').value = data.property || '';
      document.getElementById('view_rental_type_id').value = data.rentalTypeId || '';
     // document.getElementById('view_price_id').value = data.priceId || '';


      document.getElementById('view_agreement_from_date').value = data.from?.split(' ')[0] || '';
      document.getElementById('view_agreement_to_date').value = data.to?.split(' ')[0] || '';
      document.getElementById('view_notice_period_days').value = data.noticeDays || '';
      document.getElementById('view_notice_period_status').value = data.noticeStatus || '';
      document.getElementById('view_renewal_percentage').value = data.renewal || '';
      document.getElementById('view_deposit_amount').value = data.deposit || '';
      document.getElementById('view_vat_deposit_amount').value = data.vatDeposit || '';
      document.getElementById('view_final_deposit_amount_with_vat').value = data.finalDeposit || '';
      document.getElementById('view_rental_amount').value = data.rental || '';
      document.getElementById('view_common_maintenance_amount').value = data.maintenance || '';
      document.getElementById('view_total_rent_amount').value = data.totalRent || '';
      document.getElementById('view_vat_rent_amount').value = data.vatRent || '';
      document.getElementById('view_final_rent_amount_with_vat').value = data.finalRent || '';
      document.getElementById('view_remarks').value = data.remarks || '';
      document.getElementById('view_status_master').value = data.status || '';
      //const docId = data.data-doc-id;
      const docId = data.docId;
const filePath = data['filePath'];
 console.log('hello',data)
         console.log('hello',data.docId)
      //  const filePath = data.data-file-path;
      

         
            const documentListContainer = document.getElementById('documentListContainer');

            if (filePath && docId) {
                documentListContainer.innerHTML = `
                    <div class="d-flex align-items-center gap-2 mt-1">
                        <a href="${filePath}" target="_blank" class="btn btn-outline-primary btn-sm">
                            <i class="fas fa-eye me-1"></i> View Document
                        </a>
                        <span class="text-muted small">Document ID: ${docId}</span>
                    </div>
                `;
            } else {
                documentListContainer.innerHTML = `<span class="text-muted fst-italic">No document availabless</span>`;
            }
      
          

    });
  });

 function LoadDocumentPath(data) {
    fetch(`/LoadDocumentPath/${data}`)
        .then(response => response.json())
        .then(data => {
            console.log('Parsed document data:', data);

            const documentListContainer = document.getElementById('documentListContainer');
            documentListContainer.innerHTML = ''; // Clear previous content

            if (Array.isArray(data) && data.length > 0) {
                data.forEach(doc => {
                    const filePath = doc.FILE_PATH;
                    const docId = doc.DOC_ID;
                    const docName = doc.DOCUMENT_NAME;

                    const docHTML = `
                        <div class="d-flex align-items-center gap-2 mt-1">
                         <span class="text-muted small mb-4 bold">Document Name:${docName}</span>
                            <a href="${filePath}" target="_blank" class="btn btn-outline-primary btn-sm">
                                <i class="fas fa-eye me-1"></i> View Document
                            </a>
                           
                        </div>
                    `;
                    documentListContainer.innerHTML += docHTML;
                });
            } else {
                documentListContainer.innerHTML = `<span class="text-muted fst-italic">No document available</span>`;
            }
        })
        .catch(err => console.error('Error loading documents:', err));
}

});

document.addEventListener('DOMContentLoaded', function () {
    const branchSelect = document.getElementById('branch_id');

    branchSelect.addEventListener('change', function () {
        const branchId = this.value;
        console.log('Selected Branch ID:', branchId);

        if (branchId) {
            fetch(`/branch-details/${branchId}`)
                .then(response => {
                    console.log('Raw response:', response);
                    return response.json();
                })
                .then(data => {
                    console.log('Parsed data:', data);

                    if (data.length > 0) {
                        const item = data[0];

                        // Set visible fields (names)
                        document.getElementById('building_name').value = item.BUILDING_NAME || '';
                        document.getElementById('floor_name').value = item.FLOOR_NAME || '';
                        document.getElementById('property_name').value = item.PROPERTY_NAME || '';

                        // Set hidden fields (IDs)
                        document.getElementById('building_id').value = item.BUILDING_ID || '';
                        document.getElementById('floor_id').value = item.FLOOR_ID || '';
                        document.getElementById('property_id').value = item.PROPERTY_ID || '';
                    } else {
                        // Clear all
                        ['building_name', 'floor_name', 'property_name',
                         'building_id', 'floor_id', 'property_id'].forEach(id => {
                            document.getElementById(id).value = '';
                        });
                    }
                })
                .catch(err => console.error('Error loading branch details:', err));
        } else {
            // Clear all if no branch selected
            ['building_name', 'floor_name', 'property_name',
             'building_id', 'floor_id', 'property_id'].forEach(id => {
                document.getElementById(id).value = '';
            });
        }
    });
});


document.addEventListener('DOMContentLoaded', function () {
    var documentModal = document.getElementById('documentModal');

    if (!documentModal) {
        console.error('Modal element #documentModal not found!');
        return;
    }

    documentModal.addEventListener('shown.bs.modal', function () {
        console.log('Document Modal is opened');

        const tenantSelect = documentModal.querySelector('#tenant_id');
        const agreementSelect = documentModal.querySelector('#agreement_id');

        if (!tenantSelect) {
            console.error('Tenant select #tenant_id not found in modal!');
            return;
        }
        if (!agreementSelect) {
            console.error('Agreement select #agreement_id not found in modal!');
            return;
        }

        // Clear agreement dropdown every time modal opens
        agreementSelect.innerHTML = '<option value="">-- Select Agreement --</option>';

        // Remove existing change listener by cloning the node (clean slate)
        const newTenantSelect = tenantSelect.cloneNode(true);
        tenantSelect.parentNode.replaceChild(newTenantSelect, tenantSelect);

        console.log('Attaching change event listener to tenant select');

        newTenantSelect.addEventListener('change', function () {
            const tenantId = this.value;
            console.log('Tenant selected:', tenantId);

            if (tenantId) {
                fetch(`/agreements-by-tenant/${tenantId}`)
                    .then(response => {
                        console.log('Raw fetch response:', response);
                        return response.json();
                    })
                    .then(data => {
                        console.log('Parsed agreements data:', data);

                        agreementSelect.innerHTML = '<option value="">-- Select Agreement --</option>';

                        if (!data || data.length === 0) {
                            console.log('No agreements found for this tenant.');
                            agreementSelect.innerHTML = '<option value="">-- No agreements found --</option>';
                        } else {
                            data.forEach(agreement => {
                                console.log('Adding agreement option:', agreement);
                                const option = document.createElement('option');
                                option.value = agreement.AGREEMENT_ID;
                                option.text = agreement.AGREEMENT_NAME || `Agreement #${agreement.AGREEMENT_ID}`;
                                agreementSelect.appendChild(option);
                            });
                        }
                    })
                    .catch(err => {
                        console.error('Fetch error:', err);
                        agreementSelect.innerHTML = '<option value="">-- Error loading --</option>';
                    });
            } else {
                console.log('No tenant selected, clearing agreement dropdown.');
                agreementSelect.innerHTML = '<option value="">-- Select Agreement --</option>';
            }
        });

        // For debugging: show attached event listeners in console
        console.log('Event listeners on tenant select:', getEventListeners(newTenantSelect));
    });
});





